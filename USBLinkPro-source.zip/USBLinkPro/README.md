# USB Link Pro — stability baseline

Modules: `:core` (shared reliability layer + UI), `:controller` (Controller app), `:receiver` (Receiver app).
Stack: Kotlin 1.9.24, AGP 8.6.1, Gradle 8.9, compileSdk/targetSdk 35, minSdk 26, Compose, Room 2.6.1, WorkManager 2.9.1.

## Build
1. `gradle wrapper --gradle-version 8.9` (the wrapper JAR is not included), then `./gradlew assembleDebug`.
2. Full validation: `scripts/validate.sh` (writes real results to `build-logs/summary.txt`).
3. Unit tests: `./gradlew :core:testDebugUnitTest`. Instrumented: `./gradlew connectedDebugAndroidTest` (device/emulator required).

## Where each requirement lives
| Spec area | Code |
|---|---|
| Crash prevention | `util/CrashDiagnostics`, `util/SafeCall`, `ui/UiState` (`ActionGuard`, `GuardedViewModel`), `BaseApp` |
| Background execution | `service/TransferService` (dataSync FGS, self-stopping), `work/Workers` (restore + maintenance) |
| Task persistence | `data/TaskRepository` (state machine, `restoreIncomplete`), `data/Entities` |
| Network reliability | `net/*`, `session/Session.kt`, `command/CommandExecutor` |
| USB reliability | `usb/*` |
| Performance | Dispatchers.IO/Default in repositories/engines, `LazyColumn` screens, `LogViewModel` paging, `TerminalBuffer`, `MemoryMonitor`, Reduced Motion setting |
| Database & storage | `data/*`, `BackupManager`, `util/StorageCleaner` |
| APK transfer | `transfer/*` |
| UI stability | `ui/*` |
| Compatibility engine | `compat/CompatibilityEngine` |
| Tests | `core/src/test`, `core/src/androidTest`, `*/src/androidTest` |
