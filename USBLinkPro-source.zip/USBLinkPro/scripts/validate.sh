#!/usr/bin/env bash
# Runs the 13-step release validation and writes REAL results to build-logs/summary.txt.
# Nothing is reported as PASS unless the command actually exited with status 0.
set -u
cd "$(dirname "$0")/.."
LOG=build-logs; mkdir -p "$LOG"; SUMMARY="$LOG/summary.txt"; : > "$SUMMARY"
GW=./gradlew; [ -x "$GW" ] || GW=gradle
step() { # name, logfile, command...
  local name="$1" file="$LOG/$2"; shift 2
  if "$@" >"$file" 2>&1; then echo "PASS     $name" | tee -a "$SUMMARY"; else echo "FAIL     $name (see $file)" | tee -a "$SUMMARY"; fi
}
skip() { echo "SKIPPED  $1 ($2)" | tee -a "$SUMMARY"; }

step "1 Clean build"            01-clean.log        $GW clean
step "2 Compile Controller"     02-controller.log   $GW :controller:assembleDebug :controller:assembleRelease
step "3 Compile Receiver"       03-receiver.log     $GW :receiver:assembleDebug :receiver:assembleRelease
step "4 Unit tests"             04-unit.log         $GW :core:testDebugUnitTest
if adb devices 2>/dev/null | awk 'NR>1 && $2=="device"' | grep -q .; then
  step "5 Integration/instrumented tests" 05-instrumented.log $GW :core:connectedDebugAndroidTest :controller:connectedDebugAndroidTest :receiver:connectedDebugAndroidTest
else skip "5 Integration/instrumented tests" "no device/emulator attached"; fi
step "6 Lint"                   06-lint.log         $GW :core:lintDebug :controller:lintRelease :receiver:lintRelease
step "7 Dependencies"           07-deps.log         $GW :controller:dependencies :receiver:dependencies --configuration releaseRuntimeClasspath
for app in controller receiver; do
  apk=$(ls $app/build/outputs/apk/debug/*.apk 2>/dev/null | head -1)
  mf=$(ls $app/build/intermediates/merged_manifests/release/*/AndroidManifest.xml $app/build/intermediates/merged_manifests/release/AndroidManifest.xml 2>/dev/null | head -1)
  if [ -n "$mf" ]; then grep -o 'uses-permission[^/]*android:name="[^"]*"' "$mf" > "$LOG/08-permissions-$app.txt"; echo "DONE     8 Manifest permissions $app -> $LOG/08-permissions-$app.txt" | tee -a "$SUMMARY"
  else skip "8 Manifest permissions $app" "merged manifest not found"; fi
  rel=$(ls $app/build/outputs/apk/release/*.apk 2>/dev/null | head -1)
  if [ -n "$rel" ]; then echo "DONE     9 APK size $app: $(stat -c %s "$rel") bytes ($rel)" | tee -a "$SUMMARY"; else skip "9 APK size $app" "release APK not built"; fi
  if [ -n "$apk" ] && adb devices 2>/dev/null | awk 'NR>1 && $2=="device"' | grep -q .; then
    step "10 Install $app (debug APK)" "10-install-$app.log" adb install -r "$apk"
  else skip "10 Install $app" "no APK or no device"; fi
done
skip "11 Real device connections" "manual: pair Controller and Receiver over Wi-Fi/hotspot and USB; record results in docs/COMPATIBILITY_REPORT.md"
if adb devices 2>/dev/null | awk 'NR>1 && $2=="device"' | grep -q .; then
  adb logcat -d -b crash > "$LOG/12-crash-buffer.txt" 2>&1; echo "DONE     12 Crash buffer captured: $(wc -l < "$LOG/12-crash-buffer.txt") lines" | tee -a "$SUMMARY"
else skip "12 Review crash reports" "no device"; fi
echo "Summary written to $SUMMARY"
