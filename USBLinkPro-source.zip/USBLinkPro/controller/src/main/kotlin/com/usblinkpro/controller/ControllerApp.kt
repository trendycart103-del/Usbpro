package com.usblinkpro.controller

import com.usblinkpro.core.BaseApp

class ControllerApp : BaseApp() {
    override val installRequired: Boolean = false
}
