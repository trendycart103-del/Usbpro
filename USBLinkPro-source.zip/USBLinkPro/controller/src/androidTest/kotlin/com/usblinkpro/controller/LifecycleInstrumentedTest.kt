package com.usblinkpro.controller

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LifecycleInstrumentedTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun navigationStateSurvivesActivityRecreation() {
        rule.onNodeWithText("Settings").performClick()
        rule.onNodeWithText("Reduced motion").assertIsDisplayed()
        rule.activityRule.scenario.recreate()
        rule.onNodeWithText("Reduced motion").assertIsDisplayed()
    }

    @Test fun deviceScreenShowsHonestStatuses() {
        rule.onNodeWithText("Device").performClick()
        rule.waitUntil(5_000) { rule.onAllNodesWithTextCompat("USB HID gadget") }
    }

    private fun androidx.compose.ui.test.junit4.AndroidComposeTestRule<*, *>.onAllNodesWithTextCompat(t: String): Boolean =
        onAllNodes(androidx.compose.ui.test.hasText(t, substring = true)).fetchSemanticsNodes().isNotEmpty()
}
