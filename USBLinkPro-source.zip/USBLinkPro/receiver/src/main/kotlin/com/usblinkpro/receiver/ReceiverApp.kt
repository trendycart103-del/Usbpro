package com.usblinkpro.receiver

import com.usblinkpro.core.BaseApp

class ReceiverApp : BaseApp() {
    override val installRequired: Boolean = true
}
