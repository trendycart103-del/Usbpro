package com.usblinkpro.receiver

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.usblinkpro.core.Core
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.transfer.InstallResult
import com.usblinkpro.core.transfer.InstallResultBus
import com.usblinkpro.core.ui.AppRoot
import com.usblinkpro.core.util.CrashDiagnostics
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                InstallResultBus.events.collect { handle(it) }
            }
        }
        setContent { AppRoot("USB Link Pro Receiver") }
    }

    private suspend fun handle(result: InstallResult) {
        val logs = Core.get().logs
        when (result) {
            is InstallResult.NeedsUserAction -> try {
                startActivity(result.intent) // system installer confirmation; installation is never silent
            } catch (e: Exception) {
                CrashDiagnostics.recordNonFatal("install_confirm", e)
                logs.append(LogLevel.WARN, "Could not open the installer confirmation screen")
            }
            is InstallResult.Success -> logs.append(LogLevel.INFO, "Install succeeded: ${result.packageName}")
            is InstallResult.Failure -> logs.append(LogLevel.WARN, "Install failed (status ${result.status}): ${result.message}")
            InstallResult.Cancelled -> logs.append(LogLevel.INFO, "Install cancelled by the user")
        }
    }
}
