package com.usblinkpro.core

import android.content.Context
import androidx.compose.material3.Text
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.assertIsDisplayed
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.usblinkpro.core.compat.CompatibilityEngine
import com.usblinkpro.core.compat.DeviceSnapshotReader
import com.usblinkpro.core.net.Availability
import com.usblinkpro.core.net.NetworkMonitor
import com.usblinkpro.core.net.ReceiverAvailability
import com.usblinkpro.core.transfer.ApkValidator
import com.usblinkpro.core.ui.StateView
import com.usblinkpro.core.ui.UiState
import com.usblinkpro.core.util.ApkValidationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.net.ServerSocket

@RunWith(AndroidJUnit4::class)
class DeviceInstrumentedTest {
    @get:Rule val compose = createComposeRule()
    private val ctx: Context = ApplicationProvider.getApplicationContext()

    @Test fun errorStateShowsRetryAndRetryIsClickable() {
        var retried = 0
        compose.setContent { StateView<String>(UiState.Error("Boom"), onRetry = { retried++ }, emptyText = "") {} }
        compose.onNodeWithText("Boom").assertIsDisplayed()
        compose.onNodeWithText("Retry").performClick(); compose.onNodeWithText("Retry").performClick()
        assertEquals(2, retried)
    }

    @Test fun emptyAndContentStates() {
        compose.setContent { StateView(UiState.Empty, onRetry = {}, emptyText = "Nothing here") { s: String -> Text(s) } }
        compose.onNodeWithText("Nothing here").assertIsDisplayed()
    }

    @Test fun networkMonitorEmitsInitialState() = runBlocking {
        withTimeout(5_000) { NetworkMonitor(ctx).states.first() }; Unit
    }

    @Test fun receiverAvailabilityDetectsOpenAndClosedPorts() = runBlocking {
        val s = ServerSocket(0); val port = s.localPort
        assertEquals(Availability.AVAILABLE, ReceiverAvailability.probe("127.0.0.1", port))
        s.close()
        assertEquals(Availability.UNREACHABLE, ReceiverAvailability.probe("127.0.0.1", port))
    }

    @Test fun apkValidatorRejectsNonApkAndWrongPackage() = runBlocking {
        val v = ApkValidator(ctx)
        val junk = File(ctx.cacheDir, "junk.apk").apply { writeText("not an apk") }
        try { v.validate(junk); fail() } catch (_: ApkValidationException) {}
        val testApk = File(androidx.test.platform.app.InstrumentationRegistry.getInstrumentation().context.applicationInfo.sourceDir)
        val info = v.validate(testApk)
        assertTrue(info.packageName.isNotEmpty())
        try { v.validate(testApk, expectedPackage = "com.example.other"); fail() } catch (_: ApkValidationException) {}
        try { v.validate(testApk, expectedSha256 = "0".repeat(64)); fail() } catch (_: ApkValidationException) {}
    }

    @Test fun compatibilityReaderNeverThrows() {
        val items = CompatibilityEngine.evaluate(DeviceSnapshotReader(ctx, installRequired = true).read())
        assertTrue(items.isNotEmpty()); assertTrue(items.any { it.id == "usb_hid" })
    }
}
