package com.usblinkpro.core

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import com.usblinkpro.core.data.BackupManager
import com.usblinkpro.core.data.DbHolder
import com.usblinkpro.core.data.IllegalTaskTransitionException
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.data.LogRepository
import com.usblinkpro.core.data.TaskRepository
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.work.TaskRestoreWorker
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class PersistenceInstrumentedTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val name = "test-${System.nanoTime()}.db"

    @Before fun clean() { ctx.deleteDatabase(name) }
    @After fun tearDown() { ctx.deleteDatabase(name); Core.install(null) }

    @Test fun taskLifecycleAndIllegalTransition() = runBlocking {
        val repo = TaskRepository(DbHolder(ctx, name))
        val t = repo.create("cmd:x", idempotent = false, sessionId = null)
        repo.transition(t.taskId, TaskStatus.RUNNING)
        assertEquals(TaskStatus.COMPLETED, repo.transition(t.taskId, TaskStatus.COMPLETED).status)
        try { repo.transition(t.taskId, TaskStatus.RUNNING); fail() } catch (_: IllegalTaskTransitionException) {}
    }

    @Test fun processRecreationRestoresTasksSafely() = runBlocking {
        val h1 = DbHolder(ctx, name); val repo1 = TaskRepository(h1)
        val idem = repo1.create("transfer", true, null); val non = repo1.create("cmd:x", false, null)
        val bound = repo1.create("cmd:y", true, "old-session")
        for (t in listOf(idem, non, bound)) repo1.transition(t.taskId, TaskStatus.RUNNING)
        h1.close() // simulates process death / device restart: new holder reads the same file
        val repo2 = TaskRepository(DbHolder(ctx, name))
        val report = repo2.restoreIncomplete()
        assertEquals(1, report.resumable); assertEquals(1, report.needsVerification); assertEquals(1, report.failed)
        assertEquals(TaskStatus.PENDING, repo2.get(idem.taskId)!!.status)
        assertEquals(TaskStatus.NEEDS_VERIFICATION, repo2.get(non.taskId)!!.status)
        assertEquals(TaskStatus.FAILED, repo2.get(bound.taskId)!!.status)
    }

    @Test fun restoreWorkerRuns() = runBlocking {
        val holder = DbHolder(ctx, name)
        Core.install(CoreContainer(ctx, holder, false))
        val repo = Core.get().tasks
        val t = repo.create("cmd", false, null); repo.transition(t.taskId, TaskStatus.RUNNING)
        val result = TestListenableWorkerBuilder<TaskRestoreWorker>(ctx).build().doWork()
        assertEquals(ListenableWorker.Result.success(), result)
        assertEquals(TaskStatus.NEEDS_VERIFICATION, repo.get(t.taskId)!!.status)
    }

    @Test fun logsPaginateRotateAndRedact() = runBlocking {
        val logs = LogRepository(DbHolder(ctx, name))
        repeat(120) { logs.append(LogLevel.INFO, "entry $it password=secret$it") }
        val p1 = logs.page(limit = 50); val p2 = logs.page(p1.last().id, 50)
        assertEquals(50, p1.size); assertTrue(p1.first().id > p2.first().id)
        assertTrue(p1.none { it.message.contains("secret") })
        logs.rotate(maxRows = 30)
        assertEquals(30, logs.page(limit = 200).size)
    }

    @Test fun corruptDatabaseIsQuarantinedNotCrashed() = runBlocking {
        val f = ctx.getDatabasePath(name); f.parentFile!!.mkdirs(); f.writeBytes(ByteArray(4096) { 0x41 })
        val holder = DbHolder(ctx, name)
        val repo = TaskRepository(holder)
        repo.create("after-corruption", true, null)
        assertTrue(holder.recoveredFromCorruption)
        assertTrue(f.parentFile!!.listFiles()!!.any { it.name.startsWith("$name.corrupt-") })
        f.parentFile!!.listFiles()!!.filter { it.name.startsWith("$name.corrupt-") }.forEach { it.delete() }
    }

    @Test fun backupAndRestoreRoundTrip() = runBlocking {
        val holder = DbHolder(ctx, name); val repo = TaskRepository(holder)
        val t = repo.create("keep-me", true, null)
        val file = File(ctx.cacheDir, "bk-${System.nanoTime()}.db")
        BackupManager(holder).backup(file)
        repo.transition(t.taskId, TaskStatus.CANCELLED)
        BackupManager(holder).restore(file)
        assertEquals(TaskStatus.PENDING, TaskRepository(holder).get(t.taskId)!!.status)
        file.delete(); assertFalse(file.exists())
    }
}
