package com.usblinkpro.core.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [
        TaskEntity::class,
        CommandHistoryEntity::class,
        ExecutionLogEntity::class,
        TransferMetaEntity::class,
        PairingEntity::class,
        PreferenceEntity::class
    ],
    version = AppDatabase.VERSION,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun commandHistoryDao(): CommandHistoryDao
    abstract fun logDao(): LogDao
    abstract fun transferDao(): TransferDao
    abstract fun pairingDao(): PairingDao
    abstract fun preferenceDao(): PreferenceDao

    companion object {
        const val VERSION = 1
    }
}

/** Version 1 is the baseline schema; add Migration objects here when VERSION is raised. */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
