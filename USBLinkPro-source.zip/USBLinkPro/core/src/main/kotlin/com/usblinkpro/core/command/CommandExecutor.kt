package com.usblinkpro.core.command

import com.usblinkpro.core.data.AuditLog
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.data.TaskStore
import com.usblinkpro.core.session.Admission
import com.usblinkpro.core.session.SessionManager
import com.usblinkpro.core.session.SessionValidator
import com.usblinkpro.core.util.CommandRejectedException
import com.usblinkpro.core.util.OperationTimeoutException
import com.usblinkpro.core.util.StaleSessionException
import com.usblinkpro.core.util.TerminalBuffer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/** An allow-listed command. There is no raw shell: unknown ids and malformed arguments are rejected. */
data class CommandSpec(
    val id: String,
    val maxArgs: Int = 0,
    val argPattern: Regex = Regex("[A-Za-z0-9._:/-]{1,128}"),
    val requiresApproval: Boolean = true
)

class CommandPolicy(specs: Collection<CommandSpec>) {
    private val byId = specs.associateBy { it.id }

    fun validate(id: String, args: List<String>): CommandSpec {
        val spec = byId[id] ?: throw CommandRejectedException("Command is not allowed")
        if (args.size > spec.maxArgs) throw CommandRejectedException("Too many arguments")
        if (args.any { !spec.argPattern.matches(it) }) throw CommandRejectedException("Invalid argument")
        return spec
    }
}

data class CommandRequest(
    val id: String,
    val args: List<String>,
    val sessionId: String?,
    val requestId: String,
    val issuedAtMs: Long,
    val idempotent: Boolean
)

sealed interface ExecResult {
    data class Success(val taskId: String, val output: String) : ExecResult
    data class Failed(val taskId: String, val error: Throwable, val needsVerification: Boolean) : ExecResult
}

/**
 * Executes exactly one approved, validated, session-bound command at a time. There is no batch or
 * "execute all" entry point. A command interrupted by timeout or session change is never retried
 * automatically; if it is not idempotent its task becomes NEEDS_VERIFICATION.
 */
class CommandExecutor(
    private val policy: CommandPolicy,
    private val sessions: SessionManager,
    private val validator: SessionValidator,
    private val tasks: TaskStore,
    private val audit: AuditLog,
    private val terminal: TerminalBuffer,
    private val timeoutMs: Long = 30_000,
    private val handler: suspend (CommandSpec, List<String>) -> String
) {
    suspend fun execute(request: CommandRequest, approved: Boolean): ExecResult {
        val spec = policy.validate(request.id, request.args)
        if (spec.requiresApproval && !approved) throw CommandRejectedException("User approval required")
        when (validator.admit(request.sessionId, request.requestId, request.issuedAtMs)) {
            Admission.OK -> Unit
            Admission.NO_SESSION -> throw CommandRejectedException("Not connected")
            Admission.STALE_SESSION -> throw StaleSessionException()
            Admission.EXPIRED -> throw CommandRejectedException("Command expired")
            Admission.DUPLICATE -> throw CommandRejectedException("Duplicate request")
        }
        try {
            val task = tasks.create("cmd:${spec.id}", request.idempotent, request.sessionId)
            tasks.transition(task.taskId, TaskStatus.RUNNING)
            return try {
                val output = runWatched(request.sessionId, spec, request.args)
                terminal.append(output)
                tasks.transition(task.taskId, TaskStatus.COMPLETED, result = output.take(200))
                audit.command(spec.id, task.taskId, "ok")
                ExecResult.Success(task.taskId, output)
            } catch (e: CancellationException) {
                withContext(NonCancellable) {
                    runCatching { tasks.transition(task.taskId, TaskStatus.CANCELLED) }
                }
                throw e
            } catch (e: Exception) {
                val uncertain = !request.idempotent
                val next = if (uncertain) TaskStatus.NEEDS_VERIFICATION else TaskStatus.FAILED
                runCatching { tasks.transition(task.taskId, next, error = e.message ?: e::class.java.simpleName) }
                audit.command(spec.id, task.taskId, "failed")
                audit.log(LogLevel.WARN, "Command ${spec.id} failed: ${e.message}", task.taskId)
                ExecResult.Failed(task.taskId, e, uncertain)
            }
        } finally {
            validator.release(request.requestId)
        }
    }

    private suspend fun runWatched(sessionId: String?, spec: CommandSpec, args: List<String>): String = coroutineScope {
        val watcher = launch {
            while (isActive) {
                delay(500)
                if (!sessions.isCurrent(sessionId)) throw StaleSessionException()
            }
        }
        try {
            try {
                withTimeout(timeoutMs) { handler(spec, args) }
            } catch (e: TimeoutCancellationException) {
                throw OperationTimeoutException(spec.id, timeoutMs)
            }
        } finally {
            watcher.cancel()
        }
    }
}
