package com.usblinkpro.core.ui

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

val LocalReducedMotion = compositionLocalOf { false }

fun <T> motionSpec(reduced: Boolean): FiniteAnimationSpec<T> = if (reduced) snap() else tween(180)

@Composable
fun <T> StateView(
    state: UiState<T>,
    onRetry: () -> Unit,
    emptyText: String,
    modifier: Modifier = Modifier,
    content: @Composable (T) -> Unit
) {
    Box(modifier.fillMaxSize()) {
        when (state) {
            is UiState.Loading -> CircularProgressIndicator(
                Modifier.align(Alignment.Center).semantics { contentDescription = "Loading" }
            )
            is UiState.Empty -> Text(emptyText, Modifier.align(Alignment.Center).padding(24.dp))
            is UiState.Error -> Column(
                Modifier.align(Alignment.Center).padding(24.dp).semantics { liveRegion = LiveRegionMode.Polite },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(state.message)
                if (state.retryable) Button(onClick = onRetry, modifier = Modifier.heightIn(min = 48.dp)) { Text("Retry") }
            }
            is UiState.Content -> content(state.data)
        }
    }
}

@Composable
fun ErrorBanner(error: UiError, onDismiss: () -> Unit, onRetry: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(8.dp).semantics { liveRegion = LiveRegionMode.Assertive },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(error.message, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
        if (error.retryable && onRetry != null) TextButton(onClick = onRetry, modifier = Modifier.heightIn(min = 48.dp)) { Text("Retry") }
        TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("Dismiss") }
    }
}

/** Disabled while [busy], so the same request cannot be submitted twice. */
@Composable
fun ActionButton(text: String, busy: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick = onClick, enabled = !busy, modifier = modifier.heightIn(min = 48.dp)) {
        Text(if (busy) "$text…" else text)
    }
}
