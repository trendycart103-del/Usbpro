package com.usblinkpro.core.transfer

import com.usblinkpro.core.data.TransferMetaEntity
import com.usblinkpro.core.data.TransferStatus
import com.usblinkpro.core.data.TransferStore
import com.usblinkpro.core.util.Hashing
import com.usblinkpro.core.util.InputValidator
import com.usblinkpro.core.util.TransferProtocolException
import com.usblinkpro.core.util.ValidationException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * Sender side: validates the file, detects duplicates, resumes from the receiver's committed offset
 * after verifying the shared prefix hash, sends fixed-size chunks and persists progress.
 */
class TransferEngine(
    private val store: TransferStore,
    private val clock: () -> Long = System::currentTimeMillis,
    private val persistEveryBytes: Long = 1L shl 20
) {
    suspend fun send(
        file: File,
        transferId: String,
        sink: ChunkSink,
        chunkSize: Int = 64 * 1024,
        allowDuplicate: Boolean = false,
        taskId: String? = null,
        onProgress: (sent: Long, total: Long) -> Unit = { _, _ -> }
    ): TransferOutcome {
        if (chunkSize !in 4096..(4 shl 20)) throw ValidationException("Invalid chunk size")
        if (!file.isFile || !file.canRead()) throw TransferProtocolException("Source file is not readable")
        val total = file.length()
        if (total <= 0) throw TransferProtocolException("Source file is empty")

        val sha = Hashing.sha256(file)
        if (!allowDuplicate) {
            store.findCompletedBySha(sha)?.let { return TransferOutcome.Duplicate(it) }
        }
        val header = TransferHeader(transferId, InputValidator.fileName(file.name), total, sha, chunkSize)
        store.upsert(
            TransferMetaEntity(transferId, header.fileName, total, 0, sha, chunkSize, TransferStatus.IN_PROGRESS, clock(), taskId)
        )

        var committed = 0L
        try {
            val state = sink.begin(header)
            committed = state.offset
            if (committed > 0) {
                val prefixOk = committed <= total &&
                    Hashing.sha256(file, committed).equals(state.prefixSha256, ignoreCase = true)
                if (!prefixOk) {
                    sink.reset()
                    committed = 0
                }
            }
            withContext(Dispatchers.IO) {
                RandomAccessFile(file, "r").use { raf ->
                    val buf = ByteArray(chunkSize)
                    var lastPersist = committed
                    raf.seek(committed)
                    while (committed < total) {
                        ensureActive()
                        val want = minOf(chunkSize.toLong(), total - committed).toInt()
                        val n = raf.read(buf, 0, want)
                        if (n <= 0) throw IOException("Source file changed during transfer")
                        sink.write(committed, buf, n)
                        committed += n
                        onProgress(committed, total)
                        if (committed - lastPersist >= persistEveryBytes) {
                            store.updateProgress(transferId, committed, TransferStatus.IN_PROGRESS, clock())
                            lastPersist = committed
                        }
                    }
                }
            }
            sink.finish()
            store.updateProgress(transferId, total, TransferStatus.COMPLETED, clock())
            return TransferOutcome.Completed(sha)
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                runCatching { store.updateProgress(transferId, committed, TransferStatus.IN_PROGRESS, clock()) }
            }
            throw e
        } catch (e: Exception) {
            withContext(NonCancellable) {
                runCatching { store.updateProgress(transferId, committed, TransferStatus.FAILED, clock()) }
            }
            throw e
        }
    }
}
