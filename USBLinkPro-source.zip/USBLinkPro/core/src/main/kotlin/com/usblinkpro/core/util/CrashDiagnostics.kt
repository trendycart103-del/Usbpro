package com.usblinkpro.core.util

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Writes sanitized crash/non-fatal reports to app-private storage. The uncaught-exception handler
 * records the report and then delegates to the previous handler: the process is NOT kept alive in
 * an undefined state. Feature isolation is done with guarded coroutine scopes instead.
 */
object CrashDiagnostics {
    private const val MAX_FILES = 20
    private const val MAX_BYTES = 32 * 1024

    @Volatile private var dir: File? = null

    fun install(context: Context) {
        dir = File(context.filesDir, "crash").apply { mkdirs() }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { write("fatal", thread.name, error) }
            previous?.uncaughtException(thread, error)
        }
    }

    fun recordNonFatal(tag: String, error: Throwable) {
        runCatching { write("nonfatal", tag, error) }
    }

    fun reports(): List<File> =
        dir?.listFiles { f -> f.isFile && f.name.endsWith(".txt") }?.sortedByDescending { it.name } ?: emptyList()

    fun clear() {
        reports().forEach { it.delete() }
    }

    private fun write(kind: String, tag: String, error: Throwable) {
        val d = dir ?: return
        val header = "kind=$kind tag=$tag time=${System.currentTimeMillis()} sdk=${Build.VERSION.SDK_INT} " +
            "device=${Build.MANUFACTURER} ${Build.MODEL}\n"
        val body = LogSanitizer.redact(header + error.stackTraceToString()).take(MAX_BYTES)
        File(d, "$kind-${System.currentTimeMillis()}-${System.nanoTime() % 1000}.txt").writeText(body)
        d.listFiles()?.sortedByDescending { it.name }?.drop(MAX_FILES)?.forEach { it.delete() }
    }
}
