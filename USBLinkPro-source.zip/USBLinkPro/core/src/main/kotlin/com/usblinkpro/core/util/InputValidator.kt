package com.usblinkpro.core.util

object InputValidator {
    private val HOST = Regex(
        "^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$"
    )

    /** Accepts hostnames and dotted IPv4 literals. */
    fun host(value: String): String {
        val v = value.trim()
        if (!HOST.matches(v)) throw ValidationException("Invalid host name or address")
        return v
    }

    fun port(value: Int): Int {
        if (value !in 1..65535) throw ValidationException("Port must be between 1 and 65535")
        return value
    }

    fun port(value: String): Int =
        port(value.trim().toIntOrNull() ?: throw ValidationException("Port must be a number"))

    fun fileName(value: String): String {
        val v = value.trim()
        if (v.isEmpty() || v.length > 255) throw ValidationException("Invalid file name length")
        if (v == "." || v == ".." || v.contains("..")) throw ValidationException("Invalid file name")
        if (v.any { it == '/' || it == '\\' || it == ':' || it.code < 32 || it.code == 127 }) {
            throw ValidationException("File name contains illegal characters")
        }
        return v
    }
}
