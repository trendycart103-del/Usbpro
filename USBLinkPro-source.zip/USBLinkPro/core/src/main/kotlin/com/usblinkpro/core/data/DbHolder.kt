package com.usblinkpro.core.data

import android.content.Context
import android.database.sqlite.SQLiteException
import androidx.room.Room
import com.usblinkpro.core.util.CrashDiagnostics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Lazily opens the database off the main thread, verifies integrity and, if the file is corrupt or
 * cannot be migrated, quarantines it (kept as *.corrupt-<ts>) and starts with a fresh database
 * instead of crashing. Pass name = null for an in-memory database (tests).
 */
class DbHolder(context: Context, private val name: String? = "usblinkpro.db") {
    private val appContext = context.applicationContext
    private val mutex = Mutex()

    @Volatile private var db: AppDatabase? = null

    @Volatile var recoveredFromCorruption: Boolean = false
        private set

    val dbFile: File? get() = name?.let { appContext.getDatabasePath(it) }

    suspend fun get(): AppDatabase {
        db?.let { return it }
        return mutex.withLock { db ?: open().also { db = it } }
    }

    suspend fun close() {
        mutex.withLock {
            db?.close()
            db = null
        }
    }

    private suspend fun open(): AppDatabase = withContext(Dispatchers.IO) {
        val first = build()
        try {
            verify(first)
            first
        } catch (e: Exception) {
            if (e !is SQLiteException && e !is IllegalStateException) throw e
            CrashDiagnostics.recordNonFatal("db_open_failed", e)
            runCatching { first.close() }
            quarantine()
            recoveredFromCorruption = true
            val fresh = build()
            verify(fresh)
            fresh
        }
    }

    private fun build(): AppDatabase {
        val builder = if (name == null) {
            Room.inMemoryDatabaseBuilder(appContext, AppDatabase::class.java)
        } else {
            Room.databaseBuilder(appContext, AppDatabase::class.java, name)
        }
        return builder.addMigrations(*Migrations.ALL).build()
    }

    private fun verify(database: AppDatabase) {
        database.openHelper.writableDatabase.query("PRAGMA quick_check").use { c ->
            if (!c.moveToFirst() || c.getString(0) != "ok") throw SQLiteException("Integrity check failed")
        }
    }

    private fun quarantine() {
        val base = dbFile ?: return
        val ts = System.currentTimeMillis()
        if (base.exists()) base.renameTo(File(base.path + ".corrupt-" + ts))
        for (suffix in listOf("-wal", "-shm", "-journal")) File(base.path + suffix).delete()
    }
}
