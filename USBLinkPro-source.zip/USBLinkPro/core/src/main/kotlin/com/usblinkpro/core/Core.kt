package com.usblinkpro.core

import android.app.Application
import android.content.Context
import com.usblinkpro.core.data.BackupManager
import com.usblinkpro.core.data.DbHolder
import com.usblinkpro.core.data.LogRepository
import com.usblinkpro.core.data.PairingRepository
import com.usblinkpro.core.data.SettingsRepository
import com.usblinkpro.core.data.TaskRepository
import com.usblinkpro.core.data.TransferRepository
import com.usblinkpro.core.net.NetworkMonitor
import com.usblinkpro.core.session.RequestDeduplicator
import com.usblinkpro.core.session.SessionManager
import com.usblinkpro.core.session.SessionValidator
import com.usblinkpro.core.transfer.ApkInstaller
import com.usblinkpro.core.transfer.ApkValidator
import com.usblinkpro.core.transfer.TransferEngine
import com.usblinkpro.core.usb.UsbSessionManager
import com.usblinkpro.core.util.MemoryMonitor
import com.usblinkpro.core.util.TerminalBuffer
import java.io.File

/** Hand-wired dependency container; avoids a DI framework dependency. */
class CoreContainer(appContext: Context, val holder: DbHolder, val installRequired: Boolean) {
    val context: Context = appContext.applicationContext

    val tasks = TaskRepository(holder)
    val logs = LogRepository(holder)
    val settings = SettingsRepository(holder)
    val transfers = TransferRepository(holder)
    val pairings = PairingRepository(holder)
    val backup = BackupManager(holder)

    val sessions = SessionManager()
    val dedup = RequestDeduplicator()
    val validator = SessionValidator(sessions, dedup)

    val memory = MemoryMonitor(context)
    val network = NetworkMonitor(context)
    val terminal = TerminalBuffer()

    val partDir = File(context.filesDir, "transfers/part")
    val receivedDir = File(context.filesDir, "transfers/received")
    val backupDir = File(context.filesDir, "backups")

    val transferEngine by lazy { TransferEngine(transfers) }
    val apkValidator by lazy { ApkValidator(context) }
    val apkInstaller by lazy { ApkInstaller(context) }
    val usb by lazy { UsbSessionManager(context) }
}

object Core {
    @Volatile private var container: CoreContainer? = null

    fun init(app: Application, installRequired: Boolean): CoreContainer =
        container ?: synchronized(this) {
            container ?: CoreContainer(app, DbHolder(app), installRequired).also { container = it }
        }

    /** For tests: replace the container. */
    fun install(c: CoreContainer?) {
        container = c
    }

    fun get(): CoreContainer = container ?: error("Core.init() has not been called")

    fun from(context: Context): CoreContainer =
        container ?: init(context.applicationContext as Application, installRequired = false)
}
