package com.usblinkpro.core.transfer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import androidx.core.content.IntentCompat
import com.usblinkpro.core.util.InstallNotAllowedException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

sealed interface InstallResult {
    /** The system installer needs the user to confirm. The foreground Activity must start [intent]. */
    data class NeedsUserAction(val intent: Intent) : InstallResult
    data class Success(val packageName: String?) : InstallResult
    data class Failure(val status: Int, val message: String?) : InstallResult
    data object Cancelled : InstallResult
}

object InstallResultBus {
    private val _events = MutableSharedFlow<InstallResult>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<InstallResult> = _events.asSharedFlow()
    fun post(result: InstallResult) {
        _events.tryEmit(result)
    }
}

object InstallStatusMapper {
    fun map(status: Int, message: String?, packageName: String?, confirmIntent: Intent?): InstallResult = when (status) {
        PackageInstaller.STATUS_PENDING_USER_ACTION ->
            confirmIntent?.let { InstallResult.NeedsUserAction(it) }
                ?: InstallResult.Failure(status, "Installer did not provide a confirmation screen")
        PackageInstaller.STATUS_SUCCESS -> InstallResult.Success(packageName)
        PackageInstaller.STATUS_FAILURE_ABORTED -> InstallResult.Cancelled
        else -> InstallResult.Failure(status, message)
    }
}

class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
        val pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME)
        val confirm = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_INTENT, Intent::class.java)
        InstallResultBus.post(InstallStatusMapper.map(status, message, pkg, confirm))
    }
}

/**
 * Installs through PackageInstaller. The system always shows its own confirmation, so installation
 * is never silent. The confirmation Intent is delivered through [InstallResultBus] and must be
 * launched by the visible Activity (background activity launches are restricted by Android).
 */
class ApkInstaller(private val context: Context) {

    fun canInstall(): Boolean = context.packageManager.canRequestPackageInstalls()

    suspend fun install(file: File) = withContext(Dispatchers.IO) {
        if (!canInstall()) throw InstallNotAllowedException("Allow this app to install packages in system settings first")
        if (!file.isFile || file.length() <= 0) throw IOException("APK file is missing")
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setSize(file.length())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED)
        }
        val sessionId = installer.createSession(params)
        val session = installer.openSession(sessionId)
        try {
            file.inputStream().use { input ->
                session.openWrite("base.apk", 0, file.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            ensureActive()
            session.commit(statusIntentSender(sessionId))
        } catch (e: Exception) {
            runCatching { session.abandon() }
            throw e
        } finally {
            session.close()
        }
    }

    private fun statusIntentSender(sessionId: Int) = PendingIntent.getBroadcast(
        context,
        sessionId,
        Intent(context, InstallResultReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
    ).intentSender
}
