package com.usblinkpro.core.usb

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import com.usblinkpro.core.util.UsbDisconnectedException
import com.usblinkpro.core.util.UsbPermissionException
import com.usblinkpro.core.util.UsbTransferException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/** Thin abstraction over a claimed USB interface so session logic is unit-testable. */
interface UsbLink {
    val isOpen: Boolean
    fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, offset: Int, length: Int, timeoutMs: Int): Int

    /** Releases the interface and closes the connection. Must be idempotent. */
    fun release()
}

class AndroidUsbLink private constructor(
    private val connection: UsbDeviceConnection,
    private val usbInterface: UsbInterface
) : UsbLink {
    private val closed = AtomicBoolean(false)
    private val endpoints: Map<Int, UsbEndpoint> =
        (0 until usbInterface.endpointCount).map { usbInterface.getEndpoint(it) }.associateBy { it.address }

    override val isOpen: Boolean get() = !closed.get()

    override fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, offset: Int, length: Int, timeoutMs: Int): Int {
        val ep = endpoints[endpointAddress] ?: throw UsbTransferException("Unknown endpoint $endpointAddress")
        if (closed.get()) return -1
        return connection.bulkTransfer(ep, buffer, offset, length, timeoutMs)
    }

    override fun release() {
        if (closed.compareAndSet(false, true)) {
            runCatching { connection.releaseInterface(usbInterface) }
            runCatching { connection.close() }
        }
    }

    companion object {
        /** Claims the interface; closes the connection and throws if the claim fails. */
        fun claim(connection: UsbDeviceConnection, usbInterface: UsbInterface): AndroidUsbLink {
            if (!connection.claimInterface(usbInterface, true)) {
                connection.close()
                throw UsbTransferException("Could not claim USB interface")
            }
            return AndroidUsbLink(connection, usbInterface)
        }
    }
}

class UsbSession(
    private val link: UsbLink,
    val deviceName: String,
    val outEndpoint: Int
) : AutoCloseable {
    private val closed = AtomicBoolean(false)

    val isActive: Boolean get() = !closed.get() && link.isOpen

    /**
     * Writes in small chunks so cancellation and detach are noticed between chunks. Runs on
     * Dispatchers.IO. Throws [UsbDisconnectedException] if the session was closed or the device left.
     */
    suspend fun write(
        data: ByteArray,
        length: Int = data.size,
        chunkTimeoutMs: Int = 1_000
    ): Int = withContext(Dispatchers.IO) {
        require(length in 0..data.size) { "length out of range" }
        var offset = 0
        var zeroResults = 0
        while (offset < length) {
            ensureActive()
            if (!isActive) throw UsbDisconnectedException(deviceName)
            val n = link.bulkTransfer(outEndpoint, data, offset, minOf(length - offset, MAX_CHUNK), chunkTimeoutMs)
            if (n < 0) {
                if (!isActive) throw UsbDisconnectedException(deviceName)
                throw UsbTransferException("Bulk transfer failed ($n)")
            }
            if (n == 0 && ++zeroResults >= 3) throw UsbTransferException("Bulk transfer made no progress")
            if (n > 0) zeroResults = 0
            offset += n
        }
        offset
    }

    /** Idempotent. Always releases the interface and connection exactly once. */
    override fun close() {
        if (closed.compareAndSet(false, true)) link.release()
    }

    companion object {
        const val MAX_CHUNK = 16 * 1024
    }
}

/** Opens a session or throws; never leaks a connection. [opener] returns null if the device cannot be opened. */
fun openSession(deviceName: String, hasPermission: Boolean, outEndpoint: Int, opener: () -> UsbLink?): UsbSession {
    if (!hasPermission) throw UsbPermissionException(deviceName)
    val link = opener() ?: throw UsbTransferException("Could not open USB device")
    return UsbSession(link, deviceName, outEndpoint)
}

data class BulkTarget(val usbInterface: UsbInterface, val outEndpointAddress: Int)

object UsbCapabilities {
    fun findBulkOutTarget(device: UsbDevice): BulkTarget? {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK && ep.direction == UsbConstants.USB_DIR_OUT) {
                    return BulkTarget(intf, ep.address)
                }
            }
        }
        return null
    }
}
