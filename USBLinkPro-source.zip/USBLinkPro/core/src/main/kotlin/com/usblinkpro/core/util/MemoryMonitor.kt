package com.usblinkpro.core.util

import android.app.ActivityManager
import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class MemorySnapshot(val usedHeapBytes: Long, val maxHeapBytes: Long, val systemLow: Boolean, val availSystemBytes: Long)

/** Uses only public APIs: ComponentCallbacks2 trim levels, Runtime heap figures, ActivityManager.MemoryInfo. */
class MemoryMonitor(private val context: Context) : ComponentCallbacks2 {
    private val _trim = MutableSharedFlow<Int>(extraBufferCapacity = 4, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val trimEvents: SharedFlow<Int> = _trim.asSharedFlow()

    fun register(app: Application) = app.registerComponentCallbacks(this)

    override fun onTrimMemory(level: Int) {
        _trim.tryEmit(level)
    }

    override fun onLowMemory() {
        _trim.tryEmit(ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
    }

    override fun onConfigurationChanged(newConfig: Configuration) = Unit

    fun snapshot(): MemorySnapshot {
        val rt = Runtime.getRuntime()
        val info = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java)?.getMemoryInfo(info)
        return MemorySnapshot(rt.totalMemory() - rt.freeMemory(), rt.maxMemory(), info.lowMemory, info.availMem)
    }
}
