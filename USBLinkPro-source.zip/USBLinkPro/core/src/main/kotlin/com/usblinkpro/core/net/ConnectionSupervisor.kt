package com.usblinkpro.core.net

import com.usblinkpro.core.session.SessionManager
import com.usblinkpro.core.util.withNetworkTimeout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data object WaitingForNetwork : ConnectionState
    data class Connecting(val attempt: Int) : ConnectionState
    data class Connected(val sessionId: String) : ConnectionState
}

/**
 * Keeps a connection alive until the user calls [disconnect]. Every network change and every
 * heartbeat loss invalidates the session id, so commands issued under an older session are rejected
 * by SessionValidator and never replayed after reconnection.
 */
class ConnectionSupervisor(
    private val scope: CoroutineScope,
    private val network: Flow<NetworkState>,
    private val sessions: SessionManager,
    private val connect: suspend () -> Boolean,
    private val ping: suspend () -> Boolean,
    private val policy: RetryPolicy = RetryPolicy(),
    private val connectTimeoutMs: Long = 10_000,
    private val heartbeatIntervalMs: Long = 5_000,
    private val heartbeatTimeoutMs: Long = 3_000,
    private val maxMisses: Int = 3
) {
    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()
    private var job: Job? = null

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            network.collectLatest { net ->
                sessions.invalidate()
                if (!net.connected) {
                    _state.value = ConnectionState.WaitingForNetwork
                    return@collectLatest
                }
                var attempt = 0
                while (isActive) {
                    _state.value = ConnectionState.Connecting(attempt)
                    val ok = try {
                        withNetworkTimeout(connectTimeoutMs) { connect() }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        false
                    }
                    if (ok) {
                        _state.value = ConnectionState.Connected(sessions.open())
                        awaitHeartbeatLoss()
                        sessions.invalidate()
                        attempt = 0
                    } else {
                        delay(policy.delayFor(attempt))
                        attempt++
                    }
                }
            }
        }
    }

    private suspend fun awaitHeartbeatLoss() = coroutineScope {
        val lost = CompletableDeferred<Unit>()
        val monitor = HeartbeatMonitor(this, heartbeatIntervalMs, heartbeatTimeoutMs, maxMisses, ping) {
            lost.complete(Unit)
        }
        monitor.start()
        try {
            lost.await()
        } finally {
            monitor.stop()
        }
    }

    /** Manual disconnect: stops reconnecting and invalidates the session. */
    @Synchronized
    fun disconnect() {
        job?.cancel()
        job = null
        sessions.invalidate()
        _state.value = ConnectionState.Disconnected
    }
}
