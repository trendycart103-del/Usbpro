package com.usblinkpro.core.net

import com.usblinkpro.core.util.InputValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

enum class Availability { AVAILABLE, UNREACHABLE, TIMEOUT }

object ReceiverAvailability {
    /** Plain TCP reachability probe. Inputs are validated; the socket is always closed. */
    suspend fun probe(host: String, port: Int, timeoutMs: Int = 2_000): Availability {
        val h = InputValidator.host(host)
        val p = InputValidator.port(port)
        return withContext(Dispatchers.IO) {
            val socket = Socket()
            try {
                val address = InetSocketAddress(h, p)
                if (address.isUnresolved) {
                    Availability.UNREACHABLE
                } else {
                    socket.connect(address, timeoutMs)
                    Availability.AVAILABLE
                }
            } catch (e: SocketTimeoutException) {
                Availability.TIMEOUT
            } catch (e: IOException) {
                Availability.UNREACHABLE
            } finally {
                runCatching { socket.close() }
            }
        }
    }
}
