package com.usblinkpro.core

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.pm.ApplicationInfo
import android.os.StrictMode
import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.diagnosticsExceptionHandler
import com.usblinkpro.core.work.Workers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

abstract class BaseApp : Application() {
    /** True only for the app that installs APKs (the Receiver). */
    protected abstract val installRequired: Boolean

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + diagnosticsExceptionHandler("app_scope"))

    override fun onCreate() {
        super.onCreate()
        CrashDiagnostics.install(this)
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())
            StrictMode.setVmPolicy(
                StrictMode.VmPolicy.Builder().detectLeakedClosableObjects().detectLeakedSqlLiteObjects().detectActivityLeaks().penaltyLog().build()
            )
        }
        val core = Core.init(this, installRequired)
        core.memory.register(this)
        appScope.launch {
            core.memory.trimEvents.collect { level ->
                if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) core.terminal.trimTo(100)
            }
        }
        appScope.launch { core.holder.get() } // open + integrity-check the database off the main thread
        Workers.schedule(this)
    }
}
