package com.usblinkpro.core.compat

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.UserManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat

enum class SupportStatus { SUPPORTED, UNSUPPORTED, UNKNOWN }

data class CompatItem(val id: String, val title: String, val status: SupportStatus, val detail: String)

/** A null field means "could not be determined" and always yields UNKNOWN. */
data class DeviceSnapshot(
    val sdkInt: Int,
    val manufacturer: String,
    val hasUsbHost: Boolean?,
    val hasUsbAccessory: Boolean?,
    val hasWifi: Boolean?,
    val notificationsEnabled: Boolean?,
    val tetheringRestricted: Boolean?,
    val backgroundRestricted: Boolean?,
    val installRequired: Boolean,
    val canInstallPackages: Boolean?,
    val installRestricted: Boolean?,
    val settingsIntents: Map<String, Boolean?>
)

object CompatibilityEngine {
    private val restrictiveOems = setOf("xiaomi", "redmi", "poco", "huawei", "honor", "oppo", "realme", "vivo", "oneplus", "meizu", "asus", "samsung")

    fun evaluate(s: DeviceSnapshot, minSdk: Int = 26): List<CompatItem> = buildList {
        add(
            if (s.sdkInt >= minSdk) CompatItem("sdk", "Android version", SupportStatus.SUPPORTED, "API ${s.sdkInt} (minimum $minSdk)")
            else CompatItem("sdk", "Android version", SupportStatus.UNSUPPORTED, "API ${s.sdkInt} is below the minimum $minSdk")
        )
        add(tri("notifications", "Notifications", s.notificationsEnabled,
            "Enabled", "Disabled: progress and approval requests cannot be shown", "Could not be determined"))
        val oem = s.manufacturer.lowercase()
        add(
            if (oem in restrictiveOems) CompatItem("oem", "Manufacturer behavior", SupportStatus.UNKNOWN,
                "${s.manufacturer} devices may stop background work aggressively; behavior is not verifiable by the app")
            else CompatItem("oem", "Manufacturer behavior", SupportStatus.SUPPORTED,
                "${s.manufacturer} is not on the app's list of OEMs known for aggressive background limits (list is not exhaustive)")
        )
        add(tri("usb_host", "USB host mode", s.hasUsbHost, "Reported by the system", "Not reported by the system", "Could not be determined"))
        add(tri("usb_accessory", "USB accessory mode", s.hasUsbAccessory, "Reported by the system", "Not reported by the system", "Could not be determined"))
        add(CompatItem("usb_hid", "USB HID gadget", SupportStatus.UNKNOWN, "Cannot be detected without privileged access; never assumed"))
        add(tri("wifi", "Wi-Fi", s.hasWifi, "Reported by the system", "Not reported by the system", "Could not be determined"))
        add(
            when (s.tetheringRestricted) {
                true -> CompatItem("hotspot", "Hotspot", SupportStatus.UNSUPPORTED, "Disabled by device policy")
                false -> CompatItem("hotspot", "Hotspot", SupportStatus.UNKNOWN, "No policy restriction found; tethering availability cannot be verified through public APIs")
                null -> CompatItem("hotspot", "Hotspot", SupportStatus.UNKNOWN, "Could not be determined")
            }
        )
        add(tri("background", "Background execution", s.backgroundRestricted?.not(),
            "Not restricted for this app", "Background activity is restricted for this app", "Could not be determined"))
        if (s.installRequired) {
            val status = when {
                s.installRestricted == true -> CompatItem("install", "Package installation", SupportStatus.UNSUPPORTED, "Blocked by device policy")
                s.canInstallPackages == true -> CompatItem("install", "Package installation", SupportStatus.SUPPORTED, "App is allowed to request installs")
                s.canInstallPackages == false -> CompatItem("install", "Package installation", SupportStatus.UNSUPPORTED, "Install permission not granted in system settings")
                else -> CompatItem("install", "Package installation", SupportStatus.UNKNOWN, "Could not be determined")
            }
            add(status)
        }
        for ((name, available) in s.settingsIntents) {
            add(tri("intent_$name", "Settings screen: $name", available, "Available", "Not available on this device", "Could not be determined"))
        }
    }

    private fun tri(id: String, title: String, value: Boolean?, yes: String, no: String, unknown: String) = when (value) {
        true -> CompatItem(id, title, SupportStatus.SUPPORTED, yes)
        false -> CompatItem(id, title, SupportStatus.UNSUPPORTED, no)
        null -> CompatItem(id, title, SupportStatus.UNKNOWN, unknown)
    }
}

class DeviceSnapshotReader(private val context: Context, private val installRequired: Boolean) {

    fun read(): DeviceSnapshot {
        val pm = context.packageManager
        val um = context.getSystemService(UserManager::class.java)
        val am = context.getSystemService(ActivityManager::class.java)
        return DeviceSnapshot(
            sdkInt = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER ?: "unknown",
            hasUsbHost = pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST),
            hasUsbAccessory = pm.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY),
            hasWifi = pm.hasSystemFeature(PackageManager.FEATURE_WIFI),
            notificationsEnabled = runCatching { NotificationManagerCompat.from(context).areNotificationsEnabled() }.getOrNull(),
            tetheringRestricted = runCatching { um?.hasUserRestriction(UserManager.DISALLOW_CONFIG_TETHERING) }.getOrNull(),
            backgroundRestricted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) runCatching { am?.isBackgroundRestricted }.getOrNull() else null,
            installRequired = installRequired,
            canInstallPackages = if (installRequired) runCatching { pm.canRequestPackageInstalls() }.getOrNull() else null,
            installRestricted = if (installRequired) runCatching {
                um?.let { it.hasUserRestriction(UserManager.DISALLOW_INSTALL_APPS) || it.hasUserRestriction(UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES) }
            }.getOrNull() else null,
            settingsIntents = buildMap {
                put("Wi-Fi", resolves(Intent(Settings.ACTION_WIFI_SETTINGS)))
                put("App details", resolves(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))))
                if (installRequired) {
                    put("Install unknown apps", resolves(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))))
                }
            }
        )
    }

    private fun resolves(intent: Intent): Boolean? =
        runCatching { context.packageManager.resolveActivity(intent, 0) != null }.getOrNull()
}
