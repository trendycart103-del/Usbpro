package com.usblinkpro.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(task: TaskEntity)

    @Update
    suspend fun update(task: TaskEntity): Int

    @Query("SELECT * FROM tasks WHERE taskId = :id")
    suspend fun get(id: String): TaskEntity?

    @Query("SELECT * FROM tasks WHERE status IN ('PENDING','RUNNING','WAITING_NETWORK','NEEDS_VERIFICATION') ORDER BY startTime")
    suspend fun incomplete(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE status IN ('RUNNING','WAITING_NETWORK')")
    fun observeActive(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY startTime DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<TaskEntity>>

    @Query("UPDATE tasks SET progress = :progress, lastUpdate = :now WHERE taskId = :id AND status = 'RUNNING'")
    suspend fun setProgress(id: String, progress: Int, now: Long): Int

    @Query("DELETE FROM tasks WHERE status IN ('COMPLETED','FAILED','CANCELLED') AND lastUpdate < :before")
    suspend fun deleteTerminalBefore(before: Long): Int
}

@Dao
interface CommandHistoryDao {
    @Insert
    suspend fun insert(entry: CommandHistoryEntity): Long

    @Query("SELECT * FROM command_history ORDER BY id DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<CommandHistoryEntity>

    @Query("DELETE FROM command_history WHERE id NOT IN (SELECT id FROM command_history ORDER BY id DESC LIMIT :keep)")
    suspend fun trimToCount(keep: Int): Int
}

@Dao
interface LogDao {
    @Insert
    suspend fun insert(entry: ExecutionLogEntity): Long

    @Query("SELECT * FROM execution_logs WHERE id < :beforeId ORDER BY id DESC LIMIT :limit")
    suspend fun page(beforeId: Long, limit: Int): List<ExecutionLogEntity>

    @Query("DELETE FROM execution_logs WHERE id NOT IN (SELECT id FROM execution_logs ORDER BY id DESC LIMIT :keep)")
    suspend fun trimToCount(keep: Int): Int

    @Query("DELETE FROM execution_logs WHERE timestamp < :before")
    suspend fun deleteBefore(before: Long): Int
}

@Dao
interface TransferDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meta: TransferMetaEntity)

    @Query("SELECT * FROM transfer_meta WHERE transferId = :id")
    suspend fun get(id: String): TransferMetaEntity?

    @Query("SELECT * FROM transfer_meta WHERE sha256 = :sha AND status = 'COMPLETED' LIMIT 1")
    suspend fun findCompleted(sha: String): TransferMetaEntity?

    @Query("UPDATE transfer_meta SET committedBytes = :committed, status = :status, updatedAt = :now WHERE transferId = :id")
    suspend fun updateProgress(id: String, committed: Long, status: TransferStatus, now: Long): Int

    @Query("SELECT * FROM transfer_meta WHERE status IN ('IN_PROGRESS','FAILED') ORDER BY updatedAt DESC")
    suspend fun resumable(): List<TransferMetaEntity>

    @Query("DELETE FROM transfer_meta WHERE status IN ('COMPLETED','FAILED','CANCELLED') AND updatedAt < :before")
    suspend fun deleteTerminalBefore(before: Long): Int
}

@Dao
interface PairingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pairing: PairingEntity)

    @Query("SELECT * FROM pairings ORDER BY lastSeen DESC")
    suspend fun all(): List<PairingEntity>

    @Query("DELETE FROM pairings WHERE deviceId = :id")
    suspend fun delete(id: String): Int
}

@Dao
interface PreferenceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pref: PreferenceEntity)

    @Query("SELECT prefValue FROM preferences WHERE prefKey = :key")
    suspend fun get(key: String): String?

    @Query("SELECT prefValue FROM preferences WHERE prefKey = :key")
    fun observe(key: String): Flow<String?>
}
