package com.usblinkpro.core.util

import com.usblinkpro.core.data.IllegalTaskTransitionException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketException
import java.net.UnknownHostException

class ValidationException(message: String) : IllegalArgumentException(message)
class NetworkTimeoutException(val timeoutMs: Long, cause: Throwable? = null) :
    IOException("Timed out after ${timeoutMs}ms", cause)

class OperationTimeoutException(val key: String, val timeoutMs: Long) :
    Exception("Operation '$key' timed out after ${timeoutMs}ms")

class UsbDisconnectedException(device: String) : IOException("USB device disconnected: $device")
class UsbTransferException(message: String) : IOException(message)
class UsbPermissionException(device: String) : SecurityException("USB permission not granted for $device")
class InsufficientStorageException(val needed: Long, val available: Long) :
    IOException("Not enough storage: need $needed bytes, have $available")

class ChecksumMismatchException(val expected: String, val actual: String) :
    IOException("SHA-256 mismatch")

class TransferProtocolException(message: String) : IOException(message)
class ApkValidationException(message: String) : Exception(message)
class InstallNotAllowedException(message: String) : Exception(message)
class CommandRejectedException(message: String) : Exception(message)
class StaleSessionException : Exception("Connection session changed; command discarded")

object ErrorMessages {
    fun userMessage(e: Throwable): String = when (e) {
        is NetworkTimeoutException, is OperationTimeoutException ->
            "The operation timed out. Check the connection and try again."
        is UnknownHostException -> "The receiver could not be found. Check the address."
        is ConnectException, is SocketException -> "Connection failed or was lost. Try reconnecting."
        is UsbDisconnectedException -> "The USB device was disconnected."
        is UsbPermissionException -> "USB permission was not granted."
        is UsbTransferException -> "USB transfer failed. Reconnect the device and retry."
        is InsufficientStorageException -> "Not enough free storage for this operation."
        is ChecksumMismatchException -> "The file failed integrity verification. Retry the transfer."
        is ApkValidationException -> e.message ?: "The APK is not valid."
        is InstallNotAllowedException -> e.message ?: "Installing apps is not allowed for this app."
        is ValidationException -> e.message ?: "Invalid input."
        is CommandRejectedException -> e.message ?: "Command rejected."
        is StaleSessionException -> "The connection changed while the command was running."
        is IllegalTaskTransitionException -> "This task can no longer be changed."
        is OutOfMemoryError -> "The device is low on memory. Close other apps and retry."
        is IOException -> "An I/O error occurred. Please retry."
        else -> "Something went wrong. Please try again."
    }

    fun isRetryable(e: Throwable): Boolean =
        e !is ValidationException && e !is CommandRejectedException && e !is ApkValidationException &&
            e !is InstallNotAllowedException
}
