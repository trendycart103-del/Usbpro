package com.usblinkpro.core.data

import kotlinx.coroutines.flow.Flow

interface TaskStore {
    fun observeRecent(limit: Int): Flow<List<TaskEntity>>
    suspend fun create(type: String, idempotent: Boolean, sessionId: String?): TaskEntity
    suspend fun transition(
        id: String,
        to: TaskStatus,
        error: String? = null,
        result: String? = null,
        incrementRetry: Boolean = false
    ): TaskEntity
}

interface TransferStore {
    suspend fun upsert(meta: TransferMetaEntity)
    suspend fun findCompletedBySha(sha: String): TransferMetaEntity?
    suspend fun updateProgress(id: String, committed: Long, status: TransferStatus, now: Long)
}

interface AuditLog {
    suspend fun log(level: LogLevel, message: String, taskId: String? = null)
    suspend fun command(commandId: String, taskId: String?, outcome: String)
}
