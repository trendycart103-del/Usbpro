package com.usblinkpro.core.session

import java.util.UUID

/** Holds the id of the live connection session. Any network change or disconnect invalidates it. */
class SessionManager {
    private val lock = Any()
    private var current: String? = null

    fun open(): String = synchronized(lock) { UUID.randomUUID().toString().also { current = it } }
    fun invalidate() = synchronized(lock) { current = null }
    fun currentId(): String? = synchronized(lock) { current }
    fun isCurrent(id: String?): Boolean = synchronized(lock) { id != null && id == current }
}

/** Rejects duplicate request ids, both while in flight and for [ttlMs] after completion. */
class RequestDeduplicator(
    private val ttlMs: Long = 60_000,
    private val maxEntries: Int = 512,
    private val clock: () -> Long = System::currentTimeMillis
) {
    private val inFlight = HashSet<String>()
    private val recent = LinkedHashMap<String, Long>()

    @Synchronized
    fun tryBegin(key: String): Boolean {
        prune()
        if (key in inFlight || recent.containsKey(key)) return false
        inFlight += key
        return true
    }

    @Synchronized
    fun finish(key: String) {
        inFlight -= key
        recent[key] = clock()
        while (recent.size > maxEntries) recent.remove(recent.keys.first())
    }

    private fun prune() {
        val cutoff = clock() - ttlMs
        val it = recent.entries.iterator()
        while (it.hasNext()) if (it.next().value < cutoff) it.remove()
    }
}

enum class Admission { OK, NO_SESSION, STALE_SESSION, EXPIRED, DUPLICATE }

class SessionValidator(
    private val sessions: SessionManager,
    private val dedup: RequestDeduplicator,
    private val ttlMs: Long = 30_000,
    private val clock: () -> Long = System::currentTimeMillis
) {
    /** When OK is returned the request id is claimed; call [release] when the command ends. */
    fun admit(sessionId: String?, requestId: String, issuedAtMs: Long): Admission {
        if (sessions.currentId() == null) return Admission.NO_SESSION
        if (!sessions.isCurrent(sessionId)) return Admission.STALE_SESSION
        val age = clock() - issuedAtMs
        if (age > ttlMs || age < -ttlMs) return Admission.EXPIRED
        if (!dedup.tryBegin(requestId)) return Admission.DUPLICATE
        return Admission.OK
    }

    fun release(requestId: String) = dedup.finish(requestId)
}
