package com.usblinkpro.core.util

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Bounded, sanitized, in-memory terminal output. Old lines are dropped; long lines are truncated. */
class TerminalBuffer(private val maxLines: Int = 500, private val maxLineLength: Int = 1000) {
    private val lines = ArrayDeque<String>()
    private val _version = MutableStateFlow(0L)
    val version: StateFlow<Long> = _version.asStateFlow()

    @Synchronized
    fun append(raw: String) {
        val bounded = raw.take(maxLineLength * 64)
        for (line in bounded.split('\n')) {
            lines.addLast(LogSanitizer.redact(line.take(maxLineLength)))
            while (lines.size > maxLines) lines.removeFirst()
        }
        _version.value = _version.value + 1
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()

    @Synchronized
    fun trimTo(keep: Int) {
        while (lines.size > keep.coerceAtLeast(0)) lines.removeFirst()
        _version.value = _version.value + 1
    }

    @Synchronized
    fun clear() = trimTo(0)
}
