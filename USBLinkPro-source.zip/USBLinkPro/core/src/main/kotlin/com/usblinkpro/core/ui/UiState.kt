package com.usblinkpro.core.ui

import androidx.compose.runtime.Immutable
import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.ErrorMessages
import com.usblinkpro.core.util.OperationTimeoutException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data object Empty : UiState<Nothing>
    data class Content<T>(val data: T) : UiState<T>
    data class Error(val message: String, val retryable: Boolean = true) : UiState<Nothing>
}

@Immutable
data class UiError(val message: String, val retryable: Boolean)

sealed interface GuardResult<out T> {
    data class Done<T>(val value: T) : GuardResult<T>
    data object Rejected : GuardResult<Nothing>
    data class Failed(val error: Throwable) : GuardResult<Nothing>
}

/**
 * Single-flight guard per key. A second call with the same key is rejected while the first runs, and
 * the key is ALWAYS released (success, failure, timeout, cancellation), so a failed operation can
 * never leave a button permanently disabled.
 */
class ActionGuard {
    private val active = MutableStateFlow<Set<String>>(emptySet())
    val busyKeys: StateFlow<Set<String>> = active.asStateFlow()

    suspend fun <T> run(key: String, timeoutMs: Long = 30_000, block: suspend () -> T): GuardResult<T> {
        var acquired = false
        active.update {
            acquired = key !in it
            if (acquired) it + key else it
        }
        if (!acquired) return GuardResult.Rejected
        try {
            return GuardResult.Done(withTimeout(timeoutMs) { block() })
        } catch (e: TimeoutCancellationException) {
            return GuardResult.Failed(OperationTimeoutException(key, timeoutMs))
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            return GuardResult.Failed(e)
        } catch (e: Exception) {
            return GuardResult.Failed(e)
        } finally {
            active.update { it - key }
        }
    }
}

abstract class GuardedViewModel : ViewModel() {
    protected val guard = ActionGuard()
    val busy: StateFlow<Set<String>> = guard.busyKeys

    private val _error = MutableStateFlow<UiError?>(null)
    val error: StateFlow<UiError?> = _error.asStateFlow()

    fun dismissError() {
        _error.value = null
    }

    protected fun reportError(tag: String, e: Throwable) {
        CrashDiagnostics.recordNonFatal(tag, e)
        _error.value = UiError(ErrorMessages.userMessage(e), ErrorMessages.isRetryable(e))
    }

    /** Runs [block] under the single-flight guard; failures become a user-visible error, never a crash. */
    protected fun launchAction(key: String, timeoutMs: Long = 30_000, block: suspend () -> Unit) {
        viewModelScope.launch {
            val r = guard.run(key, timeoutMs, block)
            if (r is GuardResult.Failed) reportError(key, r.error)
        }
    }
}
