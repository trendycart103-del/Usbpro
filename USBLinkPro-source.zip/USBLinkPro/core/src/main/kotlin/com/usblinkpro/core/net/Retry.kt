package com.usblinkpro.core.net

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.io.IOException
import kotlin.random.Random

data class RetryPolicy(
    val baseMs: Long = 500,
    val maxMs: Long = 30_000,
    val maxAttempts: Int = 6,
    val jitterRatio: Double = 0.2
) {
    /** Exponential delay with +/- jitter, capped at [maxMs]. [attempt] is zero-based. */
    fun delayFor(attempt: Int, random: Random = Random.Default): Long {
        require(attempt >= 0) { "attempt must be >= 0" }
        val capped = minOf(maxMs, baseMs * (1L shl attempt.coerceAtMost(20)))
        val jitter = (capped * jitterRatio * (random.nextDouble() * 2 - 1)).toLong()
        return (capped + jitter).coerceIn(0, maxMs)
    }
}

suspend fun <T> retryWithBackoff(
    policy: RetryPolicy = RetryPolicy(),
    isRetryable: (Throwable) -> Boolean = { it is IOException },
    onRetry: (attempt: Int, error: Throwable, delayMs: Long) -> Unit = { _, _, _ -> },
    block: suspend (attempt: Int) -> T
): T {
    var attempt = 0
    while (true) {
        try {
            return block(attempt)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            attempt++
            if (!isRetryable(e) || attempt >= policy.maxAttempts) throw e
            val wait = policy.delayFor(attempt - 1)
            onRetry(attempt, e, wait)
            delay(wait)
        }
    }
}
