package com.usblinkpro.core.net

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Pings every [intervalMs]; after [maxMisses] consecutive failures/timeouts calls [onLost] once and stops. */
class HeartbeatMonitor(
    private val scope: CoroutineScope,
    private val intervalMs: Long = 5_000,
    private val timeoutMs: Long = 3_000,
    private val maxMisses: Int = 3,
    private val ping: suspend () -> Boolean,
    private val onLost: () -> Unit
) {
    private var job: Job? = null

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            var misses = 0
            while (isActive) {
                delay(intervalMs)
                val ok = try {
                    withTimeoutOrNull(timeoutMs) { ping() } ?: false
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    misses = 0
                } else if (++misses >= maxMisses) {
                    onLost()
                    return@launch
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
    }
}
