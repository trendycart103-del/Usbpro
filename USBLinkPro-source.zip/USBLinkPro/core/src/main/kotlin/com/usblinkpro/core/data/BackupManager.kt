package com.usblinkpro.core.data

import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** File-based backup/restore of the Room database. Backups contain no secrets (none are stored). */
class BackupManager(private val holder: DbHolder) {

    suspend fun backup(dest: File) = withContext(Dispatchers.IO) {
        val source = holder.dbFile ?: throw IOException("In-memory database cannot be backed up")
        val db = holder.get()
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").use { it.moveToFirst() }
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".tmp")
        try {
            source.inputStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (!tmp.renameTo(dest)) throw IOException("Could not finalize backup file")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    suspend fun restore(src: File) = withContext(Dispatchers.IO) {
        val target = holder.dbFile ?: throw IOException("In-memory database cannot be restored")
        validateBackup(src)
        holder.close()
        val safety = File(target.path + ".pre-restore")
        if (target.exists()) {
            safety.delete()
            if (!target.renameTo(safety)) throw IOException("Could not preserve current database")
        }
        for (suffix in listOf("-wal", "-shm", "-journal")) File(target.path + suffix).delete()
        try {
            src.inputStream().use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            holder.get() // reopen + verify now so failures surface here
        } catch (e: Exception) {
            holder.close()
            target.delete()
            if (safety.exists()) safety.renameTo(target)
            throw if (e is IOException) e else IOException("Restore failed: ${e.message}", e)
        }
    }

    private fun validateBackup(src: File) {
        if (!src.isFile || src.length() == 0L) throw IOException("Backup file missing or empty")
        val check = SQLiteDatabase.openDatabase(src.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            check.rawQuery("PRAGMA quick_check", null).use { c ->
                if (!c.moveToFirst() || c.getString(0) != "ok") throw IOException("Backup failed integrity check")
            }
            if (check.version !in 1..AppDatabase.VERSION) throw IOException("Backup schema version not supported")
        } finally {
            check.close()
        }
    }
}
