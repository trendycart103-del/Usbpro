package com.usblinkpro.core.ui

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.usblinkpro.core.Core
import com.usblinkpro.core.compat.CompatItem
import com.usblinkpro.core.compat.CompatibilityEngine
import com.usblinkpro.core.compat.DeviceSnapshotReader
import com.usblinkpro.core.data.AppDatabase
import com.usblinkpro.core.data.BackupManager
import com.usblinkpro.core.data.DbHolder
import com.usblinkpro.core.data.ExecutionLogEntity
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.data.LogRepository
import com.usblinkpro.core.data.Prefs
import com.usblinkpro.core.data.SettingsRepository
import com.usblinkpro.core.data.TaskEntity
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.data.TaskStore
import com.usblinkpro.core.transfer.ApkInstaller
import com.usblinkpro.core.transfer.ApkValidator
import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.ErrorMessages
import com.usblinkpro.core.util.TerminalBuffer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class TaskListViewModel(
    private val handle: SavedStateHandle,
    private val tasks: TaskStore
) : GuardedViewModel() {
    private val reload = MutableStateFlow(0)

    val showFinished: StateFlow<Boolean> = handle.getStateFlow(KEY_SHOW_FINISHED, true)

    val state: StateFlow<UiState<List<TaskEntity>>> =
        combine(showFinished, reload) { show, _ -> show }
            .flatMapLatest { show ->
                tasks.observeRecent(200)
                    .map<List<TaskEntity>, UiState<List<TaskEntity>>> { list ->
                        val visible = if (show) list else list.filter { !it.status.isTerminal }
                        if (visible.isEmpty()) UiState.Empty else UiState.Content(visible)
                    }
                    .catch { e ->
                        CrashDiagnostics.recordNonFatal("task_list", e)
                        emit(UiState.Error(ErrorMessages.userMessage(e), ErrorMessages.isRetryable(e)))
                    }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun setShowFinished(value: Boolean) {
        handle[KEY_SHOW_FINISHED] = value
    }

    fun retry() {
        reload.update { it + 1 }
    }

    fun cancel(taskId: String) = launchAction("cancel:$taskId") {
        tasks.transition(taskId, TaskStatus.CANCELLED)
    }

    /** The user confirms whether an interrupted non-idempotent command actually ran. Nothing is re-executed. */
    fun resolveVerification(taskId: String, executed: Boolean) = launchAction("verify:$taskId") {
        if (executed) tasks.transition(taskId, TaskStatus.COMPLETED, result = "Verified as executed")
        else tasks.transition(taskId, TaskStatus.FAILED, error = "Verified as not executed")
    }

    companion object {
        const val KEY_SHOW_FINISHED = "show_finished"
        val Factory = viewModelFactory {
            initializer { TaskListViewModel(createSavedStateHandle(), Core.get().tasks) }
        }
    }
}

data class LogState(
    val items: List<ExecutionLogEntity> = emptyList(),
    val loading: Boolean = false,
    val endReached: Boolean = false
)

class LogViewModel(private val logs: LogRepository) : GuardedViewModel() {
    private val _state = MutableStateFlow(LogState())
    val state: StateFlow<LogState> = _state.asStateFlow()

    init {
        loadMore()
    }

    fun refresh() {
        _state.value = LogState()
        loadMore()
    }

    fun loadMore() {
        val current = _state.value
        if (current.endReached) return
        launchAction("load_logs") {
            _state.update { it.copy(loading = true) }
            try {
                val before = current.items.lastOrNull()?.id ?: Long.MAX_VALUE
                val page = logs.page(before, PAGE_SIZE)
                _state.update {
                    val merged = it.items + page
                    it.copy(items = merged, endReached = page.size < PAGE_SIZE || merged.size >= MAX_ITEMS)
                }
            } finally {
                _state.update { it.copy(loading = false) }
            }
        }
    }

    companion object {
        const val PAGE_SIZE = 50
        const val MAX_ITEMS = 1_000
        val Factory = viewModelFactory { initializer { LogViewModel(Core.get().logs) } }
    }
}

class TerminalViewModel(terminal: TerminalBuffer) : GuardedViewModel() {
    val lines: StateFlow<List<String>> = terminal.version
        .map { terminal.snapshot() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), terminal.snapshot())

    companion object {
        val Factory = viewModelFactory { initializer { TerminalViewModel(Core.get().terminal) } }
    }
}

class CompatibilityViewModel(
    private val reader: DeviceSnapshotReader
) : GuardedViewModel() {
    private val _state = MutableStateFlow<UiState<List<CompatItem>>>(UiState.Loading)
    val state: StateFlow<UiState<List<CompatItem>>> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            val r = guard.run("compat", 10_000) {
                withContext(Dispatchers.Default) { CompatibilityEngine.evaluate(reader.read()) }
            }
            _state.value = when (r) {
                is GuardResult.Done -> if (r.value.isEmpty()) UiState.Empty else UiState.Content(r.value)
                is GuardResult.Failed -> {
                    CrashDiagnostics.recordNonFatal("compat", r.error)
                    UiState.Error(ErrorMessages.userMessage(r.error))
                }
                GuardResult.Rejected -> _state.value
            }
        }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                val core = Core.get()
                CompatibilityViewModel(DeviceSnapshotReader(core.context, core.installRequired))
            }
        }
    }
}

class SettingsViewModel(
    private val settings: SettingsRepository,
    private val backup: BackupManager,
    private val holder: DbHolder,
    private val backupDir: File
) : GuardedViewModel() {
    val reducedMotion: StateFlow<Boolean> = settings.observeBoolean(Prefs.REDUCED_MOTION, false)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _crashCount = MutableStateFlow(0)
    val crashCount: StateFlow<Int> = _crashCount.asStateFlow()

    init {
        refreshCrashCount()
    }

    fun setMessage(text: String?) {
        _message.value = text
    }

    fun recoveredFromCorruption(): Boolean = holder.recoveredFromCorruption

    fun setReducedMotion(value: Boolean) = launchAction("reduced_motion") {
        settings.setBoolean(Prefs.REDUCED_MOTION, value)
    }

    fun backup() = launchAction("backup", timeoutMs = 60_000) {
        val file = File(backupDir, "usblinkpro-${System.currentTimeMillis()}.db")
        backup.backup(file)
        withContext(Dispatchers.IO) {
            backupDir.listFiles { f -> f.name.endsWith(".db") }?.sortedByDescending { it.name }?.drop(5)?.forEach { it.delete() }
        }
        _message.value = "Backup saved: ${file.name}"
    }

    fun restore() = launchAction("restore", timeoutMs = 60_000) {
        val latest = withContext(Dispatchers.IO) {
            backupDir.listFiles { f -> f.name.endsWith(".db") }?.maxByOrNull { it.name }
        }
        if (latest == null) {
            _message.value = "No backup found."
        } else {
            backup.restore(latest)
            _message.value = "Restored ${latest.name}."
        }
    }

    fun clearCrashReports() {
        viewModelScope.launch(Dispatchers.IO) {
            CrashDiagnostics.clear()
            refreshCrashCount()
        }
    }

    private fun refreshCrashCount() {
        viewModelScope.launch(Dispatchers.IO) { _crashCount.value = CrashDiagnostics.reports().size }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                val c = Core.get()
                SettingsViewModel(c.settings, c.backup, c.holder, c.backupDir)
            }
        }
    }
}

class ReceivedFilesViewModel(
    private val receivedDir: File,
    private val validator: ApkValidator,
    private val installer: ApkInstaller,
    private val logs: LogRepository
) : GuardedViewModel() {
    private val _state = MutableStateFlow<UiState<List<File>>>(UiState.Loading)
    val state: StateFlow<UiState<List<File>>> = _state.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
    }

    fun canInstall(): Boolean = installer.canInstall()
    fun setMessage(text: String?) {
        _message.value = text
    }

    fun refresh() {
        viewModelScope.launch {
            val r = guard.run("list_files", 10_000) {
                withContext(Dispatchers.IO) {
                    receivedDir.listFiles { f -> f.isFile && f.name.endsWith(".apk") }?.sortedByDescending { it.lastModified() } ?: emptyList()
                }
            }
            _state.value = when (r) {
                is GuardResult.Done -> if (r.value.isEmpty()) UiState.Empty else UiState.Content(r.value)
                is GuardResult.Failed -> UiState.Error(ErrorMessages.userMessage(r.error))
                GuardResult.Rejected -> _state.value
            }
        }
    }

    /** Validates the APK, then hands it to the system installer, which asks the user to confirm. */
    fun install(file: File) = launchAction("install:${file.name}", timeoutMs = 120_000) {
        val info = validator.validate(file)
        logs.append(LogLevel.INFO, "Installing ${info.packageName} v${info.versionName} (${info.sizeBytes} bytes)")
        installer.install(file)
        _message.value = "Waiting for system confirmation for ${info.packageName}."
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                val c = Core.get()
                ReceivedFilesViewModel(c.receivedDir, c.apkValidator, c.apkInstaller, c.logs)
            }
        }
    }
}
