package com.usblinkpro.core.work

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.usblinkpro.core.Core
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.StorageCleaner
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/** Moves interrupted tasks into a safe state after a restart. It never re-executes anything. */
class TaskRestoreWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val core = Core.from(applicationContext)
        val report = core.tasks.restoreIncomplete()
        core.logs.append(
            LogLevel.INFO,
            "Task restore: resumable=${report.resumable} needsVerification=${report.needsVerification} failed=${report.failed}"
        )
        Result.success()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        CrashDiagnostics.recordNonFatal("task_restore", e)
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}

/** Daily log rotation, task/transfer metadata purge and stale-file cleanup. */
class MaintenanceWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val core = Core.from(applicationContext)
        val day = 24L * 3600 * 1000
        core.logs.rotate()
        core.logs.trimHistory()
        core.tasks.purgeTerminal(30 * day)
        core.transfers.purgeTerminal(System.currentTimeMillis() - 30 * day)
        StorageCleaner.cleanOlderThan(core.partDir, 7 * day, ".part")
        StorageCleaner.cleanOlderThan(core.receivedDir, 30 * day)
        Result.success()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        CrashDiagnostics.recordNonFatal("maintenance", e)
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    }
}

object Workers {
    const val RESTORE = "task_restore"
    const val MAINTENANCE = "maintenance"

    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context)
        wm.enqueueUniqueWork(
            RESTORE, ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<TaskRestoreWorker>().setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).build()
        )
        wm.enqueueUniquePeriodicWork(
            MAINTENANCE, ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<MaintenanceWorker>(1, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
        )
    }
}
