package com.usblinkpro.core.data

import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.LogSanitizer
import com.usblinkpro.core.util.runCatchingCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class LogRepository(
    private val holder: DbHolder,
    private val clock: () -> Long = System::currentTimeMillis
) : AuditLog {

    /** Logging must never crash a feature: failures are recorded as non-fatal diagnostics only. */
    override suspend fun log(level: LogLevel, message: String, taskId: String?) {
        runCatchingCancellable {
            holder.get().logDao().insert(
                ExecutionLogEntity(
                    taskId = taskId, timestamp = clock(), level = level.name,
                    message = LogSanitizer.redact(message).take(MAX_MESSAGE)
                )
            )
        }.onFailure { CrashDiagnostics.recordNonFatal("log_append", it) }
    }

    suspend fun append(level: LogLevel, message: String, taskId: String? = null) = log(level, message, taskId)

    override suspend fun command(commandId: String, taskId: String?, outcome: String) {
        runCatchingCancellable {
            holder.get().commandHistoryDao().insert(
                CommandHistoryEntity(
                    commandId = commandId.take(64), taskId = taskId, timestamp = clock(),
                    outcome = LogSanitizer.redact(outcome).take(200)
                )
            )
        }.onFailure { CrashDiagnostics.recordNonFatal("history_append", it) }
    }

    suspend fun page(beforeId: Long = Long.MAX_VALUE, limit: Int = 50): List<ExecutionLogEntity> =
        holder.get().logDao().page(beforeId, limit.coerceIn(1, 200))

    suspend fun rotate(maxRows: Int = 5000, maxAgeMs: Long = 14L * 24 * 3600 * 1000) {
        val dao = holder.get().logDao()
        dao.deleteBefore(clock() - maxAgeMs)
        dao.trimToCount(maxRows)
    }

    suspend fun trimHistory(keep: Int = 1000) {
        holder.get().commandHistoryDao().trimToCount(keep)
    }

    companion object {
        const val MAX_MESSAGE = 2000
    }
}

object Prefs {
    const val REDUCED_MOTION = "reduced_motion"
}

class SettingsRepository(private val holder: DbHolder) {
    suspend fun getBoolean(key: String, default: Boolean): Boolean =
        holder.get().preferenceDao().get(key)?.toBooleanStrictOrNull() ?: default

    suspend fun setBoolean(key: String, value: Boolean) {
        holder.get().preferenceDao().upsert(PreferenceEntity(key, value.toString()))
    }

    fun observeBoolean(key: String, default: Boolean): Flow<Boolean> =
        flow { emitAll(holder.get().preferenceDao().observe(key)) }
            .map { it?.toBooleanStrictOrNull() ?: default }
            .distinctUntilChanged()
            .catch { CrashDiagnostics.recordNonFatal("pref_observe", it); emit(default) }
}

class TransferRepository(
    private val holder: DbHolder
) : TransferStore {
    override suspend fun upsert(meta: TransferMetaEntity) = holder.get().transferDao().upsert(meta)

    override suspend fun findCompletedBySha(sha: String): TransferMetaEntity? =
        holder.get().transferDao().findCompleted(sha.lowercase())

    override suspend fun updateProgress(id: String, committed: Long, status: TransferStatus, now: Long) {
        holder.get().transferDao().updateProgress(id, committed, status, now)
    }

    suspend fun get(id: String): TransferMetaEntity? = holder.get().transferDao().get(id)
    suspend fun resumable(): List<TransferMetaEntity> = holder.get().transferDao().resumable()
    suspend fun purgeTerminal(before: Long): Int = holder.get().transferDao().deleteTerminalBefore(before)
}

class PairingRepository(private val holder: DbHolder) {
    suspend fun upsert(p: PairingEntity) = holder.get().pairingDao().upsert(p)
    suspend fun all(): List<PairingEntity> = holder.get().pairingDao().all()
    suspend fun delete(deviceId: String) = holder.get().pairingDao().delete(deviceId)
}
