package com.usblinkpro.core.transfer

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import com.usblinkpro.core.util.ApkValidationException
import com.usblinkpro.core.util.Hashing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

data class ApkInfo(
    val packageName: String,
    val versionCode: Long,
    val versionName: String?,
    val sizeBytes: Long,
    val sha256: String
)

class ApkValidator(private val context: Context, private val maxBytes: Long = 500L shl 20) {

    suspend fun validate(file: File, expectedSha256: String? = null, expectedPackage: String? = null): ApkInfo {
        val size = withContext(Dispatchers.IO) {
            if (!file.isFile || !file.canRead()) throw ApkValidationException("APK file not found")
            val len = file.length()
            if (len <= 0 || len > maxBytes) throw ApkValidationException("APK size is outside the allowed range")
            val magic = ByteArray(4)
            val read = FileInputStream(file).use { it.read(magic) }
            if (read != 4 || magic[0] != 'P'.code.toByte() || magic[1] != 'K'.code.toByte() ||
                magic[2] != 3.toByte() || magic[3] != 4.toByte()
            ) {
                throw ApkValidationException("File is not a ZIP/APK archive")
            }
            len
        }
        val sha = Hashing.sha256(file)
        if (expectedSha256 != null && !sha.equals(expectedSha256, ignoreCase = true)) {
            throw ApkValidationException("APK checksum does not match")
        }
        return withContext(Dispatchers.IO) {
            val info = try {
                context.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
            } catch (e: Exception) {
                null
            } ?: throw ApkValidationException("APK could not be parsed")
            if (expectedPackage != null && info.packageName != expectedPackage) {
                throw ApkValidationException("APK package name does not match the expected package")
            }
            ApkInfo(info.packageName, PackageInfoCompat.getLongVersionCode(info), info.versionName, size, sha)
        }
    }
}
