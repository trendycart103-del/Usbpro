package com.usblinkpro.core.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.usblinkpro.core.Core
import com.usblinkpro.core.util.CrashDiagnostics
import com.usblinkpro.core.util.Notifications
import com.usblinkpro.core.util.diagnosticsExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * User-visible foreground service (type dataSync) that exists only while tasks are RUNNING or
 * WAITING_NETWORK. It stops itself shortly after the last active task ends; it is never sticky.
 * Start it only from a user-initiated action while the app is visible.
 */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + diagnosticsExceptionHandler("transfer_service"))
    private var observeJob: Job? = null
    @Volatile private var lastStartId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        Notifications.ensureChannels(this)
        try {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID,
                Notifications.progress(this, "USB Link Pro", "Working…", -1),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } catch (e: Exception) {
            // ForegroundServiceStartNotAllowedException (Android 12+) or SecurityException (missing permission/type)
            CrashDiagnostics.recordNonFatal("fgs_start", e)
            stopSelf()
            return START_NOT_STICKY
        }
        observeJob?.cancel()
        observeJob = scope.launch {
            Core.from(applicationContext).tasks.observeActive().collectLatest { active ->
                if (active.isEmpty()) {
                    delay(STOP_GRACE_MS)
                    ServiceCompat.stopForeground(this@TransferService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf(lastStartId)
                } else {
                    val avg = active.sumOf { it.progress } / active.size
                    runCatching {
                        NotificationManagerCompat.from(this@TransferService).notify(
                            NOTIFICATION_ID,
                            Notifications.progress(this@TransferService, "USB Link Pro", "${active.size} task(s) running", avg)
                        )
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    /** Android 15+ limits dataSync foreground services; stop cleanly when the system says time is up. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 1001
        private const val STOP_GRACE_MS = 3_000L

        /** Call only from a user-initiated action while the app is in the foreground. */
        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, TransferService::class.java))
            } catch (e: Exception) {
                CrashDiagnostics.recordNonFatal("fgs_request", e)
            }
        }
    }
}
