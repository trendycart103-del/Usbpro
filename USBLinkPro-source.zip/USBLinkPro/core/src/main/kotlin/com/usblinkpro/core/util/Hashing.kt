package com.usblinkpro.core.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.security.MessageDigest

object Hashing {
    private const val BUFFER = 64 * 1024

    fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun emptySha256(): String = hex(MessageDigest.getInstance("SHA-256").digest())

    /** SHA-256 of the first [limit] bytes of [file]; cancellable; runs on Dispatchers.IO. */
    suspend fun sha256(file: File, limit: Long = file.length()): String = withContext(Dispatchers.IO) {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(BUFFER)
        var remaining = limit
        FileInputStream(file).use { input ->
            while (remaining > 0) {
                ensureActive()
                val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n < 0) break
                md.update(buf, 0, n)
                remaining -= n
            }
        }
        if (remaining > 0) throw IOException("File shorter than expected")
        hex(md.digest())
    }
}
