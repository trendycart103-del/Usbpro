package com.usblinkpro.core.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.usblinkpro.core.util.UsbTransferException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface UsbEvent {
    data class Attached(val device: UsbDevice) : UsbEvent
    data class Detached(val deviceName: String) : UsbEvent
    data class PermissionResult(val deviceName: String, val granted: Boolean) : UsbEvent
}

/**
 * Call [start] when the owning screen/service becomes active and [stop] when it ends. Detach of the
 * open device closes the session immediately. Permission is only requested via [requestPermission],
 * which the UI must call from an explicit user action.
 */
class UsbSessionManager(context: Context) {
    private val appContext = context.applicationContext
    private val usb: UsbManager? = appContext.getSystemService(UsbManager::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _events = MutableSharedFlow<UsbEvent>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val events: SharedFlow<UsbEvent> = _events.asSharedFlow()

    private val lock = Any()
    private var session: UsbSession? = null
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val device = IntentCompat.getParcelableExtra(intent, UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> device?.let { _events.tryEmit(UsbEvent.Attached(it)) }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> device?.let { d ->
                    scope.launch { closeIfDevice(d.deviceName) }
                    _events.tryEmit(UsbEvent.Detached(d.deviceName))
                }
                ACTION_PERMISSION -> device?.let {
                    _events.tryEmit(
                        UsbEvent.PermissionResult(it.deviceName, intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                    )
                }
            }
        }
    }

    fun start() {
        synchronized(lock) {
            if (registered) return
            val filter = IntentFilter().apply {
                addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
                addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
                addAction(ACTION_PERMISSION)
            }
            ContextCompat.registerReceiver(appContext, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
    }

    fun stop() {
        synchronized(lock) {
            if (registered) {
                runCatching { appContext.unregisterReceiver(receiver) }
                registered = false
            }
            session?.close()
            session = null
        }
    }

    /** Releases the receiver and cancels the manager's coroutines. Call once when it is no longer needed. */
    fun destroy() {
        stop()
        scope.cancel()
    }

    fun devices(): List<UsbDevice> = usb?.deviceList?.values?.toList() ?: emptyList()

    fun hasPermission(device: UsbDevice): Boolean = usb?.hasPermission(device) == true

    /** Must be called from a user-initiated action. The result arrives as [UsbEvent.PermissionResult]. */
    fun requestPermission(device: UsbDevice) {
        val manager = usb ?: return
        val intent = Intent(ACTION_PERMISSION).setPackage(appContext.packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        manager.requestPermission(device, PendingIntent.getBroadcast(appContext, 0, intent, flags))
    }

    suspend fun open(device: UsbDevice): UsbSession = withContext(Dispatchers.IO) {
        val manager = usb ?: throw UsbTransferException("USB service unavailable")
        synchronized(lock) { session?.close(); session = null }
        val target = UsbCapabilities.findBulkOutTarget(device) ?: throw UsbTransferException("No bulk OUT endpoint found")
        val opened = openSession(device.deviceName, manager.hasPermission(device), target.outEndpointAddress) {
            manager.openDevice(device)?.let { AndroidUsbLink.claim(it, target.usbInterface) }
        }
        synchronized(lock) { session = opened }
        opened
    }

    fun closeSession() {
        synchronized(lock) { session?.close(); session = null }
    }

    private fun closeIfDevice(name: String) {
        synchronized(lock) {
            if (session?.deviceName == name) {
                session?.close()
                session = null
            }
        }
    }

    companion object {
        const val ACTION_PERMISSION = "com.usblinkpro.USB_PERMISSION"
    }
}
