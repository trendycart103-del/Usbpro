package com.usblinkpro.core.transfer

import com.usblinkpro.core.data.TransferMetaEntity

data class TransferHeader(
    val transferId: String,
    val fileName: String,
    val totalBytes: Long,
    val sha256: String,
    val chunkSize: Int
)

/** [offset] bytes are already stored by the receiver; [prefixSha256] is the SHA-256 of those bytes. */
data class ResumeState(val offset: Long, val prefixSha256: String)

/** Transport-agnostic receiving side of a chunked transfer. */
interface ChunkSink {
    suspend fun begin(header: TransferHeader): ResumeState
    suspend fun write(offset: Long, buf: ByteArray, len: Int)
    suspend fun reset()
    suspend fun finish()
}

sealed interface TransferOutcome {
    data class Completed(val sha256: String) : TransferOutcome
    data class Duplicate(val existing: TransferMetaEntity) : TransferOutcome
}
