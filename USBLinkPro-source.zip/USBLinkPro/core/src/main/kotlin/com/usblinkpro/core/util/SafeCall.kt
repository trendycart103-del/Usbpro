package com.usblinkpro.core.util

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

/** Like runCatching, but never swallows coroutine cancellation. */
suspend inline fun <T> runCatchingCancellable(block: () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

/** withTimeout that reports expiry as a retryable IOException instead of a CancellationException. */
suspend fun <T> withNetworkTimeout(timeoutMs: Long, block: suspend () -> T): T =
    try {
        withTimeout(timeoutMs) { block() }
    } catch (e: TimeoutCancellationException) {
        throw NetworkTimeoutException(timeoutMs, e)
    }

fun diagnosticsExceptionHandler(tag: String) = CoroutineExceptionHandler { _, e ->
    CrashDiagnostics.recordNonFatal(tag, e)
}
