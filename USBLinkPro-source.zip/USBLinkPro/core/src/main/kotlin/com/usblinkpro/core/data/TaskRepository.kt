package com.usblinkpro.core.data

import androidx.room.withTransaction
import com.usblinkpro.core.util.LogSanitizer
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import java.util.UUID

class TaskNotFoundException(id: String) : Exception("Task not found: $id")

class IllegalTaskTransitionException(val from: TaskStatus, val to: TaskStatus) :
    IllegalStateException("Illegal task transition $from -> $to")

object TaskTransitions {
    private val allowed: Map<TaskStatus, Set<TaskStatus>> = mapOf(
        TaskStatus.PENDING to setOf(TaskStatus.RUNNING, TaskStatus.FAILED, TaskStatus.CANCELLED),
        TaskStatus.RUNNING to setOf(
            TaskStatus.PENDING, TaskStatus.WAITING_NETWORK, TaskStatus.NEEDS_VERIFICATION,
            TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED
        ),
        TaskStatus.WAITING_NETWORK to setOf(
            TaskStatus.PENDING, TaskStatus.RUNNING, TaskStatus.NEEDS_VERIFICATION,
            TaskStatus.FAILED, TaskStatus.CANCELLED
        ),
        TaskStatus.NEEDS_VERIFICATION to setOf(
            TaskStatus.PENDING, TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED
        ),
        TaskStatus.COMPLETED to emptySet(),
        TaskStatus.FAILED to emptySet(),
        TaskStatus.CANCELLED to emptySet()
    )

    fun isAllowed(from: TaskStatus, to: TaskStatus): Boolean = allowed[from]?.contains(to) == true
}

data class RestoreReport(val resumable: Int, val needsVerification: Int, val failed: Int)

class TaskRepository(
    private val holder: DbHolder,
    private val clock: () -> Long = System::currentTimeMillis
) : TaskStore {

    override suspend fun create(type: String, idempotent: Boolean, sessionId: String?): TaskEntity {
        val now = clock()
        val task = TaskEntity(
            taskId = UUID.randomUUID().toString(), type = type, status = TaskStatus.PENDING,
            startTime = now, lastUpdate = now, progress = 0, retryCount = 0,
            errorInfo = null, result = null, idempotent = idempotent, sessionId = sessionId
        )
        holder.get().taskDao().insert(task)
        return task
    }

    override suspend fun transition(
        id: String, to: TaskStatus, error: String?, result: String?, incrementRetry: Boolean
    ): TaskEntity {
        val db = holder.get()
        return db.withTransaction {
            val cur = db.taskDao().get(id) ?: throw TaskNotFoundException(id)
            if (!TaskTransitions.isAllowed(cur.status, to)) throw IllegalTaskTransitionException(cur.status, to)
            val updated = cur.copy(
                status = to,
                lastUpdate = clock(),
                progress = if (to == TaskStatus.COMPLETED) 100 else cur.progress,
                retryCount = cur.retryCount + if (incrementRetry) 1 else 0,
                errorInfo = error?.let { LogSanitizer.redact(it).take(500) }
                    ?: if (to == TaskStatus.COMPLETED) null else cur.errorInfo,
                result = result?.let { LogSanitizer.redact(it).take(500) } ?: cur.result
            )
            db.taskDao().update(updated)
            updated
        }
    }

    override fun observeRecent(limit: Int): Flow<List<TaskEntity>> =
        flow { emitAll(holder.get().taskDao().observeRecent(limit)) }

    fun observeActive(): Flow<List<TaskEntity>> =
        flow { emitAll(holder.get().taskDao().observeActive()) }

    suspend fun get(id: String): TaskEntity? = holder.get().taskDao().get(id)

    /** Progress writes are ignored unless the task is RUNNING. Callers should throttle. */
    suspend fun updateProgress(id: String, progress: Int) {
        holder.get().taskDao().setProgress(id, progress.coerceIn(0, 100), clock())
    }

    /**
     * Called after process start / reboot. Nothing is re-executed here; tasks are only moved to a
     * state from which a user or a verified-idempotent resume can continue:
     *  - session-bound work never survives a restart (stale commands are never replayed);
     *  - unbound idempotent work returns to PENDING;
     *  - non-idempotent work that was in flight becomes NEEDS_VERIFICATION.
     */
    suspend fun restoreIncomplete(): RestoreReport {
        val db = holder.get()
        var resumable = 0
        var verify = 0
        var failed = 0
        db.withTransaction {
            val now = clock()
            for (t in db.taskDao().incomplete()) {
                val inFlight = t.status == TaskStatus.RUNNING || t.status == TaskStatus.WAITING_NETWORK
                val bound = t.sessionId != null
                val next: Pair<TaskStatus, String?>? = when {
                    t.status == TaskStatus.NEEDS_VERIFICATION -> null
                    bound && t.status == TaskStatus.PENDING -> TaskStatus.FAILED to "Session expired before execution"
                    bound && inFlight && t.idempotent -> TaskStatus.FAILED to "Session lost"
                    inFlight && !t.idempotent -> TaskStatus.NEEDS_VERIFICATION to "Interrupted; result must be verified"
                    inFlight -> TaskStatus.PENDING to null
                    else -> null
                }
                if (next != null) {
                    db.taskDao().update(
                        t.copy(status = next.first, lastUpdate = now, errorInfo = next.second ?: t.errorInfo)
                    )
                    when (next.first) {
                        TaskStatus.PENDING -> resumable++
                        TaskStatus.NEEDS_VERIFICATION -> verify++
                        else -> failed++
                    }
                }
            }
        }
        return RestoreReport(resumable, verify, failed)
    }

    suspend fun purgeTerminal(maxAgeMs: Long): Int =
        holder.get().taskDao().deleteTerminalBefore(clock() - maxAgeMs)
}
