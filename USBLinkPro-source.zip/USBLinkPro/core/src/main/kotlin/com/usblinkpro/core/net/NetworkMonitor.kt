package com.usblinkpro.core.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

data class NetworkState(val connected: Boolean, val isWifi: Boolean)

/** Emits on connectivity or transport (Wi-Fi/other) changes. Unregisters its callback when collection stops. */
class NetworkMonitor(context: Context) {
    private val cm: ConnectivityManager? = context.getSystemService(ConnectivityManager::class.java)

    val states: Flow<NetworkState> = callbackFlow {
        val manager = cm
        if (manager == null) {
            trySend(NetworkState(connected = false, isWifi = false))
            awaitClose { }
            return@callbackFlow
        }
        val initialCaps = manager.activeNetwork?.let { manager.getNetworkCapabilities(it) }
        trySend(NetworkState(initialCaps != null, initialCaps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true))

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val caps = manager.getNetworkCapabilities(network)
                trySend(NetworkState(true, caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true))
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                trySend(NetworkState(true, caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)))
            }

            override fun onLost(network: Network) {
                trySend(NetworkState(false, false))
            }
        }
        try {
            manager.registerDefaultNetworkCallback(callback)
        } catch (e: SecurityException) {
            close(e)
            return@callbackFlow
        }
        awaitClose { runCatching { manager.unregisterNetworkCallback(callback) } }
    }.distinctUntilChanged()
}
