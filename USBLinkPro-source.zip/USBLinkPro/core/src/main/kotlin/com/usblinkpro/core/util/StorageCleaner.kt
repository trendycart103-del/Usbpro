package com.usblinkpro.core.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object StorageCleaner {
    /** Deletes regular files in [dir] whose last-modified time is older than [maxAgeMs]. Returns the count deleted. */
    suspend fun cleanOlderThan(
        dir: File,
        maxAgeMs: Long,
        suffix: String? = null,
        now: Long = System.currentTimeMillis()
    ): Int = withContext(Dispatchers.IO) {
        var deleted = 0
        dir.listFiles { f -> f.isFile && (suffix == null || f.name.endsWith(suffix)) }?.forEach { f ->
            if (now - f.lastModified() > maxAgeMs && f.delete()) deleted++
        }
        deleted
    }
}
