package com.usblinkpro.core.util

/** Removes passwords, OTPs and tokens from any text before it is logged or persisted. */
object LogSanitizer {
    private const val MASK = "[REDACTED]"

    private val keyValue = Regex(
        "(?i)\\b(password|passwd|pwd|otp|pin|token|secret|api[_-]?key|authorization|auth)\\b([\"']?\\s*[:=]\\s*[\"']?)(bearer\\s+)?([^\\s,;\"'}&]+)"
    )
    private val bearer = Regex("(?i)\\bbearer\\s+[A-Za-z0-9._~+/=-]+")

    fun redact(text: String): String {
        var out = keyValue.replace(text) { m -> m.groupValues[1] + m.groupValues[2] + MASK }
        out = bearer.replace(out, "Bearer $MASK")
        return out
    }
}
