package com.usblinkpro.core.transfer

import com.usblinkpro.core.util.ChecksumMismatchException
import com.usblinkpro.core.util.Hashing
import com.usblinkpro.core.util.InputValidator
import com.usblinkpro.core.util.InsufficientStorageException
import com.usblinkpro.core.util.TransferProtocolException
import com.usblinkpro.core.util.ValidationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Writes chunks sequentially to <transferId>.part, supports resume from the existing part file,
 * verifies size and SHA-256 on finish and only then moves the file into [finalDir].
 */
class ChunkReceiver(
    private val partDir: File,
    private val finalDir: File,
    private val maxBytes: Long = 2L shl 30,
    private val freeSpace: (File) -> Long = { it.usableSpace },
    private val marginBytes: Long = 8L shl 20
) : ChunkSink, Closeable {
    private val mutex = Mutex()
    private var header: TransferHeader? = null
    private var raf: RandomAccessFile? = null
    private var written = 0L

    @Volatile var finalFile: File? = null
        private set

    private val idPattern = Regex("[A-Za-z0-9-]{8,64}")
    private val shaPattern = Regex("[0-9a-fA-F]{64}")

    private fun validate(h: TransferHeader) {
        if (!idPattern.matches(h.transferId)) throw ValidationException("Invalid transfer id")
        InputValidator.fileName(h.fileName)
        if (!shaPattern.matches(h.sha256)) throw ValidationException("Invalid SHA-256")
        if (h.totalBytes !in 1..maxBytes) throw ValidationException("File size out of allowed range")
        if (h.chunkSize !in 4096..(4 shl 20)) throw ValidationException("Invalid chunk size")
    }

    private fun partFile(h: TransferHeader) = File(partDir, "${h.transferId}.part")

    override suspend fun begin(header: TransferHeader): ResumeState = mutex.withLock {
        withContext(Dispatchers.IO) {
            validate(header)
            if (!(partDir.isDirectory || partDir.mkdirs()) || !(finalDir.isDirectory || finalDir.mkdirs())) {
                throw IOException("Cannot create transfer directories")
            }
            closeRaf()
            val part = partFile(header)
            var existing = if (part.exists()) part.length() else 0L
            if (existing > header.totalBytes) {
                part.delete()
                existing = 0L
            }
            val needed = header.totalBytes - existing + marginBytes
            val available = freeSpace(partDir)
            if (available < needed) throw InsufficientStorageException(needed, available)
            val prefix = if (existing > 0) Hashing.sha256(part, existing) else Hashing.emptySha256()
            raf = RandomAccessFile(part, "rw")
            written = existing
            this@ChunkReceiver.header = header
            finalFile = null
            ResumeState(existing, prefix)
        }
    }

    override suspend fun write(offset: Long, buf: ByteArray, len: Int) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val r = raf ?: throw TransferProtocolException("begin() was not called")
            val h = header ?: throw TransferProtocolException("begin() was not called")
            if (offset != written) throw TransferProtocolException("Out-of-order chunk: expected $written, got $offset")
            if (len <= 0 || len > buf.size || written + len > h.totalBytes) throw TransferProtocolException("Invalid chunk length")
            r.seek(offset)
            r.write(buf, 0, len)
            written += len
        }
    }

    override suspend fun reset() = mutex.withLock {
        withContext(Dispatchers.IO) {
            val h = header ?: throw TransferProtocolException("begin() was not called")
            closeRaf()
            val part = partFile(h)
            part.delete()
            raf = RandomAccessFile(part, "rw")
            written = 0L
        }
    }

    override suspend fun finish() = mutex.withLock {
        withContext(Dispatchers.IO) {
            val h = header ?: throw TransferProtocolException("begin() was not called")
            val r = raf ?: throw TransferProtocolException("begin() was not called")
            if (written != h.totalBytes) throw TransferProtocolException("Incomplete transfer: $written/${h.totalBytes} bytes")
            r.fd.sync()
            closeRaf()
            val part = partFile(h)
            val actual = Hashing.sha256(part)
            if (!actual.equals(h.sha256, ignoreCase = true)) {
                part.delete()
                throw ChecksumMismatchException(h.sha256, actual)
            }
            val dest = File(finalDir, "${h.sha256.take(8)}-${h.fileName}")
            try {
                Files.move(part.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE)
            } catch (e: AtomicMoveNotSupportedException) {
                Files.move(part.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
            finalFile = dest
        }
    }

    private fun closeRaf() {
        runCatching { raf?.close() }
        raf = null
    }

    override fun close() = closeRaf()
}
