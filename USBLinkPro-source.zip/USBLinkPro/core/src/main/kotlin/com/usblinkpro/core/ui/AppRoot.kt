package com.usblinkpro.core.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.usblinkpro.core.Core
import com.usblinkpro.core.data.Prefs

private data class Dest(val route: String, val label: String)

/** Ignores navigation requests that arrive while the current entry is not RESUMED (double taps, transitions). */
fun NavController.safeNavigate(route: String) {
    val state = currentBackStackEntry?.lifecycle?.currentState ?: return
    if (!state.isAtLeast(Lifecycle.State.RESUMED)) return
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AppRoot(title: String) {
    val core = remember { Core.get() }
    val nav = rememberNavController()
    val reduced by core.settings.observeBoolean(Prefs.REDUCED_MOTION, false)
        .collectAsStateWithLifecycle(initialValue = false)
    val destinations = remember(core.installRequired) {
        buildList {
            add(Dest("tasks", "Tasks"))
            if (core.installRequired) add(Dest("files", "Files"))
            add(Dest("logs", "Logs"))
            add(Dest("terminal", "Terminal"))
            add(Dest("compat", "Device"))
            add(Dest("settings", "Settings"))
        }
    }
    CompositionLocalProvider(LocalReducedMotion provides reduced) {
        MaterialTheme {
            Scaffold(
                topBar = {
                    Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp).semantics { heading() })
                },
                bottomBar = {
                    val entry by nav.currentBackStackEntryAsState()
                    val current = entry?.destination?.route
                    NavigationBar {
                        destinations.forEach { d ->
                            NavigationBarItem(
                                selected = current == d.route,
                                onClick = { nav.safeNavigate(d.route) },
                                icon = { Text(d.label.take(1)) },
                                label = { Text(d.label) }
                            )
                        }
                    }
                }
            ) { padding ->
                NavHost(
                    navController = nav,
                    startDestination = "tasks",
                    modifier = Modifier.padding(padding),
                    enterTransition = { if (reduced) EnterTransition.None else fadeIn(motionSpec(false)) },
                    exitTransition = { if (reduced) ExitTransition.None else fadeOut(motionSpec(false)) },
                    popEnterTransition = { if (reduced) EnterTransition.None else fadeIn(motionSpec(false)) },
                    popExitTransition = { if (reduced) ExitTransition.None else fadeOut(motionSpec(false)) }
                ) {
                    composable("tasks") { TaskListScreen() }
                    if (core.installRequired) composable("files") { ReceivedFilesScreen() }
                    composable("logs") { LogScreen() }
                    composable("terminal") { TerminalScreen() }
                    composable("compat") { CompatibilityScreen() }
                    composable("settings") { SettingsScreen() }
                }
            }
        }
    }
}
