package com.usblinkpro.core.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TaskStatus {
    PENDING, RUNNING, WAITING_NETWORK, NEEDS_VERIFICATION, COMPLETED, FAILED, CANCELLED;

    val isTerminal: Boolean get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

enum class TransferStatus { IN_PROGRESS, COMPLETED, FAILED, CANCELLED }

enum class LogLevel { DEBUG, INFO, WARN, ERROR }

@Entity(tableName = "tasks", indices = [Index("status"), Index("startTime")])
data class TaskEntity(
    @PrimaryKey val taskId: String,
    val type: String,
    val status: TaskStatus,
    val startTime: Long,
    val lastUpdate: Long,
    val progress: Int,
    val retryCount: Int,
    val errorInfo: String?,
    val result: String?,
    /** False => never re-executed automatically after an interruption; needs verification first. */
    val idempotent: Boolean,
    /** Non-null only for work bound to a live connection session. Such work never survives a restart. */
    val sessionId: String?
)

@Entity(tableName = "command_history", indices = [Index("timestamp")])
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commandId: String,
    val taskId: String?,
    val timestamp: Long,
    val outcome: String
)

@Entity(tableName = "execution_logs", indices = [Index("timestamp")])
data class ExecutionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: String?,
    val timestamp: Long,
    val level: String,
    val message: String
)

@Entity(tableName = "transfer_meta", indices = [Index("sha256"), Index("status")])
data class TransferMetaEntity(
    @PrimaryKey val transferId: String,
    val fileName: String,
    val totalBytes: Long,
    val committedBytes: Long,
    val sha256: String,
    val chunkSize: Int,
    val status: TransferStatus,
    val updatedAt: Long,
    val taskId: String?
)

/** Pairing metadata only. Secrets, OTPs and tokens are never persisted here. */
@Entity(tableName = "pairings")
data class PairingEntity(
    @PrimaryKey val deviceId: String,
    val displayName: String,
    val createdAt: Long,
    val lastSeen: Long
)

@Entity(tableName = "preferences")
data class PreferenceEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String
)
