package com.usblinkpro.core.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usblinkpro.core.compat.CompatItem
import com.usblinkpro.core.compat.SupportStatus
import com.usblinkpro.core.data.TaskEntity
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.util.CrashDiagnostics
import java.text.DateFormat
import java.util.Date

@Composable
fun TaskListScreen(vm: TaskListViewModel = viewModel(factory = TaskListViewModel.Factory)) {
    val state by vm.state.collectAsStateWithLifecycle()
    val showFinished by vm.showFinished.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Show finished tasks", Modifier.weight(1f))
            Switch(checked = showFinished, onCheckedChange = vm::setShowFinished, modifier = Modifier.semantics { contentDescription = "Show finished tasks" })
        }
        error?.let { ErrorBanner(it, onDismiss = vm::dismissError) }
        StateView(state, onRetry = vm::retry, emptyText = "No tasks yet.") { tasks ->
            LazyColumn(Modifier.fillMaxSize()) {
                items(tasks, key = { it.taskId }) { task ->
                    TaskRow(
                        task = task,
                        busy = busy.any { it.endsWith(task.taskId) },
                        onCancel = { vm.cancel(task.taskId) },
                        onVerified = { vm.resolveVerification(task.taskId, executed = it) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun TaskRow(task: TaskEntity, busy: Boolean, onCancel: () -> Unit, onVerified: (Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(task.type, style = MaterialTheme.typography.titleMedium)
        Text("Status: ${task.status.name.lowercase().replace('_', ' ')}  •  retries: ${task.retryCount}")
        if (task.status == TaskStatus.RUNNING || task.status == TaskStatus.WAITING_NETWORK) {
            LinearProgressIndicator(
                progress = { task.progress / 100f },
                modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Progress ${task.progress} percent" }
            )
        }
        task.errorInfo?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        task.result?.let { Text(it) }
        when (task.status) {
            TaskStatus.PENDING, TaskStatus.RUNNING, TaskStatus.WAITING_NETWORK ->
                ActionButton("Cancel", busy, onCancel)
            TaskStatus.NEEDS_VERIFICATION -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("It was executed", busy, { onVerified(true) })
                ActionButton("It was not executed", busy, { onVerified(false) })
            }
            else -> Unit
        }
    }
}

@Composable
fun LogScreen(vm: LogViewModel = viewModel(factory = LogViewModel.Factory)) {
    val state by vm.state.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM) }
    Column(Modifier.fillMaxSize()) {
        error?.let { ErrorBanner(it, onDismiss = vm::dismissError, onRetry = vm::loadMore) }
        val ui: UiState<List<com.usblinkpro.core.data.ExecutionLogEntity>> = when {
            state.items.isEmpty() && state.loading -> UiState.Loading
            state.items.isEmpty() -> UiState.Empty
            else -> UiState.Content(state.items)
        }
        StateView(ui, onRetry = vm::refresh, emptyText = "No log entries.") { items ->
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { e ->
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Text("${fmt.format(Date(e.timestamp))}  ${e.level}", style = MaterialTheme.typography.labelSmall)
                        Text(e.message, style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    if (!state.endReached) ActionButton("Load more", busy.isNotEmpty(), vm::loadMore, Modifier.padding(16.dp))
                    else Text("Showing the most recent entries.", Modifier.padding(16.dp), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun TerminalScreen(vm: TerminalViewModel = viewModel(factory = TerminalViewModel.Factory)) {
    val lines by vm.lines.collectAsStateWithLifecycle()
    if (lines.isEmpty()) {
        StateView<List<String>>(UiState.Empty, onRetry = {}, emptyText = "No terminal output.") {}
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            items(lines.size, key = { it }) { i -> Text(lines[i], style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
fun CompatibilityScreen(vm: CompatibilityViewModel = viewModel(factory = CompatibilityViewModel.Factory)) {
    val state by vm.state.collectAsStateWithLifecycle()
    StateView(state, onRetry = vm::refresh, emptyText = "No checks available.") { items ->
        LazyColumn(Modifier.fillMaxSize()) {
            items(items, key = { it.id }) { CompatRow(it) }
            item { TextButton(onClick = vm::refresh, modifier = Modifier.padding(8.dp).heightIn(min = 48.dp)) { Text("Re-check") } }
        }
    }
}

@Composable
private fun CompatRow(item: CompatItem) {
    val label = when (item.status) {
        SupportStatus.SUPPORTED -> "SUPPORTED"
        SupportStatus.UNSUPPORTED -> "UNSUPPORTED"
        SupportStatus.UNKNOWN -> "UNKNOWN"
    }
    Column(
        Modifier.fillMaxWidth().padding(16.dp).semantics(mergeDescendants = true) { contentDescription = "${item.title}: $label. ${item.detail}" },
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text("${item.title} — $label", style = MaterialTheme.typography.titleSmall)
        Text(item.detail, style = MaterialTheme.typography.bodySmall)
    }
    HorizontalDivider()
}

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)) {
    val context = LocalContext.current
    val reduced by vm.reducedMotion.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val crashCount by vm.crashCount.collectAsStateWithLifecycle()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.setMessage(if (granted) "Notifications enabled." else "Notification permission was denied.")
    }
    val needsNotificationPermission = Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        error?.let { ErrorBanner(it, onDismiss = vm::dismissError) }
        message?.let { Text(it) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Reduced motion", Modifier.weight(1f))
            Switch(checked = reduced, onCheckedChange = vm::setReducedMotion, modifier = Modifier.semantics { contentDescription = "Reduced motion" })
        }
        if (needsNotificationPermission) {
            ActionButton("Enable notifications", false, { if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) })
        }
        ActionButton("Back up now", "backup" in busy, vm::backup)
        ActionButton("Restore latest backup", "restore" in busy, vm::restore)
        if (vm.recoveredFromCorruption()) Text("The database was damaged and has been reset. The damaged file was kept for diagnostics.")
        Text("Crash reports stored: $crashCount")
        TextButton(onClick = vm::clearCrashReports, modifier = Modifier.heightIn(min = 48.dp)) { Text("Clear crash reports") }
    }
}

@Composable
fun ReceivedFilesScreen(vm: ReceivedFilesViewModel = viewModel(factory = ReceivedFilesViewModel.Factory)) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        error?.let { ErrorBanner(it, onDismiss = vm::dismissError) }
        message?.let { Text(it, Modifier.padding(16.dp)) }
        if (!vm.canInstall()) {
            ActionButton("Allow installs (opens settings)", false, { openInstallSettings(context, vm) }, Modifier.padding(16.dp))
        }
        StateView(state, onRetry = vm::refresh, emptyText = "No received APK files.") { files ->
            LazyColumn(Modifier.fillMaxSize()) {
                items(files, key = { it.absolutePath }) { f ->
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(f.name, Modifier.weight(1f))
                        ActionButton("Install", "install:${f.name}" in busy, { vm.install(f) })
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

private fun openInstallSettings(context: Context, vm: ReceivedFilesViewModel) {
    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        CrashDiagnostics.recordNonFatal("open_install_settings", e)
        vm.setMessage("This settings screen is not available on this device.")
    }
}

