package com.usblinkpro.core

import com.usblinkpro.core.command.CommandPolicy
import com.usblinkpro.core.command.CommandSpec
import com.usblinkpro.core.session.Admission
import com.usblinkpro.core.session.RequestDeduplicator
import com.usblinkpro.core.session.SessionManager
import com.usblinkpro.core.session.SessionValidator
import com.usblinkpro.core.util.CommandRejectedException
import com.usblinkpro.core.util.InputValidator
import com.usblinkpro.core.util.LogSanitizer
import com.usblinkpro.core.util.TerminalBuffer
import com.usblinkpro.core.util.ValidationException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class SecurityAndValidationTest {
    @Test fun sanitizerRedactsSecrets() {
        for (s in listOf("password=hunter2", "Authorization: Bearer abc.def", "otp: 123456", "{\"token\":\"xyz\"}")) {
            val out = LogSanitizer.redact(s)
            assertTrue(out, out.contains("[REDACTED]"))
            for (secret in listOf("hunter2", "abc.def", "123456", "xyz")) assertFalse(out.contains(secret))
        }
        assertEquals("transfer 42% done", LogSanitizer.redact("transfer 42% done"))
    }

    @Test fun inputValidation() {
        assertEquals("192.168.43.1", InputValidator.host(" 192.168.43.1 "))
        assertEquals(8080, InputValidator.port("8080"))
        for (bad in listOf("", "a b", "-x.com", "x;rm")) expectInvalid { InputValidator.host(bad) }
        for (bad in listOf("0", "70000", "abc")) expectInvalid { InputValidator.port(bad) }
        for (bad in listOf("../a.apk", "a/b.apk", "", "..")) expectInvalid { InputValidator.fileName(bad) }
        assertEquals("app.apk", InputValidator.fileName("app.apk"))
    }

    private fun expectInvalid(block: () -> Unit) {
        try { block(); fail() } catch (_: ValidationException) {}
    }

    @Test fun commandPolicyIsAllowlistOnly() {
        val p = CommandPolicy(listOf(CommandSpec("status"), CommandSpec("open", maxArgs = 1)))
        p.validate("status", emptyList()); p.validate("open", listOf("file.txt"))
        for ((id, args) in listOf("rm" to emptyList(), "status" to listOf("x"), "open" to listOf("a;b"), "open" to listOf("a", "b"))) {
            try { p.validate(id, args); fail("$id $args") } catch (_: CommandRejectedException) {}
        }
    }

    @Test fun sessionValidation() {
        var now = 1_000_000L
        val sessions = SessionManager()
        val v = SessionValidator(sessions, RequestDeduplicator(clock = { now }), ttlMs = 30_000, clock = { now })
        assertEquals(Admission.NO_SESSION, v.admit("s", "r1", now))
        val id = sessions.open()
        assertEquals(Admission.OK, v.admit(id, "r1", now))
        assertEquals(Admission.DUPLICATE, v.admit(id, "r1", now))
        v.release("r1")
        assertEquals(Admission.DUPLICATE, v.admit(id, "r1", now))
        assertEquals(Admission.EXPIRED, v.admit(id, "r2", now - 60_000))
        sessions.invalidate(); val newId = sessions.open()
        assertEquals(Admission.STALE_SESSION, v.admit(id, "r3", now))
        assertEquals(Admission.OK, v.admit(newId, "r3", now))
    }

    @Test fun deduplicatorForgetsAfterTtl() {
        var now = 0L
        val d = RequestDeduplicator(ttlMs = 100, clock = { now })
        assertTrue(d.tryBegin("a")); d.finish("a")
        assertFalse(d.tryBegin("a"))
        now = 500
        assertTrue(d.tryBegin("a"))
    }

    @Test fun terminalBufferIsBoundedAndSanitized() {
        val t = TerminalBuffer(maxLines = 3, maxLineLength = 10)
        t.append("1\n2\n3\n4\n5")
        assertEquals(listOf("3", "4", "5"), t.snapshot())
        t.append("x".repeat(100)); assertEquals(10, t.snapshot().last().length)
        t.append("password=abc"); assertFalse(t.snapshot().last().contains("abc"))
        t.trimTo(1); assertEquals(1, t.snapshot().size)
    }
}
