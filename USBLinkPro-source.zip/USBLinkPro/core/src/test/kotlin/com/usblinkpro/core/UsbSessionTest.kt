package com.usblinkpro.core

import com.usblinkpro.core.usb.UsbLink
import com.usblinkpro.core.usb.UsbSession
import com.usblinkpro.core.usb.openSession
import com.usblinkpro.core.util.UsbDisconnectedException
import com.usblinkpro.core.util.UsbPermissionException
import com.usblinkpro.core.util.UsbTransferException
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FakeLink(private val onTransfer: (calls: Int) -> Int = { 1 shl 30 }) : UsbLink {
    var releases = 0; var calls = 0; var total = 0
    override var isOpen = true
    override fun bulkTransfer(endpointAddress: Int, buffer: ByteArray, offset: Int, length: Int, timeoutMs: Int): Int {
        val r = onTransfer(++calls); val n = if (r > length) length else r
        if (n > 0) total += n
        return n
    }
    override fun release() { releases++; isOpen = false }
}

class UsbSessionTest {
    @Test fun writesAllBytesInChunks() = runTest {
        val link = FakeLink(); val s = UsbSession(link, "dev", 1)
        assertEquals(40_000, s.write(ByteArray(40_000)))
        assertEquals(40_000, link.total); assertEquals(3, link.calls)
    }

    @Test fun detachDuringWriteThrowsAndCloseReleasesOnce() = runTest {
        lateinit var s: UsbSession
        val link = FakeLink { c -> if (c == 2) { s.close(); -1 } else 4096 }
        s = UsbSession(link, "dev", 1)
        try { s.write(ByteArray(40_000)); fail() } catch (_: UsbDisconnectedException) {}
        s.close(); s.close()
        assertEquals(1, link.releases)
    }

    @Test fun transferErrorIsReportedWithoutClosing() = runTest {
        val s = UsbSession(FakeLink { -1 }, "dev", 1)
        try { s.write(ByteArray(10)); fail() } catch (_: UsbTransferException) {}
        assertTrue(s.isActive)
    }

    @Test fun noProgressIsDetected() = runTest {
        try { UsbSession(FakeLink { 0 }, "dev", 1).write(ByteArray(10)); fail() } catch (_: UsbTransferException) {}
    }

    @Test fun permissionDenialAndOpenFailure() {
        try { openSession("dev", false, 1) { FakeLink() }; fail() } catch (_: UsbPermissionException) {}
        try { openSession("dev", true, 1) { null }; fail() } catch (_: UsbTransferException) {}
        val s = openSession("dev", true, 1) { FakeLink() }
        assertFalse(!s.isActive)
    }
}
