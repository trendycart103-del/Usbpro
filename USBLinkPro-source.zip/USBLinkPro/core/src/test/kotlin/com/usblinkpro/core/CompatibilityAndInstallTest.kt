package com.usblinkpro.core

import android.content.pm.PackageInstaller
import com.usblinkpro.core.compat.CompatibilityEngine
import com.usblinkpro.core.compat.DeviceSnapshot
import com.usblinkpro.core.compat.SupportStatus
import com.usblinkpro.core.data.IllegalTaskTransitionException
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.data.TaskTransitions
import com.usblinkpro.core.transfer.InstallResult
import com.usblinkpro.core.transfer.InstallStatusMapper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CompatibilityAndInstallTest {
    private fun snap(
        sdk: Int = 34, oem: String = "Google", notif: Boolean? = true, install: Boolean = true,
        canInstall: Boolean? = true, bg: Boolean? = false, tether: Boolean? = false
    ) = DeviceSnapshot(sdk, oem, true, false, true, notif, tether, bg, install, canInstall, false, mapOf("Wi-Fi" to true))

    private fun status(items: List<com.usblinkpro.core.compat.CompatItem>, id: String) = items.first { it.id == id }.status

    @Test fun neverFabricatesCapabilities() {
        val items = CompatibilityEngine.evaluate(snap())
        assertEquals(SupportStatus.UNKNOWN, status(items, "usb_hid"))
        assertEquals(SupportStatus.UNKNOWN, status(items, "hotspot"))
        assertEquals(SupportStatus.UNSUPPORTED, status(items, "usb_accessory"))
        assertEquals(SupportStatus.SUPPORTED, status(items, "usb_host"))
    }

    @Test fun permissionDenialAndRestrictions() {
        val items = CompatibilityEngine.evaluate(snap(notif = false, canInstall = false, bg = true, tether = true, oem = "Xiaomi"))
        assertEquals(SupportStatus.UNSUPPORTED, status(items, "notifications"))
        assertEquals(SupportStatus.UNSUPPORTED, status(items, "install"))
        assertEquals(SupportStatus.UNSUPPORTED, status(items, "background"))
        assertEquals(SupportStatus.UNSUPPORTED, status(items, "hotspot"))
        assertEquals(SupportStatus.UNKNOWN, status(items, "oem"))
    }

    @Test fun unknownWhenUndeterminable() {
        val items = CompatibilityEngine.evaluate(snap(notif = null, canInstall = null, bg = null, tether = null))
        for (id in listOf("notifications", "install", "background", "hotspot")) assertEquals(id, SupportStatus.UNKNOWN, status(items, id))
    }

    @Test fun installItemOmittedWhenNotRequiredAndOldSdkUnsupported() {
        assertTrue(CompatibilityEngine.evaluate(snap(install = false)).none { it.id == "install" })
        assertEquals(SupportStatus.UNSUPPORTED, status(CompatibilityEngine.evaluate(snap(sdk = 24)), "sdk"))
    }

    @Test fun taskTransitions() {
        assertTrue(TaskTransitions.isAllowed(TaskStatus.RUNNING, TaskStatus.NEEDS_VERIFICATION))
        assertFalse(TaskTransitions.isAllowed(TaskStatus.COMPLETED, TaskStatus.RUNNING))
        assertFalse(TaskTransitions.isAllowed(TaskStatus.NEEDS_VERIFICATION, TaskStatus.RUNNING))
        for (t in TaskStatus.values().filter { it.isTerminal }) for (to in TaskStatus.values()) assertFalse(TaskTransitions.isAllowed(t, to))
        assertEquals("Illegal task transition COMPLETED -> RUNNING", IllegalTaskTransitionException(TaskStatus.COMPLETED, TaskStatus.RUNNING).message)
    }

    @Test fun installStatusMapping() {
        assertEquals(InstallResult.Success("p"), InstallStatusMapper.map(PackageInstaller.STATUS_SUCCESS, null, "p", null))
        assertEquals(InstallResult.Cancelled, InstallStatusMapper.map(PackageInstaller.STATUS_FAILURE_ABORTED, null, null, null))
        assertTrue(InstallStatusMapper.map(PackageInstaller.STATUS_FAILURE_STORAGE, "no space", null, null) is InstallResult.Failure)
        assertTrue(InstallStatusMapper.map(PackageInstaller.STATUS_PENDING_USER_ACTION, null, null, null) is InstallResult.Failure)
    }
}
