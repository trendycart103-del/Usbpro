package com.usblinkpro.core

import com.usblinkpro.core.net.HeartbeatMonitor
import com.usblinkpro.core.net.RetryPolicy
import com.usblinkpro.core.net.retryWithBackoff
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.IOException
import kotlin.random.Random

class RetryAndHeartbeatTest {
    @Test fun delaysGrowAndCap() {
        val p = RetryPolicy(baseMs = 100, maxMs = 1000, jitterRatio = 0.0)
        assertEquals(listOf(100L, 200L, 400L, 800L, 1000L, 1000L), (0..5).map { p.delayFor(it) })
    }

    @Test fun jitterStaysInBounds() {
        val p = RetryPolicy(100, 1000, 6, 0.2)
        repeat(200) { assertTrue(p.delayFor(3, Random(it)) in 640..960) }
    }

    @Test fun retriesThenSucceeds() = runTest {
        var calls = 0
        val r = retryWithBackoff(RetryPolicy(1, 2, 5, 0.0)) { if (++calls < 3) throw IOException("x"); "ok" }
        assertEquals("ok", r); assertEquals(3, calls)
    }

    @Test fun nonRetryableThrowsImmediately() = runTest {
        var calls = 0
        try { retryWithBackoff<Unit>(RetryPolicy(1, 2, 5, 0.0)) { calls++; throw IllegalStateException() }; fail() }
        catch (e: IllegalStateException) { assertEquals(1, calls) }
    }

    @Test fun exhaustsAttempts() = runTest {
        var calls = 0
        try { retryWithBackoff<Unit>(RetryPolicy(1, 2, 3, 0.0)) { calls++; throw IOException() }; fail() }
        catch (e: IOException) { assertEquals(3, calls) }
    }

    @Test fun cancellationIsNotRetried() = runTest {
        var calls = 0
        try { retryWithBackoff<Unit>(RetryPolicy(1, 2, 5, 0.0)) { calls++; throw CancellationException("c") }; fail() }
        catch (e: CancellationException) { assertEquals(1, calls) }
    }

    @Test fun heartbeatReportsLossAfterMisses() = runTest {
        var lost = 0
        HeartbeatMonitor(backgroundScope, 1000, 500, 3, { false }, { lost++ }).start()
        advanceTimeBy(3001); runCurrent()
        assertEquals(1, lost)
    }

    @Test fun heartbeatTimeoutCountsAsMiss() = runTest {
        var lost = 0
        HeartbeatMonitor(backgroundScope, 1000, 500, 3, { delay(10_000); true }, { lost++ }).start()
        advanceTimeBy(5000); runCurrent()
        assertEquals(1, lost)
    }

    @Test fun heartbeatRecoversWhenPingSucceeds() = runTest {
        var lost = 0; var n = 0
        HeartbeatMonitor(backgroundScope, 1000, 500, 3, { n++ % 2 == 0 }, { lost++ }).start()
        advanceTimeBy(20_000); runCurrent()
        assertEquals(0, lost)
    }
}
