package com.usblinkpro.core

import androidx.lifecycle.SavedStateHandle
import com.usblinkpro.core.data.TaskEntity
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.data.TaskStore
import com.usblinkpro.core.ui.ActionGuard
import com.usblinkpro.core.ui.GuardResult
import com.usblinkpro.core.ui.TaskListViewModel
import com.usblinkpro.core.ui.UiState
import com.usblinkpro.core.util.OperationTimeoutException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.IOException

@OptIn(ExperimentalCoroutinesApi::class)
class ViewModelAndGuardTest {
    @Before fun setUp() = Dispatchers.setMain(UnconfinedTestDispatcher())
    @After fun tearDown() = Dispatchers.resetMain()

    private fun task(id: String, status: TaskStatus) = TaskEntity(id, "t", status, 0, 0, 0, 0, null, null, true, null)

    private class FakeTasks(var fail: Boolean = false) : TaskStore {
        val data = MutableStateFlow(listOf<TaskEntity>())
        override fun observeRecent(limit: Int): Flow<List<TaskEntity>> =
            if (fail) flow { throw IOException("db") } else data
        override suspend fun create(type: String, idempotent: Boolean, sessionId: String?) = error("unused")
        override suspend fun transition(id: String, to: TaskStatus, error: String?, result: String?, incrementRetry: Boolean) = error("unused")
    }

    @Test fun guardRejectsDuplicatesAndAlwaysReleases() = runTest {
        val g = ActionGuard(); val gate = CompletableDeferred<Unit>()
        val first = async { g.run("k") { gate.await(); 1 } }
        runCurrent()
        assertTrue("k" in g.busyKeys.value)
        assertEquals(GuardResult.Rejected, g.run("k") { 2 })
        gate.complete(Unit)
        assertEquals(GuardResult.Done(1), first.await())
        assertTrue(g.busyKeys.value.isEmpty())
        assertTrue(g.run("k") { error("boom") } is GuardResult.Failed)
        assertTrue(g.busyKeys.value.isEmpty())
        val t = g.run("k", timeoutMs = 100) { delay(10_000) }
        assertTrue((t as GuardResult.Failed).error is OperationTimeoutException)
        assertTrue(g.busyKeys.value.isEmpty())
        assertEquals(GuardResult.Done(3), g.run("k") { 3 })
    }

    @Test fun savedStateSurvivesRecreation() = runTest {
        val store = FakeTasks()
        val saved = SavedStateHandle()
        val vm1 = TaskListViewModel(saved, store); vm1.setShowFinished(false)
        val vm2 = TaskListViewModel(SavedStateHandle(mapOf(TaskListViewModel.KEY_SHOW_FINISHED to saved.get<Boolean>(TaskListViewModel.KEY_SHOW_FINISHED))), store)
        assertEquals(false, vm2.showFinished.value)
    }

    @Test fun emptyContentAndFilter() = runTest {
        val store = FakeTasks(); val vm = TaskListViewModel(SavedStateHandle(), store)
        backgroundScope.launch { vm.state.collect {} }
        assertEquals(UiState.Empty, vm.state.value)
        store.data.value = listOf(task("a", TaskStatus.RUNNING), task("b", TaskStatus.COMPLETED))
        assertEquals(2, (vm.state.value as UiState.Content).data.size)
        vm.setShowFinished(false)
        assertEquals(1, (vm.state.value as UiState.Content).data.size)
    }

    @Test fun errorStateThenRetryRecovers() = runTest {
        val store = FakeTasks(fail = true); val vm = TaskListViewModel(SavedStateHandle(), store)
        backgroundScope.launch { vm.state.collect {} }
        assertTrue(vm.state.value is UiState.Error)
        store.fail = false; store.data.value = listOf(task("a", TaskStatus.PENDING))
        vm.retry()
        assertTrue(vm.state.value is UiState.Content)
    }
}
