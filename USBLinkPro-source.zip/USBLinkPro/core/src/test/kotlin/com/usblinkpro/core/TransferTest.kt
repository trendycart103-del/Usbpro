package com.usblinkpro.core

import com.usblinkpro.core.data.TransferMetaEntity
import com.usblinkpro.core.data.TransferStatus
import com.usblinkpro.core.data.TransferStore
import com.usblinkpro.core.transfer.ChunkReceiver
import com.usblinkpro.core.transfer.ChunkSink
import com.usblinkpro.core.transfer.ResumeState
import com.usblinkpro.core.transfer.TransferEngine
import com.usblinkpro.core.transfer.TransferHeader
import com.usblinkpro.core.transfer.TransferOutcome
import com.usblinkpro.core.util.ChecksumMismatchException
import com.usblinkpro.core.util.Hashing
import com.usblinkpro.core.util.InsufficientStorageException
import com.usblinkpro.core.util.TransferProtocolException
import com.usblinkpro.core.util.ValidationException
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import kotlin.random.Random

class FakeStore : TransferStore {
    val rows = HashMap<String, TransferMetaEntity>()
    override suspend fun upsert(meta: TransferMetaEntity) { rows[meta.transferId] = meta }
    override suspend fun findCompletedBySha(sha: String) = rows.values.firstOrNull { it.sha256 == sha && it.status == TransferStatus.COMPLETED }
    override suspend fun updateProgress(id: String, committed: Long, status: TransferStatus, now: Long) {
        rows[id] = rows.getValue(id).copy(committedBytes = committed, status = status)
    }
}

class TransferTest {
    @get:Rule val tmp = TemporaryFolder()
    private val id = "transfer-0001"

    private fun source(size: Int = 300_000): File = tmp.newFile("app.apk").also { it.writeBytes(Random(1).nextBytes(size)) }
    private fun receiver(free: (File) -> Long = { Long.MAX_VALUE }) =
        ChunkReceiver(File(tmp.root, "part"), File(tmp.root, "final"), freeSpace = free)

    @Test fun fullTransferVerifiesAndStoresFile() = runTest {
        val src = source(); val store = FakeStore(); val rx = receiver()
        val out = TransferEngine(store).send(src, id, rx, chunkSize = 8192)
        assertTrue(out is TransferOutcome.Completed)
        assertArrayEquals(src.readBytes(), rx.finalFile!!.readBytes())
        assertEquals(TransferStatus.COMPLETED, store.rows.getValue(id).status)
    }

    @Test fun connectionLossThenResumeFromCommittedOffset() = runTest {
        val src = source(); val store = FakeStore(); val real = receiver()
        val flaky = object : ChunkSink by real {
            var sent = 0L
            override suspend fun write(offset: Long, buf: ByteArray, len: Int) {
                if (sent >= 100_000) throw IOException("connection lost")
                real.write(offset, buf, len); sent += len
            }
        }
        try { TransferEngine(store).send(src, id, flaky, chunkSize = 8192); fail() } catch (_: IOException) {}
        assertEquals(TransferStatus.FAILED, store.rows.getValue(id).status)
        real.close()
        val second = receiver()
        val out = TransferEngine(store).send(src, id, second, chunkSize = 8192)
        assertTrue(out is TransferOutcome.Completed)
        assertArrayEquals(src.readBytes(), second.finalFile!!.readBytes())
    }

    @Test fun changedSourceRestartsFromZero() = runTest {
        val src = source(); val store = FakeStore(); val rx = receiver()
        val header = TransferHeader(id, "app.apk", src.length(), Hashing.sha256(src), 8192)
        rx.begin(header); rx.write(0, ByteArray(8192) { 7 }, 8192); rx.close()
        val out = TransferEngine(store).send(src, id, receiver(), chunkSize = 8192)
        assertTrue(out is TransferOutcome.Completed)
    }

    @Test fun duplicateIsDetected() = runTest {
        val src = source(); val store = FakeStore(); val engine = TransferEngine(store)
        engine.send(src, id, receiver(), chunkSize = 8192)
        assertTrue(engine.send(src, "transfer-0002", receiver(), chunkSize = 8192) is TransferOutcome.Duplicate)
        assertTrue(engine.send(src, "transfer-0003", receiver(), chunkSize = 8192, allowDuplicate = true) is TransferOutcome.Completed)
    }

    @Test fun checksumMismatchIsRejectedAndPartDeleted() = runTest {
        val src = source(10_000); val rx = receiver()
        val header = TransferHeader(id, "app.apk", src.length(), "0".repeat(64), 4096)
        rx.begin(header); rx.write(0, src.readBytes(), 10_000)
        try { rx.finish(); fail() } catch (_: ChecksumMismatchException) {}
        assertFalse(File(tmp.root, "part/$id.part").exists())
        assertEquals(null, rx.finalFile)
    }

    @Test fun lowStorageIsRejectedBeforeWriting() = runTest {
        val src = source(10_000)
        try { TransferEngine(FakeStore()).send(src, id, receiver { 10L }, chunkSize = 4096); fail() }
        catch (_: InsufficientStorageException) {}
    }

    @Test fun outOfOrderAndInvalidHeadersRejected() = runTest {
        val src = source(10_000); val rx = receiver()
        rx.begin(TransferHeader(id, "app.apk", 10_000, Hashing.sha256(src), 4096))
        try { rx.write(4096, ByteArray(4096), 4096); fail() } catch (_: TransferProtocolException) {}
        try { receiver().begin(TransferHeader(id, "../x.apk", 10, "0".repeat(64), 4096)); fail() } catch (_: ValidationException) {}
        try { receiver().begin(TransferHeader("bad", "x.apk", 10, "0".repeat(64), 4096)); fail() } catch (_: ValidationException) {}
    }
}
