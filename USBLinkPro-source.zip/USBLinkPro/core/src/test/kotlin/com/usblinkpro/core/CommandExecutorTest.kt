package com.usblinkpro.core

import com.usblinkpro.core.command.CommandExecutor
import com.usblinkpro.core.command.CommandPolicy
import com.usblinkpro.core.command.CommandRequest
import com.usblinkpro.core.command.CommandSpec
import com.usblinkpro.core.command.ExecResult
import com.usblinkpro.core.data.AuditLog
import com.usblinkpro.core.data.LogLevel
import com.usblinkpro.core.data.TaskEntity
import com.usblinkpro.core.data.TaskStatus
import com.usblinkpro.core.data.TaskStore
import com.usblinkpro.core.session.RequestDeduplicator
import com.usblinkpro.core.session.SessionManager
import com.usblinkpro.core.session.SessionValidator
import com.usblinkpro.core.util.CommandRejectedException
import com.usblinkpro.core.util.OperationTimeoutException
import com.usblinkpro.core.util.TerminalBuffer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class CommandExecutorTest {
    private class Tasks : TaskStore {
        val rows = HashMap<String, TaskEntity>()
        override fun observeRecent(limit: Int): Flow<List<TaskEntity>> = emptyFlow()
        override suspend fun create(type: String, idempotent: Boolean, sessionId: String?): TaskEntity {
            val t = TaskEntity("id${rows.size}", type, TaskStatus.PENDING, 0, 0, 0, 0, null, null, idempotent, sessionId)
            rows[t.taskId] = t; return t
        }
        override suspend fun transition(id: String, to: TaskStatus, error: String?, result: String?, incrementRetry: Boolean): TaskEntity {
            val t = rows.getValue(id).copy(status = to); rows[id] = t; return t
        }
    }
    private object NoAudit : AuditLog {
        override suspend fun log(level: LogLevel, message: String, taskId: String?) {}
        override suspend fun command(commandId: String, taskId: String?, outcome: String) {}
    }

    private fun setup(timeout: Long, handler: suspend (CommandSpec, List<String>) -> String): Triple<CommandExecutor, SessionManager, Tasks> {
        val sessions = SessionManager(); val tasks = Tasks()
        val ex = CommandExecutor(CommandPolicy(listOf(CommandSpec("status"))), sessions,
            SessionValidator(sessions, RequestDeduplicator()), tasks, NoAudit, TerminalBuffer(), timeout, handler)
        return Triple(ex, sessions, tasks)
    }

    private fun req(session: String?, id: String = "r1", idem: Boolean = false) =
        CommandRequest("status", emptyList(), session, id, System.currentTimeMillis(), idem)

    @Test fun successCompletesTask() = runTest {
        val (ex, s, tasks) = setup(1000) { _, _ -> "ok" }
        val r = ex.execute(req(s.open()), approved = true)
        assertTrue(r is ExecResult.Success)
        assertEquals(TaskStatus.COMPLETED, tasks.rows.values.single().status)
    }

    @Test fun timeoutOfNonIdempotentCommandNeedsVerification() = runTest {
        val (ex, s, tasks) = setup(100) { _, _ -> delay(10_000); "late" }
        val r = ex.execute(req(s.open()), approved = true) as ExecResult.Failed
        assertTrue(r.error is OperationTimeoutException); assertTrue(r.needsVerification)
        assertEquals(TaskStatus.NEEDS_VERIFICATION, tasks.rows.values.single().status)
    }

    @Test fun idempotentFailureIsFailedAndUnapprovedOrStaleRejected() = runTest {
        val (ex, s, tasks) = setup(1000) { _, _ -> error("x") }
        val id = s.open()
        assertEquals(TaskStatus.FAILED, (ex.execute(req(id, "a", true), true) as ExecResult.Failed).let { tasks.rows.getValue(it.taskId).status })
        try { ex.execute(req(id, "b"), approved = false); fail() } catch (_: CommandRejectedException) {}
        s.invalidate()
        try { ex.execute(req(id, "c"), approved = true); fail() } catch (_: Exception) {}
    }
}
