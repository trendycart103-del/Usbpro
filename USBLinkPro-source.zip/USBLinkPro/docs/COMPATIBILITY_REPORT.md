# Compatibility report

No device has been tested. Results below must be filled in from real runs of `scripts/validate.sh` and manual checks.

| Device / Android | USB host | Wi-Fi | Hotspot | Background | Install | Notes |
|---|---|---|---|---|---|---|
| (none tested) | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN | — |

At runtime the app's Device screen reports SUPPORTED / UNSUPPORTED / UNKNOWN per check; undeterminable items are UNKNOWN.
