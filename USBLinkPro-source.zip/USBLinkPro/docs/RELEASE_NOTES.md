# Release notes — 1.0.0 (source only, unbuilt)

Added: Room persistence with task state machine and safe restore; WorkManager restore/maintenance; self-stopping dataSync foreground service; heartbeat, backoff, session invalidation, duplicate-request protection; USB attach/detach/permission/cleanup handling; chunked resumable SHA-256-verified transfer; APK validation and PackageInstaller-based (user-confirmed) install; compatibility engine; guarded UI states, paging, bounded terminal, Reduced Motion; crash diagnostics; unit and instrumented tests.
Removed/avoided by design: raw terminal execution, execute-all, silent permission requests, polling services, always-on services, unused permissions.
Status: not compiled, not tested, no APKs. See KNOWN_LIMITATIONS.md.
