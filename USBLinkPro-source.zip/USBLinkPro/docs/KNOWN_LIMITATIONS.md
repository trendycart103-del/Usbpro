# Known limitations

- **No pre-existing project source was supplied.** This is a hardened baseline built from the specification, not a review of existing code. Existing feature modules must be integrated through the provided interfaces (`ChunkSink`, `UsbLink`, `TaskStore`, `CommandExecutor` handler). Nothing was removed because there was nothing to remove.
- **Not built or run.** The authoring environment had no Android SDK, Gradle distribution or network. Code has not been compiled; compile errors are possible and must be fixed first.
- **No APKs, build logs, test results or device results are included.** `scripts/validate.sh` produces them.
- **Network protocol not implemented.** Socket framing/pairing between Controller and Receiver is not part of this baseline; `ChunkReceiver`/`TransferEngine` are transport-agnostic.
- **Uncaught exceptions still end the process** (reported first). Isolation relies on guarded coroutine scopes, not on swallowing fatal errors.
- **Install confirmation needs the Receiver Activity to be visible**; otherwise the confirmation intent is dropped and the install session expires.
- **Hotspot support, HID gadget support and OEM background behavior cannot be verified through public APIs** and are reported as UNKNOWN.
- **Backups** are stored in app-private storage (last 5 kept) and are not exported; backup copies the file after a WAL checkpoint and is not safe against concurrent writers.
- Database version 1 has no migrations yet (`Migrations.ALL` is empty); corrupt or unmigratable files are quarantined as `*.corrupt-<ts>` and a fresh DB is created.
- Android 15 limits `dataSync` foreground services to ~6 hours; the service stops cleanly on timeout.
- Hostname validation accepts hostnames and IPv4 only (no IPv6 literals).
