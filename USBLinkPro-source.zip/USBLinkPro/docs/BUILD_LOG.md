# Build log

**Build not attempted.** No Android SDK, Gradle distribution or network access was available. Run `scripts/validate.sh`; real logs are written to `build-logs/`.
