# Test results

**No tests have been executed.** Tests exist but were never run in this environment.

| Suite | Location | Status |
|---|---|---|
| Unit: retry/heartbeat, security/validation, transfer + recovery + low storage, USB session, compatibility, view models/guard | `core/src/test` | NOT RUN |
| Database, process-recreation restore, worker, corruption, backup | `core/src/androidTest/.../PersistenceInstrumentedTest` | NOT RUN |
| UI states, network monitor/probe, APK validation, compat reader | `core/src/androidTest/.../DeviceInstrumentedTest` | NOT RUN |
| Activity recreation / navigation | `controller|receiver/src/androidTest` | NOT RUN |
| Real USB hardware, real Wi-Fi/hotspot, device restart, force-stop | manual | NOT RUN |
