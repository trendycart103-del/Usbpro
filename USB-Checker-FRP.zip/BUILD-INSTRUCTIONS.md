# Build instructions
Requirements: JDK 17, Android Studio Koala+ (or Android SDK with platform 35 and build-tools 35.0.0), Gradle 8.9.

1. Open the folder in Android Studio and let it sync (it will create the Gradle wrapper JAR), or run `gradle wrapper --gradle-version 8.9` once.
2. `./gradlew :app:testDebugUnitTest` – unit tests.
3. `./gradlew :app:lintDebug` – static checks.
4. `./gradlew :app:assembleDebug` – APK at `app/build/outputs/apk/debug/`.

CI: `.github/workflows/build.yml` does the same steps on GitHub Actions and uploads the debug APK and logs as private workflow artifacts. Nothing is published publicly. No keystores or secrets are in the repository.

USB testing needs a physical phone with USB Host (OTG) and a peripheral.
