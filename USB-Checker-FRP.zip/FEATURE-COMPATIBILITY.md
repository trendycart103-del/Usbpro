# Feature compatibility
Nothing below has been verified on hardware.

## Implemented (needs device testing)
USB scan/info/interfaces/endpoints, USB permission via system dialog, control-transfer test, attach/detach history (while app process is alive), HID descriptor detection, Android InputDevice listing, mouse and keyboard live tests, device/network/battery/storage/memory/display/sensor/security info, diagnostics save/export, command registry + terminal, APK inspection and share, installer hand-off, launcher app list, settings launcher, permission center, recovery checklist/report, logs with rotation/search/filter/export/clear, EN/BN UI, in-app quick panel.

## Partially implemented
- Bengali: dashboard, titles and common labels are translated; many body texts are English only.
- Floating overlay bubble: needs user-granted overlay access; background service survival is OEM dependent.
- Connection history: recorded only while the app process runs.
- `usb.disconnect`: reports that the app holds no connections; Android cannot disconnect hardware.

## Hardware dependent
USB Host/OTG, peripheral class behavior, accessory mode, kernel gadget nodes.

## Android restricted
Wi-Fi SSID, IMEI/serial, full app inventory (only launcher apps), auto-granting any permission, silent install, reading other apps' data.

## Unsupported (by design or by Android)
HID Gadget (phone as keyboard/mouse) from a normal app, FRP bypass/removal, lock removal, unrestricted shell, firmware/hardware repair.

## Not yet implemented
Room database, WorkManager tasks, separate Gradle modules, full Bengali text coverage.
