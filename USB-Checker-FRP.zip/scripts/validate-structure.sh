#!/usr/bin/env bash
set -euo pipefail
required=(settings.gradle.kts build.gradle.kts app/build.gradle.kts app/src/main/AndroidManifest.xml
  app/src/main/java/com/usbchecker/frp/MainActivity.kt app/src/main/res/drawable/ic_launcher_foreground.xml
  app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml README.md PRIVACY.md FEATURE-COMPATIBILITY.md)
for f in "${required[@]}"; do [ -f "$f" ] || { echo "MISSING: $f"; exit 1; }; done
if grep -rIl "USB Link Pro" --exclude-dir=.git --exclude-dir=scripts . | grep -q .; then echo "Old project name found"; exit 1; fi
echo "Structure OK"
