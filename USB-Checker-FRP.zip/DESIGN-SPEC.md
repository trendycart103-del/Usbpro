# Design spec
Dark futuristic Material 3 theme (light variant available in settings). Palette: background #050B1C, secondary #0A1530, card #101E3D, elevated #16294F, primary #087BFF, electric #00BFFF, purple #773CFF, cyan #00E5FF, success #16D96A, warning #FFB020, error #FF405A, text #FFFFFF / #A9B8D0, border #263D68.
Components (`designsystem/`): FrpCard, ExpandCard (animated, respects the Animations setting), GradientButton, StatusChip, CapabilityRow, ResultPanel, Loading, KvRow.
Navigation: dashboard grid (19 shortcuts, searchable) → one screen per category. Snackbars report success/error. Language switch EN/বাংলা on the dashboard and in settings.
Logo: vector (phone, USB symbol, green check, gear, blue/purple gradient) used as adaptive launcher icon, splash icon and in-app logo.
Status vocabulary: Fully / Partially Supported, Hardware Dependent, Android Restricted, Unsupported, Unknown, Not Yet Implemented. Execution statuses: Success, Partial, Needs user action, Unsupported, Failed, Rejected.
