# USB Checker FRP

Standalone Android app (Kotlin, Jetpack Compose, Material 3) for USB diagnostics, device information, a registered-command system, APK inspection, settings shortcuts and **official** owner-recovery guidance.

- Package: `com.usbchecker.frp` · minSdk 26 · compile/target SDK 35 · Gradle Kotlin DSL
- Single APK. No controller/receiver app, no second phone.

## Status (read this first)
The source was generated in an environment with no Android SDK, no Gradle and no network. **It has not been compiled and has not been run on a device.** Treat the first Gradle build as the first real test and expect to fix small compile errors. See `FEATURE-COMPATIBILITY.md` for what each feature can and cannot do.

## What it does
USB scanner (permission, interfaces/endpoints, real control-transfer test, attach/detach history) · HID report and live mouse/keyboard tests · Host/HID/Accessory capability modes · device info and diagnostics (save/export) · Command Center and Terminal over a fixed registry of ~70 commands (no shell) · APK inspector (SHA-256, signer certs, installer hand-off) · app list · Settings launcher · Permission Center · Security Center · Repair and Recovery assistants (legitimate guidance only) · floating panel (in-app, optional overlay) · rotated execution logs · English/Bengali.

## What it deliberately does not do
FRP bypass, lock removal, silent installs, auto-granting permissions, unrestricted shell, HID gadget mode, hardware/firmware repair.

## Structure
`app/src/main/java/com/usbchecker/frp/`: `core/` (usb, diagnostics, commands, permissions, compatibility), `designsystem/`, `navigation/`, `data/`, `ui/<feature>/`, `utils/`. Build instructions: `BUILD-INSTRUCTIONS.md`.

## Deviations from the brief
Room, Hilt and WorkManager are not used: persistence is a small rotated JSON-lines store plus DataStore, DI is a manual container, and there is no deferrable work. `core/` and `design-system/` are packages inside the single `app` module, not separate Gradle modules.
