package com.usbchecker.frp.core.compatibility

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import java.io.File

enum class Support(val label: String) {
    FULLY("Fully Supported"),
    PARTIAL("Partially Supported"),
    HARDWARE("Hardware Dependent"),
    RESTRICTED("Android Restricted"),
    UNSUPPORTED("Unsupported"),
    UNKNOWN("Unknown"),
    NOT_IMPLEMENTED("Not Yet Implemented")
}

data class Capability(val name: String, val status: Support, val detail: String)

object Compat {
    fun usbHost(ctx: Context): List<Capability> {
        val host = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        return listOf(
            Capability(
                "USB Host feature (android.hardware.usb.host)",
                if (host) Support.FULLY else Support.UNSUPPORTED,
                if (host) "Declared by this device." else "Not declared; this device cannot act as a USB host."
            ),
            Capability("Per-device USB permission", if (host) Support.FULLY else Support.UNSUPPORTED,
                "Granted through the Android system dialog only."),
            Capability("Raw data transfer", if (host) Support.HARDWARE else Support.UNSUPPORTED,
                "Depends on the peripheral, OTG hardware and OEM firmware. The app tests a standard control transfer."),
            Capability("Silent connection / auto-grant", Support.RESTRICTED,
                "Android never lets an app grant USB permission to itself.")
        )
    }

    fun hid(ctx: Context): List<Capability> {
        val host = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        val (nodesStatus, nodesDetail) = gadgetNodes()
        return listOf(
            Capability("Host-side HID detection (interface class 3)", if (host) Support.FULLY else Support.UNSUPPORTED,
                "Reads interface descriptors of attached peripherals."),
            Capability("Android input stack recognition", Support.FULLY,
                "InputDevice list shows whether Android registered a mouse/keyboard."),
            Capability("HID Gadget (this phone acts as keyboard/mouse)", Support.UNSUPPORTED,
                "No public Android API exists. A normal app cannot enable it; it needs kernel configfs/ROM support and privileged setup."),
            Capability("Kernel gadget nodes visible to this app", nodesStatus, nodesDetail)
        )
    }

    fun accessory(ctx: Context): List<Capability> {
        val acc = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY)
        val mgr = ctx.getSystemService(Context.USB_SERVICE) as? UsbManager
        val attached = runCatching { mgr?.accessoryList?.size ?: 0 }.getOrDefault(0)
        return listOf(
            Capability("USB Accessory feature (android.hardware.usb.accessory)",
                if (acc) Support.FULLY else Support.UNSUPPORTED,
                if (acc) "Declared by this device." else "Not declared by this device."),
            Capability("Accessory mode (phone talks to an accessory-capable host)", Support.HARDWARE,
                "The external host must start the Android Open Accessory handshake; the app cannot initiate it."),
            Capability("Currently attached accessories", if (attached > 0) Support.FULLY else Support.UNKNOWN,
                "$attached accessory(ies) reported by UsbManager.")
        )
    }

    private fun gadgetNodes(): Pair<Support, String> {
        val udc = runCatching { File("/sys/class/udc").list()?.toList().orEmpty() }.getOrDefault(emptyList())
        val hidg = runCatching { File("/dev/hidg0").exists() }.getOrDefault(false)
        return when {
            udc.isNotEmpty() || hidg -> Support.HARDWARE to
                "Visible: ${if (udc.isNotEmpty()) "UDC ${udc.joinToString()}" else ""}${if (hidg) " /dev/hidg0" else ""}. Hardware may support gadgets, but this app cannot use them without privileged setup."
            else -> Support.UNKNOWN to
                "No gadget nodes visible. Android SELinux usually hides them from apps, so support cannot be determined."
        }
    }

    fun asText(list: List<Capability>): String =
        list.joinToString("\n") { "[${it.status.label}] ${it.name}\n    ${it.detail}" }
}
