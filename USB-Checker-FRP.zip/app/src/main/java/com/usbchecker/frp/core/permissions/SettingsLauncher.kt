package com.usbchecker.frp.core.permissions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.usbchecker.frp.utils.Intents

data class SettingTarget(val id: String, val title: String, val group: String, val note: String, val build: (Context) -> Intent)

/** Only public Settings intents. Android decides whether each page exists; we never change settings ourselves. */
object SettingsLauncher {
    private fun pkg(c: Context) = Uri.parse("package:${c.packageName}")

    val targets: List<SettingTarget> = listOf(
        SettingTarget("app.info", "App Information", "Application", "This app's details page") { Intents.appDetails(it) },
        SettingTarget("app.permissions", "Application Permissions", "Application", "Opens app details; permissions are inside") { Intents.appDetails(it) },
        SettingTarget("app.notifications", "Notifications", "Application", "This app's notification settings") {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, it.packageName)
        },
        SettingTarget("app.storage", "Storage", "Application", "Internal storage overview") { Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) },
        SettingTarget("app.battery", "Battery", "Application", "Battery optimization list") { Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) },
        SettingTarget("app.details", "App Details (all apps)", "Application", "List of installed apps") { Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS) },
        SettingTarget("app.defaults", "Default Apps", "Application", "Default application chooser") { Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS) },

        SettingTarget("sys.wifi", "Wi-Fi Settings", "System", "") { Intent(Settings.ACTION_WIFI_SETTINGS) },
        SettingTarget("sys.bluetooth", "Bluetooth Settings", "System", "") { Intent(Settings.ACTION_BLUETOOTH_SETTINGS) },
        SettingTarget("sys.display", "Display Settings", "System", "") { Intent(Settings.ACTION_DISPLAY_SETTINGS) },
        SettingTarget("sys.sound", "Sound Settings", "System", "") { Intent(Settings.ACTION_SOUND_SETTINGS) },
        SettingTarget("sys.language", "Language Settings", "System", "") { Intent(Settings.ACTION_LOCALE_SETTINGS) },
        SettingTarget("sys.accessibility", "Accessibility Settings", "System", "") { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
        SettingTarget("sys.date", "Date & Time", "System", "") { Intent(Settings.ACTION_DATE_SETTINGS) },
        SettingTarget("sys.network", "Network Settings", "System", "Wireless & network") { Intent(Settings.ACTION_WIRELESS_SETTINGS) },
        SettingTarget("sys.security", "Security Settings", "System", "") { Intent(Settings.ACTION_SECURITY_SETTINGS) },
        SettingTarget("sys.about", "About Phone", "System", "") { Intent(Settings.ACTION_DEVICE_INFO_SETTINGS) },

        SettingTarget("adv.overlay", "Special App Access: Display over other apps", "Advanced", "List of apps with overlay access") { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION) },
        SettingTarget("adv.install", "Special App Access: Install unknown apps", "Advanced", "List of apps allowed to request installs") { Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES) },
        SettingTarget("adv.battery", "Battery Optimization Information", "Advanced", "") { Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) },
        SettingTarget("adv.notiflistener", "Notification Access Information", "Advanced", "Apps allowed to read notifications") { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
        SettingTarget("adv.input", "Language and Input", "Advanced", "") { Intent(Settings.ACTION_INPUT_METHOD_SETTINGS) },
        SettingTarget("adv.defaults", "Default Applications", "Advanced", "") { Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS) }
    )

    val groups = listOf("Application", "System", "Advanced")

    fun find(id: String) = targets.firstOrNull { it.id == id }

    fun launch(ctx: Context, t: SettingTarget): Pair<Boolean, String> = Intents.start(ctx, t.build(ctx), t.title)

    fun launchSettingsHome(ctx: Context) = Intents.start(ctx, Intent(Settings.ACTION_SETTINGS), "Android Settings")

    @Suppress("unused")
    fun packageUri(c: Context) = pkg(c)
}
