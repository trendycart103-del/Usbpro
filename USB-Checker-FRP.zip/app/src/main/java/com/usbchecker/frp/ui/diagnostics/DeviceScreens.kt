package com.usbchecker.frp.ui.diagnostics

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.KvCard
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.ui.common.writeToUri
import com.usbchecker.frp.utils.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun DeviceInfoScreen(onBack: () -> Unit) {
    val c = (LocalContext.current.applicationContext as FrpApp).container
    var data by remember { mutableStateOf<Map<String, List<Pair<String, String>>>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableStateOf(0) }
    androidx.compose.runtime.LaunchedEffect(tick) {
        loading = true
        data = withContext(Dispatchers.IO) { runCatching { c.device.all() }.getOrDefault(emptyMap()) }
        loading = false
    }
    ScreenScaffold("Device Information", onBack) { snack ->
        GradientButton(Tr.t("Refresh"), { tick++; snack("Refreshed") }, icon = Icons.Filled.Refresh)
        Loading(loading)
        data.entries.forEachIndexed { i, (k, v) -> KvCard(k, v, Brand.Cyan, expanded = i == 0) }
    }
}

@Composable
fun DeviceDiagnosticsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val c = (ctx.applicationContext as FrpApp).container
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<Map<String, List<Pair<String, String>>>>(emptyMap()) }
    var running by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<JSONObject>>(emptyList()) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch { writeToUri(ctx, uri, c.device.report()) }
    }

    fun run(snack: (String) -> Unit) {
        scope.launch {
            running = true
            report = withContext(Dispatchers.IO) { runCatching { c.device.all() }.getOrDefault(emptyMap()) }
            running = false
            snack(if (report.isEmpty()) "Diagnostics failed" else "Diagnostics finished")
        }
    }

    ScreenScaffold("Device Diagnostics", onBack) { snack ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GradientButton("Run Diagnostics", { run(snack) }, enabled = !running)
            OutlinedButton(onClick = { run(snack) }, enabled = !running) { Text(Tr.t("Refresh")) }
        }
        Loading(running)
        report.entries.forEachIndexed { i, (k, v) -> KvCard(k, v, Brand.Blue, i == 0) }
        if (report.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                scope.launch(Dispatchers.IO) {
                    c.diagHistory.append(JSONObject().put("t", Fmt.time(System.currentTimeMillis())).put("text", c.device.report().take(20000)))
                }
                snack("Report saved to history")
            }) { Text(Tr.t("Save") + " Report") }
            OutlinedButton(onClick = { exporter.launch("usb-checker-frp-report.txt") }) { Text(Tr.t("Export") + " Report") }
        }
        OutlinedButton(onClick = {
            showHistory = !showHistory
            if (showHistory) scope.launch { history = withContext(Dispatchers.IO) { c.diagHistory.readAll().asReversed() } }
        }) { Text("View Diagnostic History") }
        if (showHistory) {
            if (history.isEmpty()) FrpCard { Text("No saved reports.") }
            history.forEach { h ->
                var open by remember { mutableStateOf(false) }
                FrpCard {
                    OutlinedButton(onClick = { open = !open }) { Text(h.optString("t")) }
                    if (open) Text(h.optString("text"), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
        SectionTitle("Restricted data fields")
        FrpCard {
            Text("Android hides some data from normal apps: Wi-Fi name (needs location permission), device serial/IMEI, installed-app inventory beyond launcher apps, and per-app battery use. This app does not request those permissions and reports them as restricted.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

