package com.usbchecker.frp.ui.terminal

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.ui.common.TermKind

@Composable
fun TerminalScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    val ctx = LocalContext.current
    val lines = vm.terminal.collectAsStateWithLifecycle().value
    val running = vm.running.collectAsStateWithLifecycle().value
    var input by rememberSaveable { mutableStateOf("") }
    val state = rememberLazyListState()
    val suggestions = vm.suggestions(input)

    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) state.animateScrollToItem(lines.lastIndex) }

    fun submit() { vm.submit(input); input = "" }

    ScreenScaffold("Terminal", onBack, scroll = false) { snack ->
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().background(Color(0xFF02060F), RoundedCornerShape(14.dp)).padding(10.dp),
            state = state
        ) {
            items(lines) { l ->
                Text(
                    l.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    color = when (l.kind) {
                        TermKind.INPUT -> Brand.Cyan; TermKind.OUT -> Brand.Green
                        TermKind.ERR -> Brand.Red; TermKind.INFO -> Brand.TextSecondary
                    }
                )
            }
        }
        if (suggestions.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(suggestions) { s -> AssistChip(onClick = { input = s }, label = { Text(s, fontSize = 11.sp) }) }
        }
        OutlinedTextField(
            value = input, onValueChange = { input = it.filter { ch -> ch.isLetterOrDigit() || ch == '.' || ch == ' ' }.take(48) },
            modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = running.isEmpty(),
            placeholder = { Text("usb.scan  |  help") }, textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send, keyboardType = KeyboardType.Ascii),
            keyboardActions = KeyboardActions(onSend = { submit() })
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { submit() }, enabled = input.isNotBlank() && running.isEmpty()) { Text(Tr.t("Run")) }
            OutlinedButton(onClick = { vm.clearTerminal() }) { Text(Tr.t("Clear")) }
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("terminal", vm.terminalText()))
                snack("Output copied")
            }) { Text(Tr.t("Copy")) }
        }
    }
}
