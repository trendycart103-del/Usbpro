package com.usbchecker.frp.ui.floating

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.Modifier
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.data.AppSettings
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.utils.Intents
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState

@Composable
fun FloatingScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val c = (ctx.applicationContext as FrpApp).container
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) { tick++; onPauseOrDispose { } }
    val s = c.prefs.settings.collectAsState(initial = AppSettings()).value
    val granted = remember(tick) { Settings.canDrawOverlays(ctx) }

    ScreenScaffold("Floating Control Panel", onBack) { snack ->
        SectionTitle("In-app quick panel (no permission needed)")
        FrpCard {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Show quick-action bubble inside this app")
                Switch(s.inAppPanel, { scope.launch { c.prefs.setInAppPanel(it) } })
            }
            Text("Shortcuts: USB Scanner, Device Information, Diagnostics, Command Center, Settings, Hide, Close.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("Overlay bubble outside the app (optional)")
        FrpCard {
            Text("Why overlay permission? Only to draw the bubble above other apps. Android requires you to grant 'Display over other apps' yourself in Settings. This app never requests it automatically and never imitates a system dialog.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            StatusChip(if (granted) "Overlay access granted" else "Overlay access not granted", if (granted) Brand.Green else Brand.Yellow)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    snack(Intents.start(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")), "Overlay permission settings").second)
                }) { Text("Open overlay settings") }
                OutlinedButton(enabled = granted, onClick = {
                    try {
                        ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingService::class.java))
                        snack("Start requested. The bubble appears only if Android allows the service to run.")
                    } catch (e: Exception) { snack("Could not start the floating service: ${e.javaClass.simpleName}") }
                }) { Text("Start bubble") }
                OutlinedButton(onClick = { ctx.stopService(Intent(ctx, FloatingService::class.java)); snack("Stop requested") }) { Text("Stop") }
            }
            Text("Android may stop background services on some devices; the overlay is best-effort.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
