package com.usbchecker.frp.ui.apkmanager

import android.app.Application
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.utils.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class ApkInfo(
    val file: File, val fileName: String, val label: String, val pkg: String, val versionName: String,
    val versionCode: Long, val minSdk: Int, val targetSdk: Int, val size: Long, val sha256: String,
    val certs: List<String>, val sizeMatches: Boolean
)

class ApkViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FrpApp).container
    private val _info = MutableStateFlow<ApkInfo?>(null)
    val info: StateFlow<ApkInfo?> = _info.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _history = MutableStateFlow<List<JSONObject>>(emptyList())
    val history: StateFlow<List<JSONObject>> = _history.asStateFlow()

    init { loadHistory() }

    fun loadHistory() {
        viewModelScope.launch { _history.value = withContext(Dispatchers.IO) { c.apkHistory.readAll().asReversed() } }
    }

    fun load(uri: Uri) {
        _busy.value = true; _error.value = null
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { parse(uri) }
                _info.value = info
                withContext(Dispatchers.IO) {
                    c.apkHistory.append(JSONObject().put("t", Fmt.time(System.currentTimeMillis())).put("name", info.fileName)
                        .put("pkg", info.pkg).put("ver", info.versionName).put("sha", info.sha256).put("size", info.size))
                }
                loadHistory()
            } catch (e: Exception) {
                _info.value = null
                _error.value = e.message ?: "Could not read this file."
            } finally {
                _busy.value = false
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun parse(uri: Uri): ApkInfo {
        val ctx = getApplication<Application>()
        var name = "selected.apk"; var declared = -1L
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) {
                it.getString(0)?.let { n -> name = n.take(120) }
                if (!it.isNull(1)) declared = it.getLong(1)
            }
        }
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
        val dest = File(dir, "selected.apk")
        val md = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open the selected file.")
        input.use { ins ->
            dest.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n); out.write(buf, 0, n); total += n
                    if (total > 1_500_000_000L) throw IllegalStateException("File is too large (limit 1.5 GB).")
                }
            }
        }
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val pm = ctx.packageManager
        val pi = pm.getPackageArchiveInfo(dest.absolutePath, flags)
            ?: throw IllegalStateException("Not a valid APK: Android could not parse the package.")
        val ai = pi.applicationInfo
        ai?.sourceDir = dest.absolutePath
        ai?.publicSourceDir = dest.absolutePath
        val label = ai?.let { runCatching { it.loadLabel(pm).toString() }.getOrNull() } ?: "(unknown)"
        val sigs = if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
        val certs = sigs?.map { Fmt.sha256(it.toByteArray()) }.orEmpty()
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        return ApkInfo(
            dest, name, label, pi.packageName, pi.versionName ?: "?", code,
            ai?.minSdkVersion ?: -1, ai?.targetSdkVersion ?: -1, total,
            Fmt.hex(md.digest()), certs, declared < 0 || declared == total
        )
    }
}
