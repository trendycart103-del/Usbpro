package com.usbchecker.frp.ui.usb

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.core.compatibility.Compat
import com.usbchecker.frp.core.usb.UsbDeviceInfo
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.CapabilityRow
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.ui.common.CommandPanel
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold

@Composable
fun UsbScannerScreen(onBack: () -> Unit) {
    val vm: UsbViewModel = viewModel()
    val devices = vm.devices.collectAsStateWithLifecycle().value
    val event = vm.event.collectAsStateWithLifecycle().value
    val transfer = vm.transfer.collectAsStateWithLifecycle().value
    val busy = vm.busy.collectAsStateWithLifecycle().value
    val history = vm.history.collectAsStateWithLifecycle().value

    ScreenScaffold("USB Scanner", onBack) { snack ->
        GradientButton(Tr.t("Refresh"), { vm.refresh(); snack("Scan complete: ${vm.devices.value.size} device(s)") }, icon = Icons.Filled.Refresh)
        event?.let { Text(it, color = Brand.Yellow) }
        if (devices.isEmpty()) {
            FrpCard { Text("No USB device attached. Connect a peripheral through an OTG adapter, then tap Refresh.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        devices.forEach { d -> DeviceCard(d, vm, transfer[d.name], d.name in busy, snack) }
        SectionTitle("USB Connection History")
        FrpCard {
            if (history.isEmpty()) Text("No events recorded yet (events are captured while the app runs).", color = MaterialTheme.colorScheme.onSurfaceVariant)
            history.take(20).forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun DeviceCard(d: UsbDeviceInfo, vm: UsbViewModel, transfer: String?, busy: Boolean, snack: (String) -> Unit) {
    ExpandCard("${d.vidPid}  ${d.product ?: d.name}", Brand.Cyan, initiallyExpanded = true) {
        StatusChip(if (d.hasPermission) "Permission granted" else "Permission required", if (d.hasPermission) Brand.Green else Brand.Yellow)
        KvRow("Device name", d.name)
        KvRow("Vendor ID", "0x" + com.usbchecker.frp.core.usb.UsbClassify.hex4(d.vid))
        KvRow("Product ID", "0x" + com.usbchecker.frp.core.usb.UsbClassify.hex4(d.pid))
        KvRow("Manufacturer", d.manufacturer ?: "Unavailable (shown after permission, if reported)")
        KvRow("Product", d.product ?: "Unavailable (shown after permission, if reported)")
        KvRow("USB version", d.usbVersion ?: "Unknown")
        KvRow("Device class", com.usbchecker.frp.core.usb.UsbClassify.className(d.cls))
        d.interfaces.forEach { i ->
            Text("Interface ${i.id}: ${i.clsName}${i.hidKind?.let { " – $it" } ?: ""}", color = Brand.Electric)
            i.endpoints.forEach { e ->
                Text("   EP 0x%02X  %s %s  max %d  interval %d".format(e.address, e.type, e.direction, e.maxPacket, e.interval),
                    fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { vm.requestPermission(d.name) { snack(it) } }, enabled = !d.hasPermission) { Text("Request permission") }
            OutlinedButton(onClick = { vm.test(d.name) { snack(it) } }, enabled = d.hasPermission && !busy) { Text("Test transfer") }
        }
        Loading(busy)
        transfer?.let { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Brand.Cyan) }
    }
}

@Composable
fun UsbDiagnosticsScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    val ctx = LocalContext.current
    ScreenScaffold("USB Diagnostics", onBack) { snack ->
        FrpCard { Compat.usbHost(ctx).forEach { CapabilityRow(it) } }
        CommandPanel(
            listOf("usb.scan", "usb.detect", "usb.device.info", "usb.interfaces", "usb.permission.request",
                "usb.connection.status", "usb.hid.detect", "usb.hid.capability", "usb.accessory.detect",
                "usb.transfer.status", "usb.disconnect"), vm, snack
        )
    }
}

@Composable
fun HostToolsScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    val ctx = LocalContext.current
    ScreenScaffold("USB Host Tools", onBack) { snack ->
        Text("Three separate local capability areas. These describe this phone only; nothing here controls another device.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        ExpandCard("MODE A: USB HOST", Brand.Blue, true) {
            Text("Detect peripherals, inspect interfaces, request permission, test supported data communication.")
            Compat.usbHost(ctx).forEach { CapabilityRow(it) }
            CommandPanel(listOf("usb.scan", "usb.interfaces", "usb.permission.request", "usb.transfer.status"), vm, snack)
        }
        ExpandCard("MODE B: USB HID COMPATIBILITY", Brand.Purple) {
            Text("Inspect HID support, mouse/keyboard compatibility, and the hardware/kernel requirements for gadget mode.")
            Compat.hid(ctx).forEach { CapabilityRow(it) }
            CommandPanel(listOf("usb.hid.detect", "usb.hid.capability"), vm, snack)
        }
        ExpandCard("MODE C: USB ACCESSORY / GADGET INFORMATION", Brand.Cyan) {
            Text("Accessory interfaces and gadget requirements. Unsupported operations are reported as such.")
            Compat.accessory(ctx).forEach { CapabilityRow(it) }
            CommandPanel(listOf("usb.accessory.detect"), vm, snack)
        }
    }
}

@Composable
fun AccessoryScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    val ctx = LocalContext.current
    ScreenScaffold("USB Accessory Tools", onBack) { snack ->
        FrpCard { Compat.accessory(ctx).forEach { CapabilityRow(it) } }
        FrpCard {
            Text("Requirements", style = MaterialTheme.typography.titleMedium)
            Text("USB accessory mode makes the phone behave as a peripheral to an external host that speaks the Android Open Accessory protocol. " +
                "A normal app cannot start it; it only observes accessories that Android has already attached. " +
                "USB gadget modes (HID, mass storage) need kernel configfs support and are not available to ordinary apps.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        CommandPanel(listOf("usb.accessory.detect"), vm, snack)
    }
}

