package com.usbchecker.frp.core.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.usbchecker.frp.utils.Intents

enum class PermKind { RUNTIME, SPECIAL_OVERLAY, SPECIAL_INSTALL, LISTENER, ACCESSIBILITY, SAF }

data class PermItem(
    val id: String, val title: String, val type: String, val why: String, val kind: PermKind,
    val manifestPerm: String? = null, val declared: Boolean = false
) {
    /** Request is offered only for permissions this app genuinely declares and that exist as runtime permissions. */
    val requestable: Boolean get() = kind == PermKind.RUNTIME && declared && manifestPerm != null &&
        !(manifestPerm == Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33)
}

object PermissionCenter {
    val items = listOf(
        PermItem("camera", "Camera", "Runtime (dangerous)", "Not used by any feature. Never requested.", PermKind.RUNTIME, Manifest.permission.CAMERA),
        PermItem("mic", "Microphone", "Runtime (dangerous)", "Not used by any feature. Never requested.", PermKind.RUNTIME, Manifest.permission.RECORD_AUDIO),
        PermItem("notif", "Notifications", "Runtime (Android 13+)", "Lets the floating-panel foreground notification be visible.", PermKind.RUNTIME, Manifest.permission.POST_NOTIFICATIONS, true),
        PermItem("bt", "Bluetooth", "Runtime (Android 12+: BLUETOOTH_CONNECT)", "Only adapter on/off state is read, which needs no permission. Not requested.", PermKind.RUNTIME, "android.permission.BLUETOOTH_CONNECT"),
        PermItem("loc", "Location", "Runtime (dangerous)", "Would be needed to read the Wi-Fi name. Not requested.", PermKind.RUNTIME, Manifest.permission.ACCESS_FINE_LOCATION),
        PermItem("nearby", "Nearby Devices", "Runtime (Android 13+)", "Not used. Not requested.", PermKind.RUNTIME, "android.permission.NEARBY_WIFI_DEVICES"),
        PermItem("files", "Files", "Storage Access Framework", "APK Manager and exports use the system file picker; no storage permission exists in this app.", PermKind.SAF),
        PermItem("a11y", "Accessibility", "Special access", "This app provides no accessibility service. Page lists services enabled on the device.", PermKind.ACCESSIBILITY),
        PermItem("listener", "Notification Listener", "Special access", "This app does not read notifications. Page lists apps that can.", PermKind.LISTENER),
        PermItem("overlay", "Special App Access: Display over other apps", "Special access (user-granted in Settings)", "Only needed for the optional floating bubble outside the app.", PermKind.SPECIAL_OVERLAY),
        PermItem("install", "Special App Access: Install unknown apps", "Special access (user-granted in Settings)", "Needed to hand an APK to the Android package installer.", PermKind.SPECIAL_INSTALL)
    )

    fun status(ctx: Context, p: PermItem): String = when (p.kind) {
        PermKind.RUNTIME -> when {
            p.manifestPerm == Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33 ->
                if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) "Granted (no runtime prompt below Android 13)" else "Disabled in Settings"
            !p.declared -> "Not requested by this app"
            ContextCompat.checkSelfPermission(ctx, p.manifestPerm!!) == PackageManager.PERMISSION_GRANTED -> "Granted"
            else -> "Denied / not yet granted"
        }
        PermKind.SPECIAL_OVERLAY -> if (Settings.canDrawOverlays(ctx)) "Granted" else "Not granted"
        PermKind.SPECIAL_INSTALL -> if (ctx.packageManager.canRequestPackageInstalls()) "Granted" else "Not granted"
        PermKind.LISTENER -> if (NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)) "Enabled" else "Not enabled (not used)"
        PermKind.ACCESSIBILITY -> "No service provided by this app"
        PermKind.SAF -> "No permission needed"
    }

    fun openSettings(ctx: Context, p: PermItem): Pair<Boolean, String> {
        val pkg = Uri.parse("package:${ctx.packageName}")
        val intent = when (p.kind) {
            PermKind.SPECIAL_OVERLAY -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
            PermKind.SPECIAL_INSTALL -> Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkg)
            PermKind.LISTENER -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            PermKind.ACCESSIBILITY -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intents.appDetails(ctx)
        }
        return Intents.start(ctx, intent, p.title)
    }

    /** Permissions this app declared in its manifest with granted flag. */
    @Suppress("DEPRECATION")
    fun requestedPermissions(ctx: Context): List<Pair<String, Boolean>> = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS)
        val names = pi.requestedPermissions ?: emptyArray()
        val flags = pi.requestedPermissionsFlags ?: IntArray(0)
        names.mapIndexed { i, n -> n to (flags.getOrNull(i)?.and(android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) }
    } catch (e: Exception) {
        emptyList()
    }
}
