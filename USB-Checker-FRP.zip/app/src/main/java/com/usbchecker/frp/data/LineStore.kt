package com.usbchecker.frp.data

import org.json.JSONObject
import java.io.File
import java.io.IOException

/** Small JSON-lines store with a hard line limit (log rotation). Thread-safe. */
class LineStore(private val file: File, private val maxLines: Int = 500) {
    private val lock = Any()

    private fun rawLines(): List<String> =
        try {
            if (file.exists()) file.readLines().filter { it.isNotBlank() } else emptyList()
        } catch (e: IOException) {
            emptyList()
        }

    fun append(obj: JSONObject) {
        synchronized(lock) {
            try {
                file.parentFile?.mkdirs()
                val lines = rawLines().toMutableList()
                lines.add(obj.toString())
                val kept = if (lines.size > maxLines) lines.takeLast(maxLines) else lines
                val tmp = File(file.path + ".tmp")
                tmp.writeText(kept.joinToString("\n") + "\n")
                if (!tmp.renameTo(file)) {
                    file.writeText(kept.joinToString("\n") + "\n")
                    tmp.delete()
                }
            } catch (e: IOException) {
                // Storage failure must never crash the app.
            }
        }
    }

    /** Oldest first. Corrupt lines are skipped. */
    fun readAll(): List<JSONObject> = synchronized(lock) {
        rawLines().mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
    }

    fun clear() {
        synchronized(lock) { runCatching { file.delete() } }
    }

    fun sizeBytes(): Long = if (file.exists()) file.length() else 0L
}
