package com.usbchecker.frp.ui.floating

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.usbchecker.frp.MainActivity

/** Optional overlay bubble. Started only after the user enabled it AND granted overlay access in Android Settings. */
class FloatingService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        startForegroundNotice()
        if (root == null) addBubble()
        return START_NOT_STICKY
    }

    private fun startForegroundNotice() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating panel", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("USB Checker FRP floating panel")
            .setContentText("Tap the bubble for quick actions. Close it from the bubble menu.")
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 41, n, if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun open(route: String) {
        startActivity(Intent(this, MainActivity::class.java).putExtra("route", route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        setMenu(false)
    }

    private var menu: LinearLayout? = null
    private var bubble: TextView? = null

    private fun setMenu(show: Boolean) { menu?.visibility = if (show) View.VISIBLE else View.GONE }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }

        val m = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        fun item(label: String, action: () -> Unit) {
            m.addView(Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } })
        }
        item("USB Scanner") { open("scanner") }
        item("Device Information") { open("device_info") }
        item("Diagnostics") { open("device_diag") }
        item("Command Center") { open("commands") }
        item("Settings") { open("app_settings") }
        item("Hide") { setMenu(false); bubble?.alpha = 0.3f }
        item("Close") { stopSelf() }
        menu = m

        val b = TextView(this).apply {
            text = "USB"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 12f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF087BFF.toInt()); setStroke(dp(2), 0xFF00E5FF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }
        bubble = b
        box.addView(m); box.addView(b)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(200) }
        params = lp

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = sx + dx; lp.y = sy + dy; runCatching { manager.updateViewLayout(box, lp) } }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) { b.alpha = 1f; setMenu(menu?.visibility != View.VISIBLE) }
                    true
                }
                else -> false
            }
        }
        try {
            manager.addView(box, lp)
            root = box
        } catch (e: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        root?.let { v -> runCatching { wm?.removeView(v) } }
        root = null
        super.onDestroy()
    }

    companion object { const val CHANNEL = "floating_panel" }
}
