package com.usbchecker.frp.ui.apkmanager

import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.utils.Intents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class AppRow(val label: String, val pkg: String, val version: String)

@Composable
fun AppManagerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    val loaded = produceState<List<AppRow>?>(null) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0).mapNotNull { ri ->
                val p = ri.activityInfo?.packageName ?: return@mapNotNull null
                val v = try { pm.getPackageInfo(p, 0).versionName ?: "?" } catch (e: PackageManager.NameNotFoundException) { "?" }
                AppRow(ri.loadLabel(pm).toString(), p, v)
            }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        }
    }.value
    val list = loaded?.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }.orEmpty()

    ScreenScaffold("Application Manager", onBack, scroll = false) { snack ->
        OutlinedTextField(query, { query = it.take(40) }, Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Search apps") })
        Text("Lists launchable apps only. Android's package-visibility rules hide the rest from this app.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Loading(loaded == null)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.pkg }) { a ->
                ExpandCard(a.label, Brand.Electric) {
                    KvRow("Package", a.pkg); KvRow("Version", a.version)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { snack(Intents.start(ctx, Intents.appDetails(ctx, a.pkg), a.label).second) }) { Text("App details") }
                        OutlinedButton(onClick = {
                            val li = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
                            snack(if (li == null) "No launch intent for ${a.label}" else Intents.start(ctx, li, a.label).second)
                        }) { Text("Open app") }
                    }
                }
            }
        }
    }
}
