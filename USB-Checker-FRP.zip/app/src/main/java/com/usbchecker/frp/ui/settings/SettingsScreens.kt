package com.usbchecker.frp.ui.settings

import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.core.permissions.SettingsLauncher
import com.usbchecker.frp.data.AppSettings
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.ui.common.writeToUri
import com.usbchecker.frp.utils.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun SettingsLauncherScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    ScreenScaffold("Settings Launcher", onBack) { snack ->
        Text("Opens only the pages Android exposes. Pages missing on your ROM are reported, never faked. Nothing is changed silently.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        SettingsLauncher.groups.forEach { g ->
            ExpandCard("${g.uppercase()} SETTINGS", Brand.Yellow, g == "Application") {
                SettingsLauncher.targets.filter { it.group == g }.forEach { t ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(t.title + if (t.note.isNotBlank()) "\n${t.note}" else "", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onClick = { snack(SettingsLauncher.launch(ctx, t).second) }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vm: CommandViewModel = viewModel()
    val logs = vm.logs.collectAsStateWithLifecycle().value
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("All") }
    var confirmClear by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadLogs() }

    val shown = logs.filter {
        (filter == "All" || it.execution == filter) &&
            (query.isBlank() || it.command.contains(query, true) || it.result.contains(query, true) || it.error.contains(query, true))
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch { writeToUri(ctx, uri, shown.joinToString("\n") { it.asLine() + "\n    " + it.result.replace("\n", "\n    ") }) }
    }

    ScreenScaffold("Execution Logs", onBack, scroll = false) { snack ->
        OutlinedTextField(query, { query = it.take(40) }, Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Search logs") })
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(listOf("All", "Success", "Partial", "Needs user action", "Failed", "Rejected", "Unsupported")) { f ->
                FilterChip(filter == f, { filter = f }, { Text(f) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.loadLogs(); snack("Logs reloaded") }) { Text("View Logs") }
            OutlinedButton(onClick = { exporter.launch("usb-checker-frp-logs.txt") }, enabled = shown.isNotEmpty()) { Text(Tr.t("Export")) }
            OutlinedButton(onClick = { confirmClear = true }) { Text("Clear Local Logs") }
        }
        if (confirmClear) FrpCard {
            Text("Delete all local logs? This cannot be undone.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.clearLogs(); confirmClear = false; snack("Logs cleared") }) { Text("Delete") }
                OutlinedButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        }
        Text("${shown.size} entries · rotated at 500 · no passwords or tokens are ever stored", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown) { l ->
                ExpandCard("${l.command}  →  ${l.execution}", if (l.execution == "Success") Brand.Green else Brand.Yellow) {
                    KvRow("Date / Time", l.time); KvRow("Local device", l.device)
                    KvRow("Request status", l.request); KvRow("Execution status", l.execution)
                    if (l.error.isNotBlank()) Text("Error: ${l.error}", color = Brand.Red, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    if (l.result.isNotBlank()) Text(l.result, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun AppSettingsScreen(onBack: () -> Unit, s: AppSettings) {
    val ctx = LocalContext.current
    val c = (ctx.applicationContext as FrpApp).container
    val scope = rememberCoroutineScope()
    var version by remember { mutableStateOf("") }
    var sizes by remember { mutableStateOf("…") }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(tick) {
        withContext(Dispatchers.IO) {
            version = try {
                @Suppress("DEPRECATION") ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
            } catch (e: PackageManager.NameNotFoundException) { "?" }
            sizes = "Cache ${Fmt.bytes(c.device.cacheBytes())} · Data ${Fmt.bytes(c.device.dataBytes())}"
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) { c.logs.readAll().joinToString("\n") { it.toString() } }
            writeToUri(ctx, uri, text)
        }
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    ScreenScaffold("Application Settings", onBack) { snack ->
        FrpCard {
            SwitchRow("Dark theme", s.dark) { scope.launch { c.prefs.setDark(it) } }
            SwitchRow("Animations", s.animations) { scope.launch { c.prefs.setAnimations(it) } }
            SwitchRow("In-app floating quick panel", s.inAppPanel) { scope.launch { c.prefs.setInAppPanel(it) } }
        }
        SectionTitle(Tr.t("Language"))
        FrpCard {
            listOf("en" to "English", "bn" to "বাংলা (Bengali)").forEach { (code, name) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.lang == code, onClick = { scope.launch { c.prefs.setLang(code) } }); Text(name)
                }
            }
        }
        SectionTitle("Notifications")
        FrpCard {
            Text("Used only for the optional floating-panel service notification.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (android.os.Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    else snack("Below Android 13 no runtime permission exists.")
                }) { Text("Request permission") }
                OutlinedButton(onClick = {
                    val t = SettingsLauncher.find("app.notifications")!!
                    snack(SettingsLauncher.launch(ctx, t).second)
                }) { Text("Android settings") }
            }
        }
        SectionTitle("Storage Management")
        FrpCard {
            Text(sizes)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    scope.launch(Dispatchers.IO) { ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                    tick++; snack("Cache cleared")
                }) { Text("Clear Cache") }
                OutlinedButton(onClick = { exporter.launch("usb-checker-frp-logs.jsonl") }) { Text("Export Application Logs") }
            }
            val crash = File(ctx.filesDir, "crash.log")
            if (crash.exists()) Text("Last error report (${Fmt.bytes(crash.length())}) is stored locally.", fontSize = 12.sp, color = Brand.Yellow)
        }
        SectionTitle("About Application")
        FrpCard {
            KvRow("Name", "USB Checker FRP"); KvRow("Version", version); KvRow("Package", ctx.packageName)
            Text("Privacy: all data stays on this device. No analytics, no account, no passwords or OTPs collected. Internet is used only for one connectivity test you start and for opening official web pages in your browser.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(Tr.t(label)); Switch(checked, onChange)
    }
}

