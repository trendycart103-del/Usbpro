package com.usbchecker.frp.core.commands

import android.content.Context
import com.usbchecker.frp.core.diagnostics.DeviceInspector
import com.usbchecker.frp.core.usb.UsbInspector
import org.json.JSONObject

enum class ExecStatus(val label: String) {
    SUCCESS("Success"), PARTIAL("Partial"), NEEDS_USER_ACTION("Needs user action"),
    UNSUPPORTED("Unsupported"), FAILED("Failed"), REJECTED("Rejected")
}

data class CommandResult(val status: ExecStatus, val output: String, val error: String? = null)

data class ExecResult(val command: String, val result: CommandResult, val durationMs: Long)

class CommandEnv(val ctx: Context, val usb: UsbInspector, val device: DeviceInspector)

data class CommandDef(
    val id: String,
    val description: String,
    val effect: String,
    val timeoutMs: Long = 8_000,
    val run: suspend (CommandEnv) -> CommandResult
) {
    val category: String get() = id.substringBefore('.')
}

data class LogEntry(
    val ts: Long, val time: String, val device: String, val command: String,
    val request: String, val execution: String, val error: String, val result: String
) {
    fun toJson(): JSONObject = JSONObject().put("ts", ts).put("time", time).put("device", device)
        .put("cmd", command).put("req", request).put("exec", execution).put("err", error).put("res", result)

    fun asLine() = "$time | $device | $command | req=$request | exec=$execution" +
        (if (error.isNotBlank()) " | error=$error" else "")

    companion object {
        fun from(o: JSONObject) = LogEntry(
            o.optLong("ts"), o.optString("time"), o.optString("device"), o.optString("cmd"),
            o.optString("req"), o.optString("exec"), o.optString("err"), o.optString("res")
        )
    }
}
