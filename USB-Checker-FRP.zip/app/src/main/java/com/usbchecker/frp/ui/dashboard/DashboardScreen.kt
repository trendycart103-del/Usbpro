package com.usbchecker.frp.ui.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.data.AppSettings
import com.usbchecker.frp.designsystem.AppLogo
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.navigation.Screen
import com.usbchecker.frp.ui.common.CommandViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.rememberCoroutineScope
import android.os.Build

private data class Snapshot(val battery: String, val storage: String)

@Composable
fun DashboardScreen(go: (String) -> Unit, settings: AppSettings) {
    val ctx = LocalContext.current
    val c = (ctx.applicationContext as FrpApp).container
    val vm: CommandViewModel = viewModel()
    val devices by c.monitor.devices.collectAsStateWithLifecycle()
    val event by c.monitor.lastEvent.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }

    val snap by produceState(Snapshot("…", "…")) {
        value = withContext(Dispatchers.IO) {
            Snapshot(c.device.batteryPercent()?.let { "$it%" } ?: "Unavailable", c.device.storageSummary())
        }
    }
    val hidCount = devices.sumOf { it.hidInterfaces.size }
    val shortcuts = Screen.entries.filter { query.isBlank() || Tr.t(it.title).contains(query, true) || it.title.contains(query, true) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AppLogo(76.dp)
                Column(Modifier.weight(1f)) {
                    Text("USB Checker FRP", style = MaterialTheme.typography.headlineMedium)
                    Text("USB diagnostics · device info · official recovery", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilterChip(selected = settings.lang == "bn", onClick = {
                    scope.launch { c.prefs.setLang(if (settings.lang == "bn") "en" else "bn") }
                }, label = { Text(if (settings.lang == "bn") "বাংলা" else "EN") })
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            FrpCard {
                KvRow(Tr.t("Manufacturer"), Build.MANUFACTURER)
                KvRow(Tr.t("Brand"), Build.BRAND)
                KvRow(Tr.t("Model"), Build.MODEL)
                KvRow(Tr.t("Android"), Build.VERSION.RELEASE)
                KvRow(Tr.t("SDK level"), Build.VERSION.SDK_INT.toString())
                KvRow(Tr.t("Battery"), snap.battery)
                KvRow(Tr.t("Storage"), snap.storage)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip("${Tr.t("USB Host")}: " + if (c.usb.hostSupported) Tr.t("Available") else Tr.t("Unavailable"),
                        if (c.usb.hostSupported) Brand.Green else Brand.Red)
                    StatusChip(if (devices.isNotEmpty()) "${Tr.t("Connected")}: ${devices.size}" else Tr.t("Not connected"),
                        if (devices.isNotEmpty()) Brand.Cyan else Brand.TextSecondary)
                }
                StatusChip("${Tr.t("HID")}: " + if (hidCount > 0) "$hidCount interface(s)" else "none detected",
                    if (hidCount > 0) Brand.Purple else Brand.TextSecondary)
                event?.let { Text(it, color = Brand.Yellow, style = MaterialTheme.typography.bodySmall) }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            OutlinedTextField(
                value = query, onValueChange = { query = it.take(40) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Filled.Search, null) },
                placeholder = { Text(Tr.t("Search features")) }, shape = RoundedCornerShape(16.dp)
            )
        }
        items(shortcuts, key = { it.route }) { s ->
            Card(
                modifier = Modifier.fillMaxWidth().height(112.dp).clickable { go(s.route) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, s.color.copy(alpha = 0.55f))
            ) {
                Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(s.icon, null, tint = s.color, modifier = Modifier.size(30.dp))
                    Text(Tr.t(s.title), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle(Tr.t("Recent Activity"))
                FrpCard {
                    if (logs.isEmpty()) Text(Tr.t("No activity yet"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    logs.take(4).forEach {
                        Text("${it.time}  ${it.command}  → ${it.execution}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(Modifier.height(72.dp))
            }
        }
    }
}

