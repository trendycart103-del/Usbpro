package com.usbchecker.frp.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "usb_checker_frp_prefs")

data class AppSettings(
    val lang: String = "en",
    val dark: Boolean = true,
    val animations: Boolean = true,
    val inAppPanel: Boolean = true
)

class Prefs(private val ctx: Context) {
    private val kLang = stringPreferencesKey("lang")
    private val kDark = booleanPreferencesKey("dark")
    private val kAnim = booleanPreferencesKey("animations")
    private val kPanel = booleanPreferencesKey("in_app_panel")

    val settings: Flow<AppSettings> = ctx.store.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { p: Preferences ->
            AppSettings(
                lang = p[kLang]?.takeIf { it == "en" || it == "bn" } ?: "en",
                dark = p[kDark] ?: true,
                animations = p[kAnim] ?: true,
                inAppPanel = p[kPanel] ?: true
            )
        }

    suspend fun setLang(v: String) { if (v == "en" || v == "bn") ctx.store.edit { it[kLang] = v } }
    suspend fun setDark(v: Boolean) { ctx.store.edit { it[kDark] = v } }
    suspend fun setAnimations(v: Boolean) { ctx.store.edit { it[kAnim] = v } }
    suspend fun setInAppPanel(v: Boolean) { ctx.store.edit { it[kPanel] = v } }
}
