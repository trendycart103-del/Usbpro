package com.usbchecker.frp.core.usb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.usbchecker.frp.data.LineStore
import com.usbchecker.frp.utils.Fmt
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Tracks attach/detach while the app process is alive and keeps a rotated history. */
class UsbMonitor(context: Context, private val usb: UsbInspector, private val store: LineStore) {
    private val ctx = context.applicationContext
    private var started = false

    private val _devices = MutableStateFlow<List<UsbDeviceInfo>>(emptyList())
    val devices: StateFlow<List<UsbDeviceInfo>> = _devices.asStateFlow()

    private val _event = MutableStateFlow<String?>(null)
    val lastEvent: StateFlow<String?> = _event.asStateFlow()

    private val _history = MutableStateFlow<List<String>>(emptyList())
    val history: StateFlow<List<String>> = _history.asStateFlow()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val d = IntentCompat.getParcelableExtra(i, UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            val id = d?.let { "${UsbClassify.hex4(it.vendorId)}:${UsbClassify.hex4(it.productId)}" } ?: "unknown"
            when (i.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> note("ATTACHED $id").also { _event.value = "Device attached: $id" }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> note("DETACHED $id").also { _event.value = "Device disconnected: $id" }
            }
            refresh()
        }
    }

    @Synchronized
    fun start() {
        if (started) return
        started = true
        _history.value = store.readAll().map { "${it.optString("t")}  ${it.optString("m")}" }.asReversed()
        val f = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        refresh()
    }

    fun refresh() { _devices.value = usb.devices() }

    fun note(message: String) {
        val t = Fmt.time(System.currentTimeMillis())
        store.append(JSONObject().put("t", t).put("m", message))
        _history.value = (listOf("$t  $message") + _history.value).take(200)
    }
}
