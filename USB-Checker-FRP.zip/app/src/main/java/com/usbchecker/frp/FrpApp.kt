package com.usbchecker.frp

import android.app.Application
import com.usbchecker.frp.data.Container
import java.io.File
import java.util.Date

class FrpApp : Application() {
    lateinit var container: Container
        private set

    override fun onCreate() {
        super.onCreate()
        installCrashHandler()
        container = Container(this)
        container.monitor.start()
    }

    /** Global error handling: persist a short crash report locally, then defer to the default handler. */
    private fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val f = File(filesDir, "crash.log")
                if (f.exists() && f.length() > 100_000) f.delete()
                f.appendText("${Date()} [${thread.name}]\n${error.stackTraceToString().take(4000)}\n\n")
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
