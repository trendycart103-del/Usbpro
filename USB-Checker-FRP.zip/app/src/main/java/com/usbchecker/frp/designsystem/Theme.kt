package com.usbchecker.frp.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object Brand {
    val Background = Color(0xFF050B1C)
    val Secondary = Color(0xFF0A1530)
    val Card = Color(0xFF101E3D)
    val Elevated = Color(0xFF16294F)
    val Blue = Color(0xFF087BFF)
    val Electric = Color(0xFF00BFFF)
    val Purple = Color(0xFF773CFF)
    val Cyan = Color(0xFF00E5FF)
    val Green = Color(0xFF16D96A)
    val Yellow = Color(0xFFFFB020)
    val Red = Color(0xFFFF405A)
    val Text = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFA9B8D0)
    val Border = Color(0xFF263D68)
    val Gradient = Brush.horizontalGradient(listOf(Blue, Purple))
}

val LocalAnimations = compositionLocalOf { true }

private val DarkScheme = darkColorScheme(
    primary = Brand.Blue, onPrimary = Brand.Text, secondary = Brand.Cyan, onSecondary = Brand.Background,
    tertiary = Brand.Purple, background = Brand.Background, onBackground = Brand.Text,
    surface = Brand.Secondary, onSurface = Brand.Text, surfaceVariant = Brand.Card,
    onSurfaceVariant = Brand.TextSecondary, outline = Brand.Border, error = Brand.Red,
    primaryContainer = Brand.Elevated, onPrimaryContainer = Brand.Text,
    surfaceContainer = Brand.Elevated, surfaceContainerHigh = Brand.Elevated
)

private val LightScheme = lightColorScheme(
    primary = Brand.Blue, onPrimary = Color.White, secondary = Color(0xFF007C99), tertiary = Brand.Purple,
    background = Color(0xFFF4F7FC), onBackground = Color(0xFF0A1530), surface = Color.White,
    onSurface = Color(0xFF0A1530), surfaceVariant = Color(0xFFE6EEFA), onSurfaceVariant = Color(0xFF4A5B78),
    outline = Color(0xFFB8C6DD), error = Color(0xFFC62840)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 26.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
)

@Composable
fun FrpTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = AppTypography, content = content)
}

@Suppress("unused")
@Composable
fun systemDark() = isSystemInDarkTheme()
