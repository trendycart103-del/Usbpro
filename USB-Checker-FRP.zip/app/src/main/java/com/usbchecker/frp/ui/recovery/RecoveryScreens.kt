package com.usbchecker.frp.ui.recovery

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.ui.common.CommandPanel
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.ui.common.writeToUri
import com.usbchecker.frp.utils.Fmt
import com.usbchecker.frp.utils.Intents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun RepairScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    ScreenScaffold("Device Repair Assistant", onBack) { snack ->
        FrpCard {
            Text("This assistant diagnoses and guides. It does not repair hardware or firmware, and it cannot flash, unlock or modify system software.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ExpandCard("SOFTWARE", Brand.Blue, true) {
            Text("Android build, firmware and patch information, plus supported recovery information.")
            CommandPanel(listOf("device.info", "device.android.version", "security.device.status", "recovery.support"), vm, snack)
        }
        ExpandCard("NETWORK", Brand.Cyan) {
            Text("If DNS fails: toggle Wi-Fi, set Private DNS to Automatic in Network settings, or test another network.")
            CommandPanel(listOf("network.status", "network.wifi", "network.connection.test", "settings.wifi"), vm, snack)
        }
        ExpandCard("APPLICATION", Brand.Green) {
            Text("Battery usage guidance: open Battery settings from the Settings Launcher to see per-app usage on your ROM.")
            CommandPanel(listOf("app.info", "app.permissions", "app.notifications", "app.storage", "settings.notifications"), vm, snack)
        }
        ExpandCard("OFFICIAL RECOVERY", Brand.Purple) {
            CommandPanel(listOf("recovery.google", "recovery.manufacturer", "recovery.support", "recovery.owner.checklist", "recovery.frp.guide"), vm, snack)
        }
    }
}

private val checklist = listOf(
    "I know the Google account email used on this phone",
    "I know the account password or have its recovery phone/email",
    "I have proof of purchase (receipt/invoice)",
    "I have the device IMEI / box label",
    "I have a stable Wi-Fi connection",
    "I have another phone or computer for official recovery pages"
)

@Composable
fun RecoveryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val c = (ctx.applicationContext as FrpApp).container
    val vm: CommandViewModel = viewModel()
    val scope = rememberCoroutineScope()
    val checked = rememberSaveable(saver = androidx.compose.runtime.saveable.listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<Boolean>, Boolean>(
        save = { it.toList() }, restore = { it.toMutableStateList() }
    )) { mutableStateListOf(*Array(checklist.size) { false }) }
    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<JSONObject>>(emptyList()) }

    fun reportText(): String = buildString {
        appendLine("USB Checker FRP – Recovery Report")
        appendLine("Time: ${Fmt.time(System.currentTimeMillis())}")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.BRAND} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine("Security patch: ${Build.VERSION.SECURITY_PATCH}")
        appendLine("Owner checklist:")
        checklist.forEachIndexed { i, t -> appendLine("  [${if (checked[i]) "x" else " "}] $t") }
        appendLine("Note: this report records preparation only. No FRP bypass is performed or claimed.")
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch { writeToUri(ctx, uri, reportText()) }
    }

    ScreenScaffold("Recovery Assistant", onBack) { snack ->
        FrpCard {
            Text("Legitimate owner recovery only", style = MaterialTheme.typography.titleMedium, color = Brand.Purple)
            Text("This app does not bypass Factory Reset Protection, evade Google verification, remove locks or extract credentials. It never asks for your Google password, OTP or tokens.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("Device Identification")
        FrpCard {
            KvRow("Manufacturer", Build.MANUFACTURER); KvRow("Brand", Build.BRAND); KvRow("Model", Build.MODEL)
            KvRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"); KvRow("Security patch", Build.VERSION.SECURITY_PATCH)
            KvRow("Build", Build.DISPLAY)
            Text("IMEI and serial number are restricted by Android for normal apps. Dial *#06# or read the box label.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("Owner Checklist")
        FrpCard {
            checklist.forEachIndexed { i, t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked[i], { checked[i] = it }); Text(t, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        SectionTitle("Google Account Assistant")
        FrpCard {
            Text("Official interfaces only. Entering an email here would not authenticate anything, so no email field is offered.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { snack(Intents.url(ctx, "https://accounts.google.com/", "Google sign-in").second) }) { Text("Google sign-in") }
                OutlinedButton(onClick = { snack(Intents.url(ctx, "https://accounts.google.com/signin/recovery", "Account recovery").second) }) { Text("Account recovery") }
            }
            OutlinedButton(onClick = {
                snack(Intents.start(ctx, Intent(Settings.ACTION_ADD_ACCOUNT).putExtra(Settings.EXTRA_ACCOUNT_TYPES, arrayOf("com.google")), "Add Google account").second)
            }) { Text("Add Google account (Android system screen)") }
            Text("Security: enable 2-step verification and keep recovery phone/email current at myaccount.google.com. Sync trouble: check Wi-Fi, date & time, then Settings > Accounts > Sync.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("Recovery Commands")
        CommandPanel(listOf("recovery.google", "recovery.account", "recovery.password", "recovery.owner.checklist", "recovery.network.check", "recovery.manufacturer", "recovery.support", "recovery.frp.guide"), vm, snack)
        SectionTitle("Recovery Report & History")
        FrpCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val text = reportText()
                    scope.launch(Dispatchers.IO) { c.recoveryHistory.append(JSONObject().put("t", Fmt.time(System.currentTimeMillis())).put("text", text)) }
                    snack("Recovery report saved locally")
                }) { Text("Save report") }
                OutlinedButton(onClick = { exporter.launch("recovery-report.txt") }) { Text("Export report") }
            }
            OutlinedButton(onClick = {
                showHistory = !showHistory
                if (showHistory) scope.launch { history = withContext(Dispatchers.IO) { c.recoveryHistory.readAll().asReversed() } }
            }) { Text("Recovery history") }
            if (showHistory) {
                if (history.isEmpty()) Text("No saved reports.")
                history.forEach { Text(it.optString("text"), fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}
