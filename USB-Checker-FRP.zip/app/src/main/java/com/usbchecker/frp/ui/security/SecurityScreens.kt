package com.usbchecker.frp.ui.security

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.core.permissions.PermissionCenter
import com.usbchecker.frp.core.permissions.PermKind
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.ui.common.CommandPanel
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold

@Composable
fun PermissionCenterScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val results = remember { mutableStateMapOf<String, String>() }
    var pending by remember { mutableStateOf<String?>(null) }

    LifecycleResumeEffect(Unit) { tick++; onPauseOrDispose { } }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pending?.let { results[it] = if (granted) "Result: granted by user" else "Result: denied by user" }
        pending = null; tick++
    }

    ScreenScaffold("Permission Center", onBack) { snack ->
        Text("Nothing here grants permissions automatically. Requests use the Android system dialog; special access opens Android Settings for you to decide.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        PermissionCenter.items.forEach { p ->
            val status = remember(tick, p.id) { PermissionCenter.status(ctx, p) }
            val good = status.startsWith("Granted") || status.startsWith("Enabled") || status.startsWith("No permission")
            ExpandCard(p.title, if (good) Brand.Green else Brand.Yellow) {
                StatusChip(status, if (good) Brand.Green else Brand.Yellow)
                KvRow("Permission type", p.type)
                KvRow("Why it is needed", p.why)
                results[p.id]?.let { KvRow("Permission result", it) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = p.requestable && !status.startsWith("Granted"),
                        onClick = { pending = p.id; launcher.launch(p.manifestPerm!!) }
                    ) { Text("Request permission") }
                    OutlinedButton(onClick = { snack(PermissionCenter.openSettings(ctx, p).second) }) {
                        Text(if (p.kind == PermKind.SAF) "Open app settings" else "Open permission settings")
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityScreen(onBack: () -> Unit, go: (String) -> Unit) {
    val vm: CommandViewModel = viewModel()
    ScreenScaffold("Security Center", onBack) { snack ->
        FrpCard {
            Text("Read-only security overview of this device and this app. Nothing is changed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { go("permissions") }) { Text("Open Permission Center") }
        }
        CommandPanel(listOf("security.device.status", "security.permission.audit", "security.app.permissions", "security.encryption.info", "security.audit"), vm, snack)
    }
}
