package com.usbchecker.frp.ui.apkmanager

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.ExpandCard
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.utils.Fmt
import com.usbchecker.frp.utils.Intents

private const val APK_MIME = "application/vnd.android.package-archive"

@Composable
fun ApkManagerScreen(onBack: () -> Unit) {
    val vm: ApkViewModel = viewModel()
    val ctx = LocalContext.current
    val info = vm.info.collectAsStateWithLifecycle().value
    val error = vm.error.collectAsStateWithLifecycle().value
    val busy = vm.busy.collectAsStateWithLifecycle().value
    val history = vm.history.collectAsStateWithLifecycle().value
    var expected by rememberSaveable { mutableStateOf("") }
    var verdict by rememberSaveable { mutableStateOf<String?>(null) }

    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { verdict = null; vm.load(u) } }

    fun uriFor(i: ApkInfo): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", i.file)

    ScreenScaffold("APK Manager", onBack) { snack ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GradientButton("Select APK File", { pickApk.launch(arrayOf(APK_MIME, "application/octet-stream")) }, icon = Icons.Filled.FolderOpen)
            OutlinedButton(onClick = { pickApk.launch(arrayOf("*/*")) }) { Text("Browse Files") }
        }
        Loading(busy)
        error?.let { FrpCard { Text(it, color = Brand.Red) } }
        if (info != null) {
            FrpCard {
                Text(info.label, style = MaterialTheme.typography.titleLarge)
                KvRow("File name", info.fileName)
                KvRow("Package name", info.pkg)
                KvRow("Version", "${info.versionName} (${info.versionCode})")
                KvRow("Min / target SDK", "${info.minSdk} / ${info.targetSdk}")
                KvRow("File size", "${Fmt.bytes(info.size)} (${info.size} B)")
                Text("SHA-256", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(info.sha256, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                Text("Signing certificate SHA-256", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (info.certs.isEmpty()) Text("No signing certificate reported (unsigned or unavailable).", color = Brand.Yellow)
                info.certs.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
                StatusChip(if (info.sizeMatches) "Read size matches file size" else "Read size differs from reported size", if (info.sizeMatches) Brand.Green else Brand.Red)
            }
            FrpCard {
                Text("File Integrity Verification", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(expected, { expected = it.filter { ch -> ch.isLetterOrDigit() }.take(64) }, Modifier.fillMaxWidth(),
                    label = { Text("Expected SHA-256 (optional)") }, singleLine = true)
                OutlinedButton(onClick = {
                    verdict = if (expected.length != 64) "Enter a full 64-character SHA-256." else
                        if (expected.equals(info.sha256, true)) "MATCH: file hash equals the expected value." else "MISMATCH: do not install this file."
                }) { Text("Verify") }
                verdict?.let { Text(it, color = if (it.startsWith("MATCH")) Brand.Green else Brand.Yellow) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val i = Intent(Intent.ACTION_SEND).setType(APK_MIME).putExtra(Intent.EXTRA_STREAM, uriFor(info)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    snack(Intents.start(ctx, Intent.createChooser(i, "Share APK"), "Share APK").second)
                }) { Text("Share APK") }
                GradientButton("Open Installer", {
                    if (!ctx.packageManager.canRequestPackageInstalls()) {
                        snack(Intents.start(ctx, Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")), "Install-unknown-apps permission").second +
                            ". Allow it, return, and tap again.")
                    } else {
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(info), APK_MIME).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        snack(Intents.start(ctx, i, "Android package installer").second + ". You must confirm there.")
                    }
                }, icon = Icons.Filled.Share)
            }
            Text("Installation is performed only by the Android package installer, with its own confirmation screen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionTitle("APK History")
        history.take(20).forEach {
            ExpandCard("${it.optString("name")}  ·  ${it.optString("ver")}") {
                KvRow("Time", it.optString("t")); KvRow("Package", it.optString("pkg"))
                KvRow("Size", Fmt.bytes(it.optLong("size"))); Text(it.optString("sha"), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
        if (history.isEmpty()) Text("No APK inspected yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
