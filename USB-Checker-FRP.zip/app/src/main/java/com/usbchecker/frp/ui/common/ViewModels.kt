package com.usbchecker.frp.ui.common

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.core.commands.CommandResult
import com.usbchecker.frp.core.commands.CommandSanitizer
import com.usbchecker.frp.core.commands.ExecResult
import com.usbchecker.frp.core.commands.ExecStatus
import com.usbchecker.frp.core.commands.LogEntry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class TermKind { INPUT, OUT, ERR, INFO }
data class TermLine(val text: String, val kind: TermKind)

class CommandViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FrpApp).container
    val registry = c.commands

    private val _results = MutableStateFlow<Map<String, ExecResult>>(emptyMap())
    val results: StateFlow<Map<String, ExecResult>> = _results.asStateFlow()

    private val _running = MutableStateFlow<Set<String>>(emptySet())
    val running: StateFlow<Set<String>> = _running.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _terminal = MutableStateFlow(listOf(TermLine("USB Checker FRP terminal. Only registered commands run. Type 'help'.", TermKind.INFO)))
    val terminal: StateFlow<List<TermLine>> = _terminal.asStateFlow()

    private val typed = ArrayDeque<String>()

    init { loadLogs() }

    private suspend fun reload() {
        _logs.value = withContext(Dispatchers.IO) { c.logs.readAll().map { LogEntry.from(it) } }.asReversed()
    }

    fun loadLogs() { viewModelScope.launch { reload() } }

    fun clearLogs() {
        viewModelScope.launch { withContext(Dispatchers.IO) { c.logs.clear() }; reload() }
    }

    fun run(raw: String, onDone: (ExecResult) -> Unit = {}) {
        val key = CommandSanitizer.sanitize(raw) ?: raw.trim().take(48)
        if (key in _running.value) return
        _running.update { it + key }
        viewModelScope.launch {
            val r = try {
                registry.execute(raw)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                ExecResult(key, CommandResult(ExecStatus.FAILED, "", e.message ?: e.javaClass.simpleName), 0)
            }
            _results.update { it + (key to r) }
            _running.update { it - key }
            reload()
            onDone(r)
        }
    }

    // ---- Terminal ----
    private fun addLines(vararg l: TermLine) { _terminal.update { (it + l).takeLast(400) } }

    fun clearTerminal() { _terminal.value = emptyList() }

    fun terminalText(): String = _terminal.value.joinToString("\n") { it.text }

    fun submit(input: String) {
        val line = input.trim().take(64)
        if (line.isEmpty()) return
        addLines(TermLine("> $line", TermKind.INPUT))
        typed.addLast(line); while (typed.size > 50) typed.removeFirst()
        when (line.lowercase()) {
            "help" -> addLines(TermLine("Built-ins: help, list, history, clear\nRun a registered command by its id, e.g. usb.scan or device.info. Arguments, pipes and shell syntax are rejected.", TermKind.INFO))
            "list" -> addLines(TermLine(registry.commands.joinToString("\n") { it.id }, TermKind.INFO))
            "history" -> addLines(TermLine(typed.joinToString("\n").ifBlank { "(empty)" }, TermKind.INFO))
            "clear" -> clearTerminal()
            else -> run(line) { r ->
                if (r.result.output.isNotBlank()) addLines(TermLine(r.result.output, TermKind.OUT))
                r.result.error?.takeIf { it.isNotBlank() }?.let { addLines(TermLine(it, TermKind.ERR)) }
                addLines(TermLine("[${r.result.status.label}] ${r.durationMs} ms", TermKind.INFO))
            }
        }
    }

    fun suggestions(prefix: String): List<String> = if (prefix.isBlank()) emptyList() else registry.suggestions(prefix)
}
