package com.usbchecker.frp.core.diagnostics

import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import android.view.Display
import com.usbchecker.frp.core.usb.UsbInspector
import java.io.File
import java.util.Locale

typealias KV = Pair<String, String>

class DeviceInspector(context: Context, private val usb: UsbInspector) {
    private val ctx = context.applicationContext

    private fun size(b: Long) = Formatter.formatFileSize(ctx, b)

    fun basic(): List<KV> = listOf(
        "Manufacturer" to Build.MANUFACTURER, "Brand" to Build.BRAND, "Model" to Build.MODEL,
        "Device" to Build.DEVICE, "Android version" to Build.VERSION.RELEASE,
        "SDK level" to Build.VERSION.SDK_INT.toString(), "Build ID" to Build.ID,
        "Build type" to Build.TYPE, "Fingerprint" to Build.FINGERPRINT,
        "Supported ABIs" to Build.SUPPORTED_ABIS.joinToString()
    )

    fun batteryPercent(): Int? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) level * 100 / scale else null
    }

    fun battery(): List<KV> {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return listOf("Battery" to "Unavailable")
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val status = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "Unknown"
        }
        val plugged = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Not plugged"
        }
        return listOf(
            "Level" to (batteryPercent()?.let { "$it%" } ?: "Unavailable"),
            "Temperature" to if (temp == Int.MIN_VALUE) "Unavailable" else "%.1f °C".format(Locale.US, temp / 10f),
            "Status" to status, "Power source" to plugged
        )
    }

    fun storage(): List<KV> = try {
        val s = StatFs(Environment.getDataDirectory().path)
        val total = s.totalBytes
        val free = s.availableBytes
        listOf("Total" to size(total), "Free" to size(free), "Used" to size(total - free))
    } catch (e: Exception) {
        listOf("Storage" to "Unavailable")
    }

    fun storageSummary(): String = storage().let { l -> l.firstOrNull { it.first == "Free" }?.second?.let { "$it free" } ?: "Unavailable" }

    fun memory(): List<KV> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return listOf("Total RAM" to size(mi.totalMem), "Available RAM" to size(mi.availMem),
            "Low memory" to mi.lowMemory.toString())
    }

    fun display(): List<KV> {
        val dm = ctx.resources.displayMetrics
        val hz = runCatching {
            (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
                .getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate
        }.getOrNull()
        return listOf("Resolution" to "${dm.widthPixels} x ${dm.heightPixels}", "Density" to "${dm.densityDpi} dpi",
            "Refresh rate" to (hz?.let { "%.0f Hz".format(Locale.US, it) } ?: "Unavailable"))
    }

    fun network(): List<KV> {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val caps = n?.let { cm.getNetworkCapabilities(it) }
        if (n == null || caps == null) return listOf("Connection" to "No active network")
        val type = listOf(
            NetworkCapabilities.TRANSPORT_WIFI to "Wi-Fi", NetworkCapabilities.TRANSPORT_CELLULAR to "Cellular",
            NetworkCapabilities.TRANSPORT_ETHERNET to "Ethernet", NetworkCapabilities.TRANSPORT_VPN to "VPN",
            NetworkCapabilities.TRANSPORT_BLUETOOTH to "Bluetooth"
        ).filter { caps.hasTransport(it.first) }.joinToString { it.second }.ifEmpty { "Other" }
        val ips = cm.getLinkProperties(n)?.linkAddresses?.mapNotNull { it.address.hostAddress }.orEmpty()
        return listOf(
            "Transport" to type,
            "Internet capability" to caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).toString(),
            "Validated by Android" to caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED).toString(),
            "IP addresses" to ips.joinToString().ifEmpty { "None" }
        )
    }

    fun wifi(): List<KV> {
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        return listOf(
            "Wi-Fi enabled" to (wm?.isWifiEnabled?.toString() ?: "Unavailable"),
            "SSID / BSSID" to "Restricted by Android (needs location permission, which this app does not request)"
        )
    }

    fun bluetooth(): List<KV> = try {
        val a = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        listOf("Bluetooth adapter" to if (a == null) "Not present" else if (a.isEnabled) "Enabled" else "Disabled")
    } catch (e: SecurityException) {
        listOf("Bluetooth adapter" to "Restricted by Android")
    }

    fun sensors(): List<KV> {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val l = sm.getSensorList(Sensor.TYPE_ALL)
        return listOf("Sensor count" to l.size.toString(), "Sensors" to l.map { it.name }.distinct().take(40).joinToString("; "))
    }

    fun usbStatus(): List<KV> = listOf(
        "USB Host feature" to if (usb.hostSupported) "Available" else "Not available",
        "USB Accessory feature" to if (usb.accessorySupported) "Available" else "Not available",
        "Attached USB devices" to usb.rawDevices().size.toString()
    )

    fun language(): List<KV> = listOf("Locale" to Locale.getDefault().toLanguageTag(),
        "Display language" to Locale.getDefault().displayLanguage)

    fun security(): List<KV> {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val enc = when (dpm.storageEncryptionStatus) {
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE, DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER -> "Active"
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY -> "Active (default key)"
            DevicePolicyManager.ENCRYPTION_STATUS_INACTIVE -> "Inactive"
            DevicePolicyManager.ENCRYPTION_STATUS_UNSUPPORTED -> "Unsupported"
            else -> "Unknown"
        }
        val kg = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return listOf("Security patch" to Build.VERSION.SECURITY_PATCH, "Storage encryption" to enc,
            "Screen lock configured" to kg.isDeviceSecure.toString())
    }

    private fun dirSize(f: File): Long = if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

    fun cacheBytes(): Long = dirSize(ctx.cacheDir)
    fun dataBytes(): Long = dirSize(ctx.filesDir)

    @Suppress("DEPRECATION")
    fun app(): List<KV> {
        val pi = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0) } catch (e: PackageManager.NameNotFoundException) { null }
        val code = pi?.let { if (Build.VERSION.SDK_INT >= 28) it.longVersionCode else it.versionCode.toLong() }
        return listOf("Package" to ctx.packageName, "Version" to "${pi?.versionName ?: "?"} ($code)",
            "Cache size" to size(cacheBytes()), "Data size" to size(dataBytes()))
    }

    fun all(): LinkedHashMap<String, List<KV>> = linkedMapOf(
        "Device" to basic(), "Battery" to battery(), "Storage" to storage(), "Memory" to memory(),
        "Display" to display(), "Network" to network(), "Wi-Fi" to wifi(), "Bluetooth" to bluetooth(),
        "USB" to usbStatus(), "Sensors" to sensors(), "Security" to security(), "Language" to language(),
        "Application" to app()
    )

    fun report(): String = all().entries.joinToString("\n\n") { (k, v) ->
        "== $k ==\n" + v.joinToString("\n") { "${it.first}: ${it.second}" }
    }

    companion object {
        fun text(l: List<KV>) = l.joinToString("\n") { "${it.first}: ${it.second}" }
    }
}
