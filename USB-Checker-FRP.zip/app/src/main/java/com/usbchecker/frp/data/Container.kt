package com.usbchecker.frp.data

import android.app.Application
import com.usbchecker.frp.core.commands.CommandRegistry
import com.usbchecker.frp.core.diagnostics.DeviceInspector
import com.usbchecker.frp.core.usb.UsbInspector
import com.usbchecker.frp.core.usb.UsbMonitor
import java.io.File

/** Manual dependency container (no DI framework needed at this size). */
class Container(val app: Application) {
    private fun store(name: String, max: Int) = LineStore(File(app.filesDir, "data/$name.jsonl"), max)

    val prefs = Prefs(app)
    val logs = store("exec_logs", 500)
    val usbHistory = store("usb_history", 200)
    val apkHistory = store("apk_history", 100)
    val diagHistory = store("diag_history", 30)
    val recoveryHistory = store("recovery_history", 30)

    val usb = UsbInspector(app)
    val device = DeviceInspector(app, usb)
    val monitor = UsbMonitor(app, usb, usbHistory)
    val commands = CommandRegistry(app, usb, device, logs)
}
