package com.usbchecker.frp.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.usbchecker.frp.FrpApp
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.data.AppSettings
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.ui.apkmanager.ApkManagerScreen
import com.usbchecker.frp.ui.apkmanager.AppManagerScreen
import com.usbchecker.frp.ui.commands.CommandCenterScreen
import com.usbchecker.frp.ui.dashboard.DashboardScreen
import com.usbchecker.frp.ui.diagnostics.DeviceDiagnosticsScreen
import com.usbchecker.frp.ui.diagnostics.DeviceInfoScreen
import com.usbchecker.frp.ui.floating.FloatingScreen
import com.usbchecker.frp.ui.hid.HidScreen
import com.usbchecker.frp.ui.recovery.RecoveryScreen
import com.usbchecker.frp.ui.recovery.RepairScreen
import com.usbchecker.frp.ui.security.PermissionCenterScreen
import com.usbchecker.frp.ui.security.SecurityScreen
import com.usbchecker.frp.ui.settings.AppSettingsScreen
import com.usbchecker.frp.ui.settings.LogsScreen
import com.usbchecker.frp.ui.settings.SettingsLauncherScreen
import com.usbchecker.frp.ui.terminal.TerminalScreen
import com.usbchecker.frp.ui.usb.AccessoryScreen
import com.usbchecker.frp.ui.usb.HostToolsScreen
import com.usbchecker.frp.ui.usb.UsbDiagnosticsScreen
import com.usbchecker.frp.ui.usb.UsbScannerScreen
import kotlinx.coroutines.launch

@Composable
fun AppRoot(pendingRoute: String?, onRouteConsumed: () -> Unit, settings: AppSettings) {
    val nav = rememberNavController()
    val go: (String) -> Unit = { r -> nav.navigate(r) { launchSingleTop = true } }
    val back: () -> Unit = { nav.popBackStack() }

    // Route extras can come from other apps, so only whitelisted routes are accepted.
    LaunchedEffect(pendingRoute) {
        Screen.fromRoute(pendingRoute)?.let { go(it.route) }
        if (pendingRoute != null) onRouteConsumed()
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(nav, startDestination = Screen.DASHBOARD) {
            composable(Screen.DASHBOARD) { DashboardScreen(go, settings) }
            composable(Screen.SCANNER.route) { UsbScannerScreen(back) }
            composable(Screen.USB_DIAG.route) { UsbDiagnosticsScreen(back) }
            composable(Screen.HID.route) { HidScreen(back) }
            composable(Screen.HOST.route) { HostToolsScreen(back) }
            composable(Screen.ACCESSORY.route) { AccessoryScreen(back) }
            composable(Screen.DEVICE_INFO.route) { DeviceInfoScreen(back) }
            composable(Screen.COMMANDS.route) { CommandCenterScreen(back) }
            composable(Screen.TERMINAL.route) { TerminalScreen(back) }
            composable(Screen.APK.route) { ApkManagerScreen(back) }
            composable(Screen.APPS.route) { AppManagerScreen(back) }
            composable(Screen.SETTINGS_LAUNCHER.route) { SettingsLauncherScreen(back) }
            composable(Screen.PERMISSIONS.route) { PermissionCenterScreen(back) }
            composable(Screen.DEVICE_DIAG.route) { DeviceDiagnosticsScreen(back) }
            composable(Screen.REPAIR.route) { RepairScreen(back) }
            composable(Screen.RECOVERY.route) { RecoveryScreen(back) }
            composable(Screen.SECURITY.route) { SecurityScreen(back, go) }
            composable(Screen.FLOATING.route) { FloatingScreen(back) }
            composable(Screen.LOGS.route) { LogsScreen(back) }
            composable(Screen.APP_SETTINGS.route) { AppSettingsScreen(back, settings) }
        }
        if (settings.inAppPanel) InAppQuickPanel(go, Modifier.align(Alignment.BottomEnd))
    }
}

/** In-app fallback for the floating panel; needs no overlay permission. */
@Composable
private fun InAppQuickPanel(go: (String) -> Unit, modifier: Modifier) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    var hidden by rememberSaveable { mutableStateOf(false) }
    val prefs = (LocalContext.current.applicationContext as FrpApp).container.prefs
    val scope = rememberCoroutineScope()

    if (hidden) {
        Box(modifier.navigationBarsPadding().padding(8.dp).size(18.dp).background(Brand.Cyan.copy(alpha = 0.35f), CircleShape).clickable { hidden = false })
        return
    }
    Column(modifier.navigationBarsPadding().padding(16.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (expanded) {
            listOf(Screen.SCANNER, Screen.DEVICE_INFO, Screen.DEVICE_DIAG, Screen.COMMANDS, Screen.APP_SETTINGS).forEach { s ->
                FilledTonalButton(onClick = { expanded = false; go(s.route) }) { Text(Tr.t(s.title)) }
            }
            FilledTonalButton(onClick = { expanded = false; hidden = true }) {
                Icon(Icons.Filled.VisibilityOff, null, Modifier.size(16.dp)); Text(" Hide")
            }
            FilledTonalButton(onClick = { expanded = false; scope.launch { prefs.setInAppPanel(false) } }) {
                Icon(Icons.Filled.Close, null, Modifier.size(16.dp)); Text(" Close")
            }
        }
        FloatingActionButton(onClick = { expanded = !expanded }, containerColor = Brand.Blue, contentColor = Color.White) {
            Icon(if (expanded) Icons.Filled.Close else Icons.Filled.Usb, contentDescription = "Quick actions")
        }
    }
}
