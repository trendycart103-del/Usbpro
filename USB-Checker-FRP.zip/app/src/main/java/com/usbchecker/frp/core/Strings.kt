package com.usbchecker.frp.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** English is the source text. Bengali is looked up at call time; missing entries fall back to English. */
object Tr {
    var lang by mutableStateOf("en")

    private val bn = mapOf(
        "USB Scanner" to "ইউএসবি স্ক্যানার", "USB Diagnostics" to "ইউএসবি ডায়াগনস্টিক্স",
        "HID Compatibility" to "এইচআইডি সামঞ্জস্য", "USB Host Tools" to "ইউএসবি হোস্ট টুলস",
        "USB Accessory Tools" to "ইউএসবি অ্যাক্সেসরি টুলস", "Device Information" to "ডিভাইস তথ্য",
        "Command Center" to "কমান্ড সেন্টার", "Terminal" to "টার্মিনাল", "APK Manager" to "এপিকে ম্যানেজার",
        "Application Manager" to "অ্যাপ্লিকেশন ম্যানেজার", "Settings Launcher" to "সেটিংস লঞ্চার",
        "Permission Center" to "পারমিশন সেন্টার", "Device Diagnostics" to "ডিভাইস ডায়াগনস্টিক্স",
        "Device Repair Assistant" to "ডিভাইস মেরামত সহকারী", "Recovery Assistant" to "রিকভারি সহকারী",
        "Security Center" to "সিকিউরিটি সেন্টার", "Floating Control Panel" to "ফ্লোটিং কন্ট্রোল প্যানেল",
        "Execution Logs" to "এক্সিকিউশন লগ", "Application Settings" to "অ্যাপ্লিকেশন সেটিংস",
        "Run" to "চালান", "Search" to "খুঁজুন", "Clear" to "মুছুন", "Copy" to "কপি", "Export" to "এক্সপোর্ট",
        "Refresh" to "রিফ্রেশ", "Language" to "ভাষা", "Recent Activity" to "সাম্প্রতিক কার্যক্রম",
        "Battery" to "ব্যাটারি", "Storage" to "স্টোরেজ", "Manufacturer" to "প্রস্তুতকারক", "Brand" to "ব্র্যান্ড",
        "Model" to "মডেল", "Android" to "অ্যান্ড্রয়েড", "Connected" to "সংযুক্ত", "Not connected" to "সংযুক্ত নয়",
        "Available" to "উপলব্ধ", "Unavailable" to "অনুপলব্ধ", "Back" to "পেছনে", "Dark theme" to "ডার্ক থিম",
        "Animations" to "অ্যানিমেশন", "Save" to "সংরক্ষণ", "History" to "ইতিহাস", "Execute" to "কার্যকর করুন",
        "No activity yet" to "এখনও কোনো কার্যক্রম নেই", "Search features" to "ফিচার খুঁজুন",
        "USB Host" to "ইউএসবি হোস্ট", "HID" to "এইচআইডি", "SDK level" to "এসডিকে লেভেল"
    )

    fun t(en: String): String = if (lang == "bn") bn[en] ?: en else en
}
