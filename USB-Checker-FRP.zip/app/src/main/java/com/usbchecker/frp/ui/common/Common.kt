package com.usbchecker.frp.ui.common

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.designsystem.ResultPanel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: () -> Unit,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.(snack: (String) -> Unit) -> Unit
) {
    val host = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val snack: (String) -> Unit = { m -> scope.launch { host.showSnackbar(m) } }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(host) },
        topBar = {
            TopAppBar(
                title = { Text(Tr.t(title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, Tr.t("Back")) } },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
                    actionIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize()
                .then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) { content(snack) }
    }
}

/** One card per registered command: description, effect, Run, and the real result. */
@Composable
fun CommandPanel(ids: List<String>, vm: CommandViewModel, snack: (String) -> Unit) {
    val results = vm.results.collectAsStateWithLifecycle().value
    val running = vm.running.collectAsStateWithLifecycle().value
    ids.forEach { id ->
        val def = vm.registry.find(id) ?: return@forEach
        FrpCard {
            Text(id, fontFamily = FontFamily.Monospace, color = Brand.Cyan, fontSize = 13.sp)
            Text(def.description, style = MaterialTheme.typography.bodyMedium)
            Text(def.effect, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            GradientButton(Tr.t("Run"), { vm.run(id) { snack("$id: ${it.result.status.label}") } }, enabled = id !in running, icon = Icons.Filled.PlayArrow)
            Loading(id in running)
            results[id]?.let { ResultPanel(it.result.status, it.result.output, it.result.error, it.durationMs) }
        }
    }
}

suspend fun writeToUri(ctx: Context, uri: Uri, text: String): Boolean = withContext(Dispatchers.IO) {
    try {
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) } != null
    } catch (e: Exception) {
        false
    }
}
