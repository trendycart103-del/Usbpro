package com.usbchecker.frp.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BubbleChart
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.usbchecker.frp.designsystem.Brand

enum class Screen(val route: String, val title: String, val icon: ImageVector, val color: Color) {
    SCANNER("scanner", "USB Scanner", Icons.Filled.Search, Brand.Cyan),
    USB_DIAG("usb_diag", "USB Diagnostics", Icons.Filled.Analytics, Brand.Electric),
    HID("hid", "HID Compatibility", Icons.Filled.Keyboard, Brand.Purple),
    HOST("host", "USB Host Tools", Icons.Filled.Usb, Brand.Blue),
    ACCESSORY("accessory", "USB Accessory Tools", Icons.Filled.Cable, Brand.Cyan),
    DEVICE_INFO("device_info", "Device Information", Icons.Filled.Smartphone, Brand.Green),
    COMMANDS("commands", "Command Center", Icons.Filled.Code, Brand.Purple),
    TERMINAL("terminal", "Terminal", Icons.Filled.Terminal, Brand.Green),
    APK("apk", "APK Manager", Icons.Filled.Android, Brand.Green),
    APPS("apps", "Application Manager", Icons.Filled.Apps, Brand.Electric),
    SETTINGS_LAUNCHER("settings_launcher", "Settings Launcher", Icons.Filled.Tune, Brand.Yellow),
    PERMISSIONS("permissions", "Permission Center", Icons.Filled.VerifiedUser, Brand.Cyan),
    DEVICE_DIAG("device_diag", "Device Diagnostics", Icons.Filled.Memory, Brand.Blue),
    REPAIR("repair", "Device Repair Assistant", Icons.Filled.Build, Brand.Yellow),
    RECOVERY("recovery", "Recovery Assistant", Icons.Filled.Restore, Brand.Purple),
    SECURITY("security", "Security Center", Icons.Filled.Security, Brand.Red),
    FLOATING("floating", "Floating Control Panel", Icons.Filled.BubbleChart, Brand.Electric),
    LOGS("logs", "Execution Logs", Icons.Filled.History, Brand.Cyan),
    APP_SETTINGS("app_settings", "Application Settings", Icons.Filled.Settings, Brand.TextSecondary);

    companion object {
        const val DASHBOARD = "dashboard"
        fun fromRoute(r: String?): Screen? = entries.firstOrNull { it.route == r }
    }
}
