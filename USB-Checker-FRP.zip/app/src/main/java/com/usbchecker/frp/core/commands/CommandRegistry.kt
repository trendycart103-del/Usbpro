package com.usbchecker.frp.core.commands

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.usbchecker.frp.core.compatibility.Compat
import com.usbchecker.frp.core.diagnostics.DeviceInspector
import com.usbchecker.frp.core.diagnostics.DeviceInspector.Companion.text
import com.usbchecker.frp.core.permissions.PermissionCenter
import com.usbchecker.frp.core.permissions.SettingsLauncher
import com.usbchecker.frp.core.usb.UsbInspector
import com.usbchecker.frp.data.LineStore
import com.usbchecker.frp.utils.Fmt
import com.usbchecker.frp.utils.Intents
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

/**
 * The ONLY way commands run. Input must match the sanitizer AND be a registered id.
 * No shell, no reflection, no arbitrary strings reach the system.
 */
class CommandRegistry(
    context: Context,
    private val usb: UsbInspector,
    private val device: DeviceInspector,
    private val logs: LineStore
) {
    private val ctx = context.applicationContext
    private val env = CommandEnv(ctx, usb, device)

    private fun ok(s: String) = CommandResult(ExecStatus.SUCCESS, s)
    private fun launch(r: Pair<Boolean, String>) =
        if (r.first) CommandResult(ExecStatus.NEEDS_USER_ACTION, r.second) else CommandResult(ExecStatus.UNSUPPORTED, r.second)

    private fun def(id: String, desc: String, effect: String = "Read-only", timeout: Long = 8_000, run: suspend (CommandEnv) -> CommandResult) =
        CommandDef(id, desc, effect, timeout, run)

    private fun settings(id: String, desc: String, targetId: String) =
        def(id, desc, "Opens an Android Settings screen") {
            val t = SettingsLauncher.find(targetId)
            if (t == null) CommandResult(ExecStatus.UNSUPPORTED, "No such settings target.") else launch(SettingsLauncher.launch(ctx, t))
        }

    private fun info(id: String, desc: String, block: () -> List<Pair<String, String>>) =
        def(id, desc) { ok(text(block())) }

    private suspend fun connectionTest(): CommandResult = withContext(Dispatchers.IO) {
        var c: HttpURLConnection? = null
        try {
            val start = System.currentTimeMillis()
            c = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000; readTimeout = 4000; requestMethod = "GET"; instanceFollowRedirects = false
            }
            val code = c.responseCode
            val ms = System.currentTimeMillis() - start
            if (code in 200..399) ok("Internet reachable (HTTP $code, ${ms} ms).")
            else CommandResult(ExecStatus.PARTIAL, "Server answered HTTP $code in ${ms} ms (captive portal or filtering possible).")
        } catch (e: Exception) {
            CommandResult(ExecStatus.FAILED, "No internet reachability.", e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
        } finally {
            c?.disconnect()
        }
    }

    private fun manufacturerUrl(): String {
        val m = Build.MANUFACTURER.lowercase()
        return when {
            "samsung" in m -> "https://www.samsung.com/support/"
            "xiaomi" in m || "redmi" in m || "poco" in m -> "https://www.mi.com/global/support/"
            "huawei" in m || "honor" in m -> "https://consumer.huawei.com/en/support/"
            "google" in m -> "https://support.google.com/pixelphone"
            "motorola" in m -> "https://support.motorola.com/"
            "oneplus" in m -> "https://www.oneplus.com/support"
            "oppo" in m -> "https://support.oppo.com/"
            "vivo" in m -> "https://www.vivo.com/support"
            "realme" in m -> "https://www.realme.com/support"
            else -> "https://www.google.com/search?q=" + Build.MANUFACTURER.replace(" ", "+") + "+official+support"
        }
    }

    private val ownerChecklist = """
        Owner verification checklist (prepare before contacting support):
        1. The Google account email that was used on this phone.
        2. Any recovery phone number / recovery email linked to that account.
        3. Proof of purchase (receipt or invoice) and the box or IMEI label.
        4. The device IMEI (dial *#06# when the phone is unlocked or see the box).
        5. A stable Wi-Fi connection.
        6. Another phone or computer to use the official recovery page.
    """.trimIndent()

    private val frpGuide = """
        FRP (Factory Reset Protection) is an anti-theft feature. This app does NOT bypass, remove or weaken it.
        Legitimate options if you are the owner:
        1. Use Google's official recovery (g.co/recover) from any browser to regain your account.
        2. After a password change Google may restrict the device for up to 24 hours; wait and retry.
        3. Sign in with the exact Google account previously used on the device.
        4. If the account cannot be recovered, contact the manufacturer or an authorized service center with proof of purchase.
        5. If the phone was bought second-hand, ask the previous owner to remove the account from the device.
    """.trimIndent()

    val commands: List<CommandDef> = listOf(
        // ---- USB ----
        def("usb.scan", "Scan for attached USB devices") {
            val l = usb.devices()
            ok(if (l.isEmpty()) "Scan complete: no USB devices attached." else
                "Scan complete: ${l.size} device(s)\n" + l.joinToString("\n") { "- ${it.vidPid} ${it.product ?: "(name hidden until permission)"} [${if (it.hasPermission) "permission granted" else "no permission"}]" })
        },
        def("usb.detect", "Detect USB host capability and device count") {
            ok("USB Host feature: ${if (usb.hostSupported) "available" else "NOT available"}\nAttached devices: ${usb.rawDevices().size}")
        },
        def("usb.device.info", "Show details of attached USB devices") {
            val l = usb.devices()
            if (l.isEmpty()) CommandResult(ExecStatus.PARTIAL, "No USB device attached.") else
                ok(l.joinToString("\n\n") { d -> "${d.name}\nVID:PID ${d.vidPid}\nClass ${d.cls}\nManufacturer ${d.manufacturer ?: "hidden/unknown"}\nProduct ${d.product ?: "hidden/unknown"}\nUSB version ${d.usbVersion ?: "unknown"}\nPermission ${d.hasPermission}" })
        },
        def("usb.interfaces", "List interfaces and endpoints of attached USB devices") {
            val l = usb.devices()
            if (l.isEmpty()) CommandResult(ExecStatus.PARTIAL, "No USB device attached.") else
                ok(l.joinToString("\n\n") { d ->
                    "${d.vidPid}\n" + d.interfaces.joinToString("\n") { i ->
                        "  IF${i.id} ${i.clsName} sub=${i.sub} proto=${i.proto} endpoints=${i.endpoints.size}" +
                            i.endpoints.joinToString("") { e -> "\n     EP 0x%02X %s %s max=%d".format(e.address, e.type, e.direction, e.maxPacket) }
                    }
                })
        },
        def("usb.permission.request", "Ask Android to show the USB permission dialog", "Shows the Android system permission dialog", 60_000) {
            val target = usb.rawDevices().firstOrNull { !usb.hasPerm(it) }
            when {
                usb.rawDevices().isEmpty() -> CommandResult(ExecStatus.PARTIAL, "No USB device attached.")
                target == null -> ok("All attached devices already have permission.")
                else -> {
                    val granted = suspendCancellableCoroutine<Boolean> { cont ->
                        usb.requestPermission(target) { if (cont.isActive) cont.resume(it) }
                    }
                    if (granted) ok("Permission GRANTED by the user for ${target.deviceName}.")
                    else CommandResult(ExecStatus.FAILED, "Permission was denied or dismissed.")
                }
            }
        },
        def("usb.connection.status", "Verify connection with a real descriptor read") {
            val l = usb.rawDevices()
            if (l.isEmpty()) CommandResult(ExecStatus.PARTIAL, "No USB device attached.") else {
                val lines = l.map { d ->
                    if (!usb.hasPerm(d)) "${d.deviceName}: attached, permission missing (not verified)"
                    else usb.transferTest(d).let { "${d.deviceName}: ${if (it.ok) "VERIFIED" else "NOT verified"} - ${it.message}" }
                }
                ok(lines.joinToString("\n"))
            }
        },
        def("usb.hid.detect", "Detect HID mouse/keyboard interfaces") {
            val hid = usb.devices().flatMap { d -> d.hidInterfaces.map { d to it } }
            val inputs = usb.inputDevices().filter { it.mouse || it.keyboard }
            ok("USB HID interfaces: ${hid.size}\n" + hid.joinToString("\n") { "- ${it.first.vidPid} IF${it.second.id}: ${it.second.hidKind}" } +
                "\nAndroid input devices (mouse/keyboard): ${inputs.size}\n" + inputs.joinToString("\n") { "- ${it.name} mouse=${it.mouse} keyboard=${it.keyboard}" })
        },
        def("usb.hid.capability", "Report HID host/gadget capability") { ok(Compat.asText(Compat.hid(ctx))) },
        def("usb.accessory.detect", "Detect USB accessory support and attached accessories") {
            ok(Compat.asText(Compat.accessory(ctx)) + "\n" + usb.accessories().joinToString("\n"))
        },
        def("usb.transfer.status", "Run a control-transfer test on permitted devices") {
            val l = usb.rawDevices().filter { usb.hasPerm(it) }
            if (l.isEmpty()) CommandResult(ExecStatus.PARTIAL, "No permitted USB device. Run usb.permission.request first.")
            else {
                val rs = l.map { it.deviceName to usb.transferTest(it) }
                val all = rs.all { it.second.ok }
                CommandResult(if (all) ExecStatus.SUCCESS else ExecStatus.PARTIAL, rs.joinToString("\n") { "${it.first}: ${it.second.message}" })
            }
        },
        def("usb.disconnect", "Release connections held by this app") {
            CommandResult(ExecStatus.PARTIAL,
                "This app keeps no open USB connections (every test closes its connection). Android does not allow apps to electrically disconnect a device; unplug it physically.")
        },

        // ---- DEVICE ----
        info("device.info", "Full device summary") { device.basic() + device.battery() },
        info("device.status", "Battery, storage, memory and network status") { device.battery() + device.storage() + device.memory() + device.network() },
        def("device.model", "Device model") { ok(Build.MODEL) },
        def("device.brand", "Device brand") { ok(Build.BRAND) },
        def("device.manufacturer", "Device manufacturer") { ok(Build.MANUFACTURER) },
        def("device.android.version", "Android version") { ok("Android ${Build.VERSION.RELEASE}") },
        def("device.sdk", "SDK level") { ok("API ${Build.VERSION.SDK_INT}") },
        info("device.battery", "Battery information") { device.battery() },
        info("device.storage", "Storage information") { device.storage() },
        info("device.ram", "Memory information") { device.memory() },
        info("device.display", "Display information") { device.display() },
        info("device.sensors", "Available sensors") { device.sensors() },
        info("device.network", "Network information") { device.network() },
        info("device.language", "Language information") { device.language() },

        // ---- APP ----
        info("app.info", "This application's information") { device.app() },
        def("app.version", "Application version") { ok(device.app().first { it.first == "Version" }.second) },
        def("app.storage", "Application storage usage") {
            ok("Cache: ${Fmt.bytes(device.cacheBytes())}\nData: ${Fmt.bytes(device.dataBytes())}")
        },
        def("app.permissions", "Permissions declared by this app") {
            ok(PermissionCenter.requestedPermissions(ctx).joinToString("\n") { "${if (it.second) "[granted]" else "[not granted]"} ${it.first}" })
        },
        def("app.notifications", "Notification status for this app") {
            ok("Notifications enabled: ${NotificationManagerCompat.from(ctx).areNotificationsEnabled()}")
        },
        settings("app.settings", "Open this app's Android settings page", "app.info"),

        // ---- NETWORK ----
        info("network.status", "Active network status") { device.network() },
        info("network.wifi", "Wi-Fi status") { device.wifi() },
        info("network.ip", "IP addresses of the active network") { device.network().filter { it.first == "IP addresses" } },
        def("network.connection.test", "Test internet reachability", "Makes one HTTPS request", 10_000) { connectionTest() },

        // ---- SETTINGS ----
        def("settings.open", "Open Android Settings", "Opens an Android Settings screen") { launch(SettingsLauncher.launchSettingsHome(ctx)) },
        settings("settings.wifi", "Open Wi-Fi settings", "sys.wifi"),
        settings("settings.bluetooth", "Open Bluetooth settings", "sys.bluetooth"),
        settings("settings.display", "Open display settings", "sys.display"),
        settings("settings.language", "Open language settings", "sys.language"),
        settings("settings.accessibility", "Open accessibility settings", "sys.accessibility"),
        settings("settings.notifications", "Open this app's notification settings", "app.notifications"),
        settings("settings.about", "Open About phone", "sys.about"),

        // ---- SECURITY ----
        info("security.device.status", "Lock, encryption and patch status") { device.security() },
        def("security.permission.audit", "Status of every tracked permission") {
            ok(PermissionCenter.items.joinToString("\n") { "${it.title}: ${PermissionCenter.status(ctx, it)}" })
        },
        def("security.app.permissions", "Permissions requested by this app") {
            ok(PermissionCenter.requestedPermissions(ctx).joinToString("\n") { "${if (it.second) "[granted]" else "[not granted]"} ${it.first}" })
        },
        info("security.encryption.info", "Storage encryption status") { device.security().filter { it.first == "Storage encryption" } },
        def("security.audit", "Combined security overview") {
            ok(text(device.security()) + "\n\nPermissions:\n" + PermissionCenter.items.joinToString("\n") { "${it.title}: ${PermissionCenter.status(ctx, it)}" })
        },

        // ---- RECOVERY ----
        def("recovery.google", "Open Google's official account recovery page", "Opens a web page in your browser") {
            launch(Intents.url(ctx, "https://accounts.google.com/signin/recovery", "Google account recovery"))
        },
        def("recovery.account", "Open the system 'add Google account' screen", "Opens an Android system screen") {
            launch(Intents.start(ctx, Intent(Settings.ACTION_ADD_ACCOUNT).putExtra(Settings.EXTRA_ACCOUNT_TYPES, arrayOf("com.google")), "Add Google account"))
        },
        def("recovery.password", "Open Google's password help page", "Opens a web page in your browser") {
            launch(Intents.url(ctx, "https://support.google.com/accounts/answer/41078", "Google password help"))
        },
        def("recovery.owner.checklist", "Owner verification checklist") { ok(ownerChecklist) },
        def("recovery.network.check", "Check connectivity before recovery", "Makes one HTTPS request", 10_000) {
            val r = connectionTest()
            r.copy(output = text(device.network()) + "\n" + r.output)
        },
        def("recovery.manufacturer", "Open manufacturer support page", "Opens a web page in your browser") {
            launch(Intents.url(ctx, manufacturerUrl(), "Manufacturer support (${Build.MANUFACTURER})"))
        },
        def("recovery.support", "Authorized service guidance") {
            ok("Contact the manufacturer or an authorized service center. Bring proof of purchase, ID and the device IMEI. Do not use third-party unlock tools.")
        },
        def("recovery.frp.guide", "Legitimate FRP recovery guide") { ok(frpGuide) }
    )

    private val byId = commands.associateBy { it.id }

    fun find(id: String) = byId[id]
    fun suggestions(prefix: String): List<String> =
        commands.map { it.id }.filter { it.startsWith(prefix.trim().lowercase()) }.take(8)

    private fun log(cmd: String, req: String, exec: String, err: String, res: String) {
        val now = System.currentTimeMillis()
        logs.append(LogEntry(now, Fmt.time(now), "${Build.MANUFACTURER} ${Build.MODEL}", cmd, req, exec, err, res.take(2000)).toJson())
    }

    suspend fun execute(raw: String): ExecResult {
        val start = System.currentTimeMillis()
        val id = CommandSanitizer.sanitize(raw)
        val def = id?.let { byId[it] }
        if (id == null || def == null) {
            val shown = raw.trim().take(48).filter { it.isLetterOrDigit() || it in "._- " }
            val r = CommandResult(ExecStatus.REJECTED, "", "Unknown or invalid command: '$shown'. Only registered commands run.")
            log(shown.ifBlank { "(empty)" }, "rejected", ExecStatus.REJECTED.label, r.error.orEmpty(), "")
            return ExecResult(shown, r, 0)
        }
        val result = try {
            withTimeoutOrNull(def.timeoutMs) { def.run(env) }
                ?: CommandResult(ExecStatus.NEEDS_USER_ACTION, "", "Timed out after ${def.timeoutMs / 1000}s without a result.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            CommandResult(ExecStatus.FAILED, "", "${e.javaClass.simpleName}: ${e.message ?: "no details"}")
        }
        log(id, "accepted", result.status.label, result.error.orEmpty(), result.output)
        return ExecResult(id, result, System.currentTimeMillis() - start)
    }
}
