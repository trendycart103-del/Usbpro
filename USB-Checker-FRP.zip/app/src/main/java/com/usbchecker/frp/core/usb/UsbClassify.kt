package com.usbchecker.frp.core.usb

/** Pure helpers (JVM-testable). Literal values are USB-IF defined. */
object UsbClassify {
    fun className(c: Int): String = when (c) {
        0x00 -> "Per-interface"
        0x01 -> "Audio"
        0x02 -> "Communications"
        0x03 -> "HID"
        0x05 -> "Physical"
        0x06 -> "Image / PTP"
        0x07 -> "Printer"
        0x08 -> "Mass Storage"
        0x09 -> "Hub"
        0x0A -> "CDC Data"
        0x0B -> "Smart Card"
        0x0E -> "Video"
        0xE0 -> "Wireless Controller"
        0xEF -> "Miscellaneous"
        0xFE -> "Application Specific"
        0xFF -> "Vendor Specific"
        else -> "Class 0x%02X".format(c)
    }

    /** Boot-protocol HID can be identified from descriptors; generic HID cannot be classified without the report descriptor. */
    fun hidKind(cls: Int, sub: Int, proto: Int): String? = when {
        cls != 0x03 -> null
        sub == 1 && proto == 1 -> "Keyboard (boot protocol)"
        sub == 1 && proto == 2 -> "Mouse (boot protocol)"
        else -> "HID (generic / non-boot)"
    }

    fun endpointType(t: Int): String = when (t) {
        0 -> "Control"; 1 -> "Isochronous"; 2 -> "Bulk"; 3 -> "Interrupt"; else -> "Unknown"
    }

    fun hex4(v: Int): String = "%04X".format(v and 0xFFFF)
}
