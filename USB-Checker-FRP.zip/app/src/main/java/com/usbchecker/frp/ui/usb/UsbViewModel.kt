package com.usbchecker.frp.ui.usb

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.usbchecker.frp.FrpApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class UsbViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as FrpApp).container
    val devices = c.monitor.devices
    val event = c.monitor.lastEvent
    val history = c.monitor.history

    private val _transfer = MutableStateFlow<Map<String, String>>(emptyMap())
    val transfer: StateFlow<Map<String, String>> = _transfer.asStateFlow()

    private val _busy = MutableStateFlow<Set<String>>(emptySet())
    val busy: StateFlow<Set<String>> = _busy.asStateFlow()

    fun refresh() = c.monitor.refresh()

    fun requestPermission(name: String, onDone: (String) -> Unit) {
        val d = c.usb.find(name)
        if (d == null) { onDone("Device is no longer attached."); return }
        c.usb.requestPermission(d) { granted ->
            c.monitor.note("PERMISSION ${if (granted) "GRANTED" else "DENIED"} for $name")
            c.monitor.refresh()
            onDone(if (granted) "USB permission granted by the user." else "USB permission denied or dismissed.")
        }
    }

    fun test(name: String, onDone: (String) -> Unit) {
        val d = c.usb.find(name)
        if (d == null) { onDone("Device is no longer attached."); return }
        _busy.update { it + name }
        viewModelScope.launch {
            val r = try { c.usb.transferTest(d) } catch (e: Exception) { null }
            val msg = r?.message ?: "Transfer test failed unexpectedly."
            _transfer.update { it + (name to msg) }
            c.monitor.note("TRANSFER TEST $name: ${if (r?.ok == true) "OK" else "FAILED"}")
            _busy.update { it - name }
            onDone(msg)
        }
    }

    fun inputDevices() = c.usb.inputDevices()
}
