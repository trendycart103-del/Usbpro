package com.usbchecker.frp.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object Intents {
    /** Starts an intent safely. Returns (started, message). Never claims more than "requested". */
    fun start(ctx: Context, intent: Intent, label: String): Pair<Boolean, String> = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true to "Requested: $label (opened by Android)"
    } catch (e: ActivityNotFoundException) {
        false to "Unavailable on this device/ROM: $label"
    } catch (e: SecurityException) {
        false to "Blocked by Android: $label"
    }

    fun url(ctx: Context, url: String, label: String) =
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)), label)

    fun appDetails(ctx: Context, pkg: String = ctx.packageName) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
}
