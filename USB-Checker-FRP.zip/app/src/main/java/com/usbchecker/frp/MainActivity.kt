package com.usbchecker.frp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.data.AppSettings
import com.usbchecker.frp.designsystem.FrpTheme
import com.usbchecker.frp.designsystem.LocalAnimations
import com.usbchecker.frp.navigation.AppRoot

class MainActivity : ComponentActivity() {
    private val pendingRoute = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute.value = intent?.getStringExtra("route")
        val container = (application as FrpApp).container
        setContent {
            val s by container.prefs.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            remember(s.lang) { Tr.lang = s.lang }
            FrpTheme(dark = s.dark) {
                CompositionLocalProvider(LocalAnimations provides s.animations) {
                    AppRoot(pendingRoute = pendingRoute.value, onRouteConsumed = { pendingRoute.value = null }, settings = s)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("route")?.let { pendingRoute.value = it }
    }
}
