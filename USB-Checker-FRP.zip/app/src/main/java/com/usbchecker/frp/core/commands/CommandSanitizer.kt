package com.usbchecker.frp.core.commands

/** Pure validation: only dotted lowercase identifiers are ever considered; no arguments, no shell syntax. */
object CommandSanitizer {
    private val pattern = Regex("^[a-z][a-z0-9]*(\\.[a-z0-9]+){1,4}$")

    fun sanitize(raw: String): String? {
        val s = raw.trim().lowercase()
        if (s.length > 48) return null
        return if (pattern.matches(s)) s else null
    }
}
