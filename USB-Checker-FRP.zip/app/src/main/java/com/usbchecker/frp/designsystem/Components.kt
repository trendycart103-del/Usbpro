package com.usbchecker.frp.designsystem

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.usbchecker.frp.R
import com.usbchecker.frp.core.commands.ExecStatus
import com.usbchecker.frp.core.compatibility.Capability
import com.usbchecker.frp.core.compatibility.Support

@Composable
fun AppLogo(size: androidx.compose.ui.unit.Dp = 72.dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo_frp), contentDescription = "USB Checker FRP logo",
        modifier = modifier.size(size).clip(RoundedCornerShape(size / 4))
    )
}

@Composable
fun FrpCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun Reveal(visible: Boolean, content: @Composable () -> Unit) {
    if (LocalAnimations.current) AnimatedVisibility(visible) { content() } else if (visible) content()
}

@Composable
fun ExpandCard(title: String, accent: Color = Brand.Cyan, initiallyExpanded: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(initiallyExpanded) }
    FrpCard {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open = !open }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(10.dp).background(accent, CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
        }
        Reveal(open) { Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }
    }
}

@Composable
fun StatusChip(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f), border = BorderStroke(1.dp, color.copy(alpha = 0.6f))) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

fun Support.color(): Color = when (this) {
    Support.FULLY -> Brand.Green
    Support.PARTIAL -> Brand.Cyan
    Support.HARDWARE, Support.NOT_IMPLEMENTED -> Brand.Yellow
    Support.RESTRICTED -> Brand.Purple
    Support.UNSUPPORTED -> Brand.Red
    Support.UNKNOWN -> Brand.TextSecondary
}

fun ExecStatus.color(): Color = when (this) {
    ExecStatus.SUCCESS -> Brand.Green
    ExecStatus.PARTIAL, ExecStatus.NEEDS_USER_ACTION -> Brand.Yellow
    ExecStatus.UNSUPPORTED, ExecStatus.REJECTED -> Brand.Red
    ExecStatus.FAILED -> Brand.Red
}

@Composable
fun KvRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(0.42f))
        Text(v, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End, modifier = Modifier.weight(0.58f))
    }
}

@Composable
fun KvCard(title: String, items: List<Pair<String, String>>, accent: Color = Brand.Cyan, expanded: Boolean = false) {
    ExpandCard(title, accent, expanded) { items.forEach { KvRow(it.first, it.second) } }
}

@Composable
fun CapabilityRow(c: Capability) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(c.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(end = 8.dp))
            StatusChip(c.status.label, c.status.color())
        }
        Text(c.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null) {
    Button(
        onClick = onClick, modifier = modifier, enabled = enabled, shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, disabledContainerColor = Color.Transparent)
    ) {
        Row(
            Modifier.background(if (enabled) Brand.Gradient else SolidColor(Color(0xFF3A4766)), RoundedCornerShape(14.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun ResultPanel(status: ExecStatus, output: String, error: String?, durationMs: Long? = null) {
    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.background, border = BorderStroke(1.dp, status.color().copy(alpha = 0.6f))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                StatusChip(status.label, status.color())
                if (durationMs != null) Text("$durationMs ms", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (output.isNotBlank()) SelectionContainer { Text(output, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
            if (!error.isNullOrBlank()) SelectionContainer { Text("Error: $error", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Brand.Red) }
        }
    }
}

@Composable
fun Loading(visible: Boolean) {
    if (visible) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Brand.Cyan)
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = Brand.Cyan, modifier = Modifier.padding(top = 8.dp))
}
