package com.usbchecker.frp.ui.commands

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.core.Tr
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.Loading
import com.usbchecker.frp.designsystem.ResultPanel
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.ui.common.CommandViewModel
import com.usbchecker.frp.ui.common.ScreenScaffold

@Composable
fun CommandCenterScreen(onBack: () -> Unit) {
    val vm: CommandViewModel = viewModel()
    val results = vm.results.collectAsStateWithLifecycle().value
    val running = vm.running.collectAsStateWithLifecycle().value
    val logs = vm.logs.collectAsStateWithLifecycle().value
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("all") }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }

    val categories = remember { listOf("all") + vm.registry.commands.map { it.category }.distinct() }
    val filtered = vm.registry.commands.filter {
        (category == "all" || it.category == category) &&
            (query.isBlank() || it.id.contains(query.trim(), true) || it.description.contains(query.trim(), true))
    }
    val sel = selected?.let { vm.registry.find(it) }

    ScreenScaffold("Command Center", onBack, scroll = false) { snack ->
        OutlinedTextField(query, { query = it.take(40) }, Modifier.fillMaxWidth(), singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) }, placeholder = { Text("Search commands") })
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { cat -> FilterChip(category == cat, { category = cat }, { Text(cat) }) }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sel != null) item(key = "preview") {
                FrpCard {
                    Text("Command Preview", style = MaterialTheme.typography.titleMedium, color = Brand.Cyan)
                    Text(sel.id, fontFamily = FontFamily.Monospace)
                    Text(sel.description)
                    Text("Effect: ${sel.effect}   Category: ${sel.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    GradientButton(Tr.t("Execute"), { vm.run(sel.id) { snack("${it.command}: ${it.result.status.label}") } }, enabled = sel.id !in running, icon = Icons.Filled.PlayArrow)
                    Loading(sel.id in running)
                    results[sel.id]?.let { ResultPanel(it.result.status, it.result.output, it.result.error, it.durationMs) }
                }
            }
            item { SectionTitle("Quick Commands") }
            items(filtered, key = { it.id }) { d ->
                FrpCard(Modifier.clickable { selected = d.id }) {
                    Text(d.id, fontFamily = FontFamily.Monospace, color = Brand.Electric, fontSize = 13.sp)
                    Text(d.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { SectionTitle("Command History") }
            if (logs.isEmpty()) item { Text("No commands executed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(logs.take(15)) { l ->
                Text(l.asLine(), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }
}
