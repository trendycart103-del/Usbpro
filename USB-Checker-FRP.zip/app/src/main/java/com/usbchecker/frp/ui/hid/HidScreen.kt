package com.usbchecker.frp.ui.hid

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.usbchecker.frp.core.compatibility.Compat
import com.usbchecker.frp.designsystem.Brand
import com.usbchecker.frp.designsystem.CapabilityRow
import com.usbchecker.frp.designsystem.FrpCard
import com.usbchecker.frp.designsystem.GradientButton
import com.usbchecker.frp.designsystem.KvRow
import com.usbchecker.frp.designsystem.SectionTitle
import com.usbchecker.frp.designsystem.StatusChip
import com.usbchecker.frp.ui.common.ScreenScaffold
import com.usbchecker.frp.ui.usb.UsbViewModel

@Composable
fun HidScreen(onBack: () -> Unit) {
    val vm: UsbViewModel = viewModel()
    val ctx = LocalContext.current
    val devices = vm.devices.collectAsStateWithLifecycle().value
    var inputs by remember { mutableStateOf(vm.inputDevices()) }
    val hid = devices.flatMap { d -> d.hidInterfaces.map { d to it } }

    ScreenScaffold("HID Compatibility", onBack) { snack ->
        SectionTitle("HID Capability Report")
        FrpCard { Compat.hid(ctx).forEach { CapabilityRow(it) } }

        SectionTitle("HID Mouse / Keyboard detection (USB descriptors)")
        FrpCard {
            if (hid.isEmpty()) Text("No USB HID interface detected.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            hid.forEach { (d, i) ->
                KvRow("${d.vidPid} IF${i.id}", i.hidKind ?: "HID")
            }
            Text("Generic (non-boot) HID may still be a mouse or keyboard; that cannot be known without reading the HID report descriptor.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionTitle("Android input devices")
        FrpCard {
            if (inputs.isEmpty()) Text("No physical input device registered.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            inputs.forEach {
                KvRow(it.name, listOfNotNull("mouse".takeIf { _ -> it.mouse }, "keyboard".takeIf { _ -> it.keyboard })
                    .joinToString().ifEmpty { "other" } + if (it.external) " (external)" else "")
            }
            GradientButton("Refresh", { inputs = vm.inputDevices(); snack("Input devices refreshed: ${inputs.size}") })
        }

        SectionTitle("Mouse Compatibility Test")
        MouseTest()
        SectionTitle("Keyboard Compatibility Test")
        KeyboardTest()
    }
}

@Composable
private fun MouseTest() {
    var events by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf("Move or click a connected mouse inside this box.") }
    var seen by remember { mutableStateOf(false) }
    FrpCard {
        Box(
            Modifier.fillMaxWidth().height(120.dp).background(MaterialTheme.colorScheme.background, RoundedCornerShape(14.dp))
                .border(1.dp, if (seen) Brand.Green else Brand.Border, RoundedCornerShape(14.dp))
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val e = awaitPointerEvent()
                            val ch = e.changes.firstOrNull() ?: continue
                            if (ch.type == PointerType.Mouse) {
                                seen = true; events++
                                detail = "Mouse events: $events  x=${ch.position.x.toInt()} y=${ch.position.y.toInt()}  primary=${e.buttons.isPrimaryPressed} secondary=${e.buttons.isSecondaryPressed}"
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) { Text(detail, modifier = Modifier.padding(8.dp)) }
        StatusChip(if (seen) "Mouse pointer events received" else "No mouse events yet", if (seen) Brand.Green else Brand.Yellow)
    }
}

@Composable
private fun KeyboardTest() {
    val fr = remember { FocusRequester() }
    var last by remember { mutableStateOf("Tap the box, then press keys on a connected keyboard.") }
    var seen by remember { mutableStateOf(false) }
    FrpCard {
        Box(
            Modifier.fillMaxWidth().height(90.dp).background(MaterialTheme.colorScheme.background, RoundedCornerShape(14.dp))
                .border(1.dp, if (seen) Brand.Green else Brand.Border, RoundedCornerShape(14.dp))
                .focusRequester(fr)
                .onKeyEvent {
                    if (it.type == KeyEventType.KeyDown) { seen = true; last = "Key code ${it.key.nativeKeyCode}" }
                    true
                }
                .focusable()
                .clickable { fr.requestFocus() },
            contentAlignment = Alignment.Center
        ) { Text(last, modifier = Modifier.padding(8.dp)) }
        StatusChip(if (seen) "Keyboard key events received" else "No key events yet", if (seen) Brand.Green else Brand.Yellow)
    }
}
