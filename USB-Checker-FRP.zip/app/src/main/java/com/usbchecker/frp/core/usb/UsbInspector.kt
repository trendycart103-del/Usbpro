package com.usbchecker.frp.core.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.view.InputDevice
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class EndpointInfo(val address: Int, val type: String, val direction: String, val maxPacket: Int, val interval: Int)

data class InterfaceInfo(
    val id: Int, val cls: Int, val clsName: String, val sub: Int, val proto: Int,
    val endpoints: List<EndpointInfo>, val hidKind: String?
)

data class UsbDeviceInfo(
    val name: String, val vid: Int, val pid: Int, val cls: Int, val hasPermission: Boolean,
    val manufacturer: String?, val product: String?, val usbVersion: String?,
    val interfaces: List<InterfaceInfo>
) {
    val vidPid get() = "${UsbClassify.hex4(vid)}:${UsbClassify.hex4(pid)}"
    val hidInterfaces get() = interfaces.filter { it.hidKind != null }
}

data class TransferResult(val ok: Boolean, val message: String)

data class InputDeviceInfo(val name: String, val vid: Int, val pid: Int, val mouse: Boolean, val keyboard: Boolean, val external: Boolean)

class UsbInspector(context: Context) {
    private val ctx = context.applicationContext
    private val mgr = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    val hostSupported: Boolean get() = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
    val accessorySupported: Boolean get() = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY)

    fun rawDevices(): List<UsbDevice> = try {
        mgr.deviceList?.values?.toList().orEmpty()
    } catch (e: Exception) {
        emptyList()
    }

    fun hasPerm(d: UsbDevice): Boolean = runCatching { mgr.hasPermission(d) }.getOrDefault(false)

    fun find(name: String): UsbDevice? = rawDevices().firstOrNull { it.deviceName == name }

    fun devices(): List<UsbDeviceInfo> = rawDevices().map { describe(it) }

    fun describe(d: UsbDevice): UsbDeviceInfo {
        val granted = runCatching { mgr.hasPermission(d) }.getOrDefault(false)
        val ifaces = (0 until d.interfaceCount).mapNotNull { i ->
            runCatching {
                val itf = d.getInterface(i)
                val eps = (0 until itf.endpointCount).map { e ->
                    val ep = itf.getEndpoint(e)
                    EndpointInfo(
                        ep.address, UsbClassify.endpointType(ep.type),
                        if (ep.direction == 0x80) "IN" else "OUT", ep.maxPacketSize, ep.interval
                    )
                }
                InterfaceInfo(
                    itf.id, itf.interfaceClass, UsbClassify.className(itf.interfaceClass),
                    itf.interfaceSubclass, itf.interfaceProtocol, eps,
                    UsbClassify.hidKind(itf.interfaceClass, itf.interfaceSubclass, itf.interfaceProtocol)
                )
            }.getOrNull()
        }
        // Manufacturer/product strings may be null until permission is granted.
        val man = runCatching { d.manufacturerName }.getOrNull()
        val prod = runCatching { d.productName }.getOrNull()
        val ver = runCatching { d.version }.getOrNull()
        return UsbDeviceInfo(d.deviceName, d.vendorId, d.productId, d.deviceClass, granted, man, prod, ver, ifaces)
    }

    /** Uses the Android system permission dialog. [onResult] receives the real outcome. */
    fun requestPermission(d: UsbDevice, onResult: (Boolean) -> Unit) {
        if (mgr.hasPermission(d)) { onResult(true); return }
        val action = "${ctx.packageName}.USB_PERMISSION"
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val dev = IntentCompat.getParcelableExtra(i, UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                if (dev != null && dev.deviceName != d.deviceName) return
                runCatching { ctx.unregisterReceiver(this) }
                onResult(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
            }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(ctx, 0, Intent(action).setPackage(ctx.packageName), flags)
        try {
            mgr.requestPermission(d, pi)
        } catch (e: Exception) {
            runCatching { ctx.unregisterReceiver(receiver) }
            onResult(false)
        }
    }

    /** Reads the 18-byte standard device descriptor via a control transfer; connection is always closed. */
    suspend fun transferTest(d: UsbDevice): TransferResult = withContext(Dispatchers.IO) {
        if (!mgr.hasPermission(d)) return@withContext TransferResult(false, "No USB permission; transfer not attempted.")
        val conn = try { mgr.openDevice(d) } catch (e: Exception) { null }
            ?: return@withContext TransferResult(false, "Android could not open the device.")
        try {
            val buf = ByteArray(18)
            val n = conn.controlTransfer(0x80, 0x06, 0x0100, 0, buf, buf.size, 1000)
            if (n == 18) {
                val bcd = ((buf[3].toInt() and 0xFF) shl 8) or (buf[2].toInt() and 0xFF)
                val vid = ((buf[9].toInt() and 0xFF) shl 8) or (buf[8].toInt() and 0xFF)
                val pid = ((buf[11].toInt() and 0xFF) shl 8) or (buf[10].toInt() and 0xFF)
                TransferResult(true, "Control transfer OK: bcdUSB=%x.%02x VID:PID=%s:%s".format(bcd shr 8, bcd and 0xFF,
                    UsbClassify.hex4(vid), UsbClassify.hex4(pid)))
            } else TransferResult(false, "Control transfer returned $n (expected 18).")
        } catch (e: Exception) {
            TransferResult(false, "Transfer error: ${e.javaClass.simpleName}")
        } finally {
            runCatching { conn.close() }
        }
    }

    fun accessories(): List<String> = runCatching {
        mgr.accessoryList?.map { "${it.manufacturer} / ${it.model} (${it.description ?: "-"})" }.orEmpty()
    }.getOrDefault(emptyList())

    fun inputDevices(): List<InputDeviceInfo> = InputDevice.getDeviceIds().mapNotNull { id ->
        val d = InputDevice.getDevice(id) ?: return@mapNotNull null
        if (d.isVirtual) return@mapNotNull null
        val src = d.sources
        InputDeviceInfo(
            d.name, d.vendorId, d.productId,
            (src and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE,
            (src and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD && d.keyboardType != InputDevice.KEYBOARD_TYPE_NONE,
            d.externalCompat()
        )
    }

    private fun InputDevice.externalCompat(): Boolean =
        if (Build.VERSION.SDK_INT >= 29) isExternal else false
}
