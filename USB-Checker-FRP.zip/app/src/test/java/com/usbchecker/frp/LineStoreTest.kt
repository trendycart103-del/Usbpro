package com.usbchecker.frp

import com.usbchecker.frp.data.LineStore
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class LineStoreTest {
    @get:Rule val tmp = TemporaryFolder()

    @Test fun rotatesAtLimit() {
        val s = LineStore(tmp.newFile("a.jsonl"), 5)
        repeat(12) { s.append(JSONObject().put("n", it)) }
        val all = s.readAll()
        assertEquals(5, all.size)
        assertEquals(7, all.first().getInt("n"))
        assertEquals(11, all.last().getInt("n"))
    }

    @Test fun clearEmpties() {
        val s = LineStore(tmp.newFile("b.jsonl"), 5)
        s.append(JSONObject().put("x", 1)); s.clear()
        assertEquals(0, s.readAll().size)
    }

    @Test fun skipsCorruptLines() {
        val f = tmp.newFile("c.jsonl"); f.writeText("{bad\n{\"ok\":1}\n")
        assertEquals(1, LineStore(f, 10).readAll().size)
    }
}
