package com.usbchecker.frp

import com.usbchecker.frp.core.usb.UsbClassify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UsbClassifyTest {
    @Test fun bootKeyboard() = assertEquals("Keyboard (boot protocol)", UsbClassify.hidKind(3, 1, 1))
    @Test fun bootMouse() = assertEquals("Mouse (boot protocol)", UsbClassify.hidKind(3, 1, 2))
    @Test fun genericHid() = assertEquals("HID (generic / non-boot)", UsbClassify.hidKind(3, 0, 0))
    @Test fun nonHid() = assertNull(UsbClassify.hidKind(8, 6, 80))
    @Test fun classNames() { assertEquals("Mass Storage", UsbClassify.className(8)); assertEquals("Class 0x77", UsbClassify.className(0x77)) }
    @Test fun hex() = assertEquals("04D9", UsbClassify.hex4(0x04D9))
    @Test fun endpoint() = assertEquals("Bulk", UsbClassify.endpointType(2))
}
