package com.usbchecker.frp

import com.usbchecker.frp.utils.Fmt
import org.junit.Assert.assertEquals
import org.junit.Test

class FmtTest {
    @Test fun sha256Empty() = assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", Fmt.sha256(ByteArray(0)))
    @Test fun bytesFormat() { assertEquals("512 B", Fmt.bytes(512)); assertEquals("1.00 KB", Fmt.bytes(1024)) }
}
