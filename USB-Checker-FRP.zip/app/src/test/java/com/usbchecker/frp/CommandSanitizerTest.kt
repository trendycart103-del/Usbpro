package com.usbchecker.frp

import com.usbchecker.frp.core.commands.CommandSanitizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandSanitizerTest {
    @Test fun acceptsRegisteredShape() = assertEquals("usb.scan", CommandSanitizer.sanitize("  USB.Scan "))
    @Test fun acceptsMultiSegment() = assertEquals("device.android.version", CommandSanitizer.sanitize("device.android.version"))
    @Test fun rejectsShellSyntax() {
        assertNull(CommandSanitizer.sanitize("usb.scan; rm -rf /"))
        assertNull(CommandSanitizer.sanitize("ls"))
        assertNull(CommandSanitizer.sanitize("usb.scan && id"))
        assertNull(CommandSanitizer.sanitize("$(reboot)"))
    }
    @Test fun rejectsArgumentsAndEmpty() {
        assertNull(CommandSanitizer.sanitize("usb.scan now"))
        assertNull(CommandSanitizer.sanitize(""))
    }
    @Test fun rejectsTooLong() = assertNull(CommandSanitizer.sanitize("a." + "b".repeat(60)))
}
